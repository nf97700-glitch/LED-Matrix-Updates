import json
import math
import os
import random
import subprocess
import sys
import threading
import time
import urllib.request

from PyQt6.QtCore import (
    QAbstractAnimation,
    QByteArray,
    QEasingCurve,
    QPropertyAnimation,
    QVariantAnimation,
    QRect,
    QRectF,
    QSettings,
    QSize,
    QTime,
    Qt,
    QPointF,
    QTimer,
    QObject,
    pyqtSignal,
)
from PyQt6.QtGui import (
    QConicalGradient,
    QColor,
    QFont,
    QFontMetricsF,
    QIcon,
    QImage,
    QKeySequence,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QRadialGradient,
    QShortcut,
)
from PyQt6.QtNetwork import QHostAddress, QTcpSocket, QUdpSocket
from PyQt6.QtWidgets import (
    QAbstractButton,
    QApplication,
    QComboBox,
    QMenu,
    QMessageBox,
    QToolButton,
    QFrame,
    QGridLayout,
    QGraphicsDropShadowEffect,
    QGraphicsOpacityEffect,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
    QSlider,
    QStackedWidget,
    QTimeEdit,
    QVBoxLayout,
    QWidget,
)

try:
    # иконки интерфейса
    from PyQt6.QtSvg import QSvgRenderer
except ImportError:
    QSvgRenderer = None

DISCOVERY_PORT = 45454
COMMAND_PORT = 3333
ANNOUNCE_PREFIX = "LEDGARLAND|"
PING_TEXT = b"PING"

# файлы обновлений (программа, приложение, прошивка) — в публичном репозитории
UPDATES_URL = "https://raw.githubusercontent.com/nf97700-glitch/LED-Matrix-Updates/main/"
# версия программы: установленная программа сравнивает её с version.json и обновляется сама
APP_VERSION = 22
MATRIX_PROFILES = {
    'esp32-19x20': {'columns':19, 'rows':20, 'name':'Matrix · 19×20'},
    'esp32c3-9x20': {'columns':9, 'rows':20, 'name':'ESP32-C3 Super Mini · 9×20'},
}
ROOT_SETTINGS = QSettings('LedGarland','LEDMatrixStudio')
MATRIX_PROFILE = str(ROOT_SETTINGS.value('matrix_profile','esp32-19x20'))
if MATRIX_PROFILE not in MATRIX_PROFILES: MATRIX_PROFILE='esp32-19x20'
if str(ROOT_SETTINGS.value('dual_enabled','true'))=='false': MATRIX_PROFILE='esp32-19x20'
MATRIX_COLUMNS = MATRIX_PROFILES[MATRIX_PROFILE]['columns']
MATRIX_ROWS = MATRIX_PROFILES[MATRIX_PROFILE]['rows']
MATRIX_LABEL = MATRIX_PROFILES[MATRIX_PROFILE]['name']

def profile_firmware(manifest):
    if MATRIX_PROFILE=='esp32-19x20': return (manifest or {}).get('firmware') or {}
    return ((manifest or {}).get('firmwares') or {}).get(MATRIX_PROFILE) or {}

def decode_discovery(message, ip):
    parts=message.split('|')
    if parts[0]=='MATRIX2' and len(parts)==6:
        model=parts[2]
        if model not in MATRIX_PROFILES:return None
        p=MATRIX_PROFILES[model]
        if parts[4:]!=[str(p['columns']),str(p['rows'])]:return None
        return {'profile':model,'name':parts[1],'id':parts[3],'ip':ip,'seen':time.monotonic()}
    if message.startswith('LEDGARLAND|'):
        return {'profile':'esp32-19x20','name':parts[1] or 'Matrix','id':'legacy19','ip':ip,'seen':time.monotonic()}
    return None

class ProfileSettings(QSettings):
    def __init__(self):super().__init__('LedGarland','LEDMatrixStudio')
    def _key(self,k):return k if MATRIX_PROFILE=='esp32-19x20' else 'profiles/'+MATRIX_PROFILE+'/'+k
    def value(self,k,defaultValue=None,**kwargs):return super().value(self._key(k),defaultValue,**kwargs)
    def setValue(self,k,v):return super().setValue(self._key(k),v)
    def remove(self,k):return super().remove(self._key(k))

APP_DIR = os.path.dirname(os.path.abspath(__file__))
# установлена как приложение (папка app рядом с runtime), а не запущена из PyCharm
INSTALLED = os.path.isfile(os.path.join(APP_DIR, "installed.txt"))


def fetch_update_bytes(url, timeout=8, max_bytes=16*1024*1024, progress=None, expected_sha=None, attempts=3, budget=40):
    """Three bounded attempts. Never returns partial data; TLS validation remains enabled."""
    import hashlib,ssl,urllib.error,http.client
    started=time.monotonic();last=None
    for attempt in range(1,attempts+1):
        if time.monotonic()-started>budget:break
        if progress:progress(f'Соединение с сервером — попытка {attempt}/{attempts}…')
        try:
            req=urllib.request.Request(url,headers={'Cache-Control':'no-cache','Accept-Encoding':'identity','User-Agent':'LEDMatrix/19'})
            with urllib.request.urlopen(req,timeout=min(timeout,max(1,budget-(time.monotonic()-started)))) as resp:
                expected=resp.headers.get('Content-Length');total=int(expected) if expected is not None else None
                if total is not None and (total<1 or total>max_bytes):raise ValueError('неверный размер обновления')
                data=bytearray()
                while True:
                    if time.monotonic()-started>budget:raise TimeoutError('время загрузки истекло')
                    chunk=resp.read(min(16384,max_bytes+1-len(data)))
                    if not chunk:break
                    data.extend(chunk)
                    if len(data)>max_bytes:raise ValueError('слишком большой файл обновления')
                    if progress:progress(f'Скачиваю · {len(data)//1024}'+(f'/{(total+1023)//1024} КБ' if total else ' КБ'))
                if not data or total is not None and len(data)!=total:raise OSError('файл скачался не полностью')
                if expected_sha and hashlib.sha256(data).hexdigest()!=expected_sha.lower():raise ValueError('контрольная сумма обновления не совпала')
                return bytes(data)
        except (ssl.SSLCertVerificationError,ValueError):raise
        except urllib.error.HTTPError as e:
            if e.code not in [408,429,500,502,503,504]:raise
            last=e
        except (OSError,urllib.error.URLError,http.client.IncompleteRead) as e:
            if isinstance(getattr(e,'reason',None),ssl.SSLCertVerificationError):raise
            last=e
        if attempt<attempts:time.sleep(.5*attempt)
    raise RuntimeError('сервер обновлений недоступен после повторных попыток; установленная версия не изменена') from last


def runtime_version():
    try:
        with open(os.path.join(APP_DIR, "installed.txt"), encoding="utf-8") as file:
            return int(file.read().strip() or 1)
    except (OSError, ValueError):
        return 1
PING_INTERVAL_MS = 1500
OFFLINE_TIMEOUT_S = 10
SNOW_FLAKES = round(120*MATRIX_COLUMNS/19)

# Цвет выключенного диода; «пустые» цвета (в т.ч. из старых
# сохранённых картинок) на гирлянду уходят чёрным
DOT_OFF = "#161616"
OFF_HEXES = {"#303948", "#C9D3E2", "#121214", "#161616"}

# Точечный шрифт 5x7 для логотипа темы Dot Matrix
DOT_FONT = {
    "A": ("01110", "10001", "10001", "11111", "10001", "10001", "10001"),
    "D": ("11110", "10001", "10001", "10001", "10001", "10001", "11110"),
    "E": ("11111", "10000", "10000", "11110", "10000", "10000", "11111"),
    "I": ("11111", "00100", "00100", "00100", "00100", "00100", "11111"),
    "L": ("10000", "10000", "10000", "10000", "10000", "10000", "11111"),
    "M": ("10001", "11011", "10101", "10101", "10001", "10001", "10001"),
    "R": ("11110", "10001", "10001", "11110", "10100", "10010", "10001"),
    "T": ("11111", "00100", "00100", "00100", "00100", "00100", "00100"),
    "X": ("10001", "10001", "01010", "00100", "01010", "10001", "10001"),
    " ": ("000", "000", "000", "000", "000", "000", "000"),
    # цифры для точечных часов во вкладке «Сценарии»
    "0": ("01110", "10001", "10011", "10101", "11001", "10001", "01110"),
    "1": ("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
    "2": ("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
    "3": ("11111", "00010", "00100", "00010", "00001", "10001", "01110"),
    "4": ("00010", "00110", "01010", "10010", "11111", "00010", "00010"),
    "5": ("11111", "10000", "11110", "00001", "00001", "10001", "01110"),
    "6": ("00110", "01000", "10000", "11110", "10001", "10001", "01110"),
    "7": ("11111", "00001", "00010", "00100", "01000", "01000", "01000"),
    "8": ("01110", "10001", "10001", "01110", "10001", "10001", "01110"),
    "9": ("01110", "10001", "10001", "01111", "00001", "00010", "01100"),
    ":": ("0", "0", "1", "0", "1", "0", "0"),
    ";": ("0", "0", "0", "0", "0", "0", "0"),
}


def dot_text_pixmap(text, dot=3.0, gap=1.2, on="#FFFFFF", off="#1C1C1C"):
    """Текст, нарисованный точками, как на светодиодной матрице."""
    columns = []
    for char in text:
        glyph = DOT_FONT.get(char, DOT_FONT[" "])
        for x in range(len(glyph[0])):
            columns.append([glyph[y][x] == "1" for y in range(7)])
        columns.append([False] * 7)
    columns = columns[:-1]

    step = dot + gap
    width = int(math.ceil(len(columns) * step))
    height = int(math.ceil(7 * step))
    pixmap = QPixmap(width * 2, height * 2)
    pixmap.setDevicePixelRatio(2.0)
    pixmap.fill(Qt.GlobalColor.transparent)

    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(Qt.PenStyle.NoPen)
    for x, column in enumerate(columns):
        for y, lit in enumerate(column):
            painter.setBrush(QColor(on if lit else off))
            painter.drawEllipse(
                QPointF(x * step + dot / 2, y * step + dot / 2), dot / 2, dot / 2
            )
    painter.end()
    return pixmap


def set_tracking(widget, pixels):
    """Разрядка букв (letter-spacing) — в стилях Qt её нет."""
    font = widget.font()
    font.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, pixels)
    widget.setFont(font)


FIRE_PALETTE = (
    (0.00, 0, 0, 0),
    (0.20, 6, 0, 0),
    (0.40, 40, 1, 0),
    (0.60, 140, 6, 0),
    (0.78, 255, 22, 0),
    (0.90, 255, 55, 0),
    (1.00, 255, 95, 4),
)


def fire_hash(x, y):
    """Целочисленный хеш → 0..1. Один в один как в прошивке ESP32."""
    h = (x * 374761393 + y * 668265263) & 0xFFFFFFFF
    h = ((h ^ (h >> 13)) * 1274126177) & 0xFFFFFFFF
    h ^= h >> 16
    return h / 4294967295.0


def fire_noise(x, y):
    """Плавный 2D value-noise 0..1 — из него «живое» шевеление пламени."""
    xi = math.floor(x)
    yi = math.floor(y)
    fx = x - xi
    fy = y - yi
    u = fx * fx * (3 - 2 * fx)
    v = fy * fy * (3 - 2 * fy)
    a = fire_hash(xi, yi)
    b = fire_hash(xi + 1, yi)
    c = fire_hash(xi, yi + 1)
    d = fire_hash(xi + 1, yi + 1)
    top = a + (b - a) * u
    bottom = c + (d - c) * u
    return top + (bottom - top) * v


def fire_palette(heat):
    if heat <= 0.0:
        return (0, 0, 0)
    if heat >= 1.0:
        return FIRE_PALETTE[-1][1:]
    for i in range(1, len(FIRE_PALETTE)):
        p1 = FIRE_PALETTE[i]
        if heat <= p1[0]:
            p0 = FIRE_PALETTE[i - 1]
            k = (heat - p0[0]) / (p1[0] - p0[0])
            return (
                p0[1] + (p1[1] - p0[1]) * k,
                p0[2] + (p1[2] - p0[2]) * k,
                p0[3] + (p1[3] - p0[3]) * k,
            )
    return FIRE_PALETTE[-1][1:]


def fire_speed_factor(speed):
    """Ползунок 1..100 → множитель времени. 65 (по умолчанию) = 1.0."""
    speed = max(1, min(100, int(speed)))
    if speed <= 65:
        return 0.3 + 0.7 * (speed - 1) / 64.0
    return 1.0 + (speed - 65) / 35.0


def rainbow_rgb(column, row, t):
    """Радужная волна: оттенок плывёт по диагонали и слегка колышется.
    Та же формула — в прошивке ESP32."""
    h = column * 0.03 + row * 0.025 - t * 0.25 + 0.08 * math.sin(t + row * 0.3)
    h -= math.floor(h)
    v = 230.0
    i = int(h * 6.0) % 6
    f = h * 6.0 - int(h * 6.0)
    q = v * (1.0 - f)
    w = v * f
    return ((v, w, 0.0), (q, v, 0.0), (0.0, v, w), (0.0, q, v), (w, 0.0, v), (v, 0.0, q))[i]


class RainSimulation:
    """Дождь в стиле Minecraft: квадратные капли падают вниз, внизу брызги
    и земля. Цвета подобраны под светодиоды. Тот же алгоритм — в ESP32."""

    DROPS = 8 if MATRIX_COLUMNS==9 else 16
    SPLASH_LIFE = 0.12

    def __init__(self, columns=MATRIX_COLUMNS, rows=MATRIX_ROWS):
        self.columns = columns
        self.rows = rows
        self.k = 1.0
        self.drops = [self.new_drop(spread=True) for _ in range(self.DROPS)]
        self.splashes = []
        self.frame = [[(0, 0, 0)] * columns for _ in range(rows)]

    def set_speed(self, speed):
        self.k = fire_speed_factor(speed)

    def new_drop(self, spread=False):
        return {
            "c": random.randrange(self.columns),
            "len": random.randint(2, 4),
            "y": random.uniform(-self.rows, self.rows) if spread else random.uniform(-6.0, -1.0),
            "v": random.uniform(16.0, 22.0),
            "b": random.uniform(0.55, 1.0),
        }

    def step(self, dt):
        dt *= self.k
        cols, rows = self.columns, self.rows
        ground = rows - 1
        frame = [[(0, 1, 4)] * cols for _ in range(rows)]
        for c in range(cols):
            frame[ground][c] = (14, 5, 0) if c % 3 else (18, 7, 0)

        for i, d in enumerate(self.drops):
            d["y"] += d["v"] * dt
            head = int(math.floor(d["y"]))
            if head >= ground:
                if len(self.splashes) < self.DROPS:
                    self.splashes.append([d["c"], 0.0])
                self.drops[i] = self.new_drop()
                continue
            for k in range(d["len"]):
                r = head - k
                if 0 <= r < ground:
                    a = d["b"] * (1.0 - k / (d["len"] + 0.5))
                    frame[r][d["c"]] = (12 * a, 30 * a + 1, 150 * a + 4)

        alive = []
        for sp in self.splashes:
            sp[1] += dt
            if sp[1] > self.SPLASH_LIFE:
                continue
            alive.append(sp)
            a = 1.0 - sp[1] / self.SPLASH_LIFE
            for dc in (-1, 1):
                cc = sp[0] + dc
                if 0 <= cc < cols:
                    frame[ground - 1][cc] = (16 * a, 40 * a + 1, 170 * a + 4)
            frame[ground][sp[0]] = (20, 40, 150)
        self.splashes = alive
        self.frame = frame
        return frame


def hsv_unit(h, s, v):
    h -= math.floor(h)
    i = int(h * 6.0)
    f = h * 6.0 - i
    p, q, t = v * (1 - s), v * (1 - s * f), v * (1 - s * (1 - f))
    return ((v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q))[i % 6]


def _fb_add(fb, r, c, col, a):
    if 0 <= r < len(fb) and 0 <= c < len(fb[0]):
        p = fb[r][c]
        for i in range(3):
            p[i] = min(255.0, p[i] + col[i] * a)


def _fb_splat(fb, y, x, col, a, rad):
    for r in range(int(y) - 2, int(y) + 3):
        for c in range(int(x) - 2, int(x) + 3):
            d = math.hypot(r - y, c - x)
            if d < rad + 0.5:
                _fb_add(fb, r, c, col, a * (1.0 - d / (rad + 0.5)))


class FireworksSimulation:
    """Фейерверк: ракеты взлетают, вспыхивают и рассыпаются искрами.
    Тот же алгоритм — в прошивке ESP32 и в приложении."""

    def __init__(self, columns=MATRIX_COLUMNS, rows=MATRIX_ROWS):
        self.columns, self.rows = columns, rows
        self.k = 1.0
        self.rockets, self.parts = [], []
        self.frame = [[[0.0, 0.0, 0.0] for _ in range(columns)] for _ in range(rows)]
        self.launch()

    def set_speed(self, speed):
        self.k = fire_speed_factor(speed)

    def launch(self):
        if len(self.rockets) < 4:
            self.rockets.append({"x": random.uniform(3, self.columns - 4), "y": self.rows - 1.0,
                                 "vy": -random.uniform(13, 17), "top": random.uniform(3, 8),
                                 "hue": random.random()})

    def step(self, dt):
        dt *= self.k
        if random.random() < 1.125 * dt or (not self.rockets and not self.parts):
            self.launch()
        fb = self.frame
        fade, damp = 0.72 ** (dt / 0.04), 0.93 ** (dt / 0.04)
        for row in fb:
            for p in row:
                p[0] *= fade
                p[1] *= fade
                p[2] *= fade
        alive = []
        for k in self.rockets:
            k["y"] += k["vy"] * dt
            k["vy"] += 6 * dt
            _fb_splat(fb, k["y"], k["x"], (255, 190, 120), 0.9, 0.6)
            if k["y"] > k["top"] and k["vy"] < -2:
                alive.append(k)
                continue
            n = random.randint(26, 40)
            h2 = k["hue"] + random.choice((0.0, 0.5, 0.15))
            for j in range(n):
                if len(self.parts) >= 140:
                    break
                a = 2 * math.pi * j / n + random.uniform(-0.1, 0.1)
                sp = random.uniform(5, 9)
                self.parts.append({"x": k["x"], "y": k["y"], "vx": math.cos(a) * sp, "vy": math.sin(a) * sp,
                                   "age": 0.0, "life": random.uniform(1.0, 1.6), "hue": k["hue"] if j % 3 else h2})
            _fb_splat(fb, k["y"], k["x"], (255, 255, 255), 1.0, 1.8)
        self.rockets = alive
        alive = []
        for p in self.parts:
            p["age"] += dt
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt
            p["vx"] *= damp
            p["vy"] = p["vy"] * damp + 5 * dt
            if p["age"] > p["life"]:
                continue
            alive.append(p)
            k = 1.0 - p["age"] / p["life"]
            col = [255 * v for v in hsv_unit(p["hue"], 0.85 * min(1.0, p["age"] * 3), 1.0)]
            tw = 1.0 if k > 0.35 else 0.4 + 0.6 * random.random()
            _fb_add(fb, int(round(p["y"])), int(round(p["x"])), col, k * tw)
        self.parts = alive
        return fb


class LavaSimulation:
    """Лава-лампа: пять капель плавно всплывают и сливаются."""

    def __init__(self, columns=MATRIX_COLUMNS, rows=MATRIX_ROWS):
        self.columns, self.rows = columns, rows
        self.k = 1.0
        self.t = 0.0
        self.blobs = [{"x": 3 + 3.2 * k + random.uniform(-0.5, 0.5), "ph": random.uniform(0, 6.28),
                       "sp": random.uniform(0.25, 0.45), "r": random.uniform(1.7, 2.3)} for k in range(5)]
        self.frame = [[(6, 0, 10)] * columns for _ in range(rows)]

    def set_speed(self, speed):
        self.k = fire_speed_factor(speed)

    def step(self, dt):
        self.t += dt * self.k
        t, rows, cols = self.t, self.rows, self.columns
        pos = [(b["x"] + 1.5 * math.sin(t * 0.6 + b["ph"]),
                rows / 2 + (rows / 2 - 2) * math.sin(t * b["sp"] * 2 + b["ph"]), b["r"] * b["r"]) for b in self.blobs]
        hs = 0.03 * math.sin(t)
        frame = []
        for r in range(rows):
            line = []
            for c in range(cols):
                v = sum(rr / ((c - x) ** 2 + (r - y) ** 2 + 0.5) for x, y, rr in pos)
                if v > 1.0:
                    k = min(1.0, (v - 1.0) / 1.5)
                    col = hsv_unit(0.95 + 0.1 * r / rows + hs, 1 - 0.35 * k, 0.55 + 0.45 * k)
                    line.append((255 * col[0], 255 * col[1] * 0.8, 255 * col[2]))
                elif v > 0.7:
                    a = (v - 0.7) / 0.3
                    line.append((max(6.0, 70 * a), 8 * a, max(10.0, 40 * a)))
                else:
                    line.append((6, 0, 10))
            frame.append(line)
        self.frame = frame
        return frame


class StarsSimulation:
    """Звёздное небо: мерцающие звёзды, холмы и падающие звёзды."""

    def __init__(self, columns=MATRIX_COLUMNS, rows=MATRIX_ROWS):
        self.columns, self.rows = columns, rows
        self.k = 1.0
        self.t = 0.0
        self.stars = [{"r": random.randrange(rows - 3), "c": random.randrange(columns),
                       "ph": random.uniform(0, 6.28), "f": random.uniform(0.6, 2.2),
                       "b": random.uniform(0.25, 0.9), "warm": random.random() < 0.3} for _ in range(18 if MATRIX_COLUMNS==9 else 38)]
        self.shoot = []
        self.frame = [[(0, 0, 0)] * columns for _ in range(rows)]

    def set_speed(self, speed):
        self.k = fire_speed_factor(speed)

    def step(self, dt):
        dt *= self.k
        self.t += dt
        rows, cols, t = self.rows, self.columns, self.t
        fb = [[[1 + 2 * r / rows, 1 + r / rows, 4 + 5 * r / rows] for _ in range(cols)] for r in range(rows)]
        for c in range(cols):
            h = int(2 + 1.2 * math.sin(c * 0.6) + 0.8 * math.sin(c * 1.7))
            for r in range(rows - h, rows):
                fb[r][c] = [0.0, 0.0, 1.0]
        for s in self.stars:
            w = 0.55 + 0.45 * math.sin(t * s["f"] * 3 + s["ph"])
            _fb_add(fb, s["r"], s["c"], (255, 210, 150) if s["warm"] else (200, 220, 255), s["b"] * w * w)
        if random.random() < 0.625 * dt and len(self.shoot) < 3:
            self.shoot.append({"x": random.uniform(4, cols), "y": random.uniform(0, 6), "age": 0.0})
        alive = []
        for s in self.shoot:
            s["age"] += dt
            s["x"] -= 22 * dt
            s["y"] += 11 * dt
            if s["age"] > 1.2 or s["x"] < -6:
                continue
            alive.append(s)
            for k in range(6):
                _fb_add(fb, int(round(s["y"] - k * 0.5)), int(round(s["x"] + k)), (255, 255, 255),
                        (1 - k / 6) * (1 - s["age"] / 1.2))
        self.shoot = alive
        self.frame = fb
        return fb


class GalaxySimulation:
    """Галактика: спиральные рукава вращаются вокруг яркого ядра."""

    def __init__(self, columns=MATRIX_COLUMNS, rows=MATRIX_ROWS):
        self.columns, self.rows = columns, rows
        self.k = 1.0
        self.t = 0.0
        self.frame = [[(0, 0, 0)] * columns for _ in range(rows)]

    def set_speed(self, speed):
        self.k = fire_speed_factor(speed)

    def step(self, dt):
        self.t += dt * self.k
        t = self.t
        cx, cy = (self.columns - 1) / 2, (self.rows - 1) / 2
        hs = 0.05 * math.sin(t)
        frame = []
        for r in range(self.rows):
            line = []
            for c in range(self.columns):
                dx, dy = c - cx, r - cy
                d = math.hypot(dx, dy)
                a = math.atan2(dy, dx)
                v = math.cos(2 * (a - t * 0.9) - d * 0.55)
                v = v * v * v * math.exp(-d / 9) if v > 0 else 0.0
                core = math.exp(-d * d / 5)
                col = hsv_unit(0.62 + 0.25 * d / 12 + hs, 0.8, 1.0)
                p = [min(255.0, 255 * (col[0] * v + core)), min(255.0, 255 * (col[1] * v + core * 0.85)),
                     min(255.0, 255 * (col[2] * v + core * 0.6))]
                if (r * 31 + c * 17) % 23 == 0:
                    a2 = 0.5 + 0.5 * math.sin(t * 3 + r + c)
                    p = [min(255.0, p[0] + 120 * a2), min(255.0, p[1] + 120 * a2), min(255.0, p[2] + 140 * a2)]
                line.append(p)
            frame.append(line)
        self.frame = frame
        return frame


NEW_MODE_KEYS = ("tunnel", "aurora", "plasma", "kaleidoscope")


def field_rgb(kind, c, r, x, y, radius, angle, t):
    """Одни и те же формулы на ESP, ПК и телефоне; кадры утверждённых предпросмотров."""
    if kind == "tunnel":
        a = 0.1 * math.sin(t * 0.65)
        u, v = x * math.cos(a) - y * math.sin(a), x * math.sin(a) + y * math.cos(a)
        q = max(abs(u), abs(v))
        p = (q * 2.6 - t * 0.66) % 1
        return tuple(255 * z for z in hsv_unit(0.54 + 0.29 * q + 0.055 * math.sin(t * 0.4), 0.84,
                       0.045 + 0.955 * math.exp(-((p - 0.5) / 0.15) ** 2)))
    if kind == "aurora":
        out = [0.0, 0.0, 0.0]
        for band in range(3):
            center = 5 + band * 4 + 2.8 * math.sin(c * 0.27 + t * 0.7 + band * 1.7) + 1.2 * math.sin(c * 0.61 - t * 0.5 + band)
            dy = r - center
            v = math.exp(-dy * dy / (22 if dy > 0 else 3.4)) * (0.52 + 0.48 * math.sin(c * 0.35 + t * 0.55 + band) ** 2)
            col = hsv_unit(0.34 + band * 0.075 + 0.045 * math.sin(c * 0.2 + t * 0.3), 0.85, v * 0.74)
            for i in range(3):
                out[i] += int(255 * col[i])
        return tuple(min(255, v) for v in out)
    if kind == "plasma":
        z = (math.sin(c * 0.44 + t * 1.6) + math.sin(r * 0.36 - t * 1.3) + math.sin((c + r) * 0.27 + t * 0.9) + math.sin(radius * 5 - t * 1.4)) / 4
        return tuple(255 * v for v in hsv_unit(0.72 + z * 0.28 + t * 0.06, 0.98, 0.16 + 0.76 * (0.5 + 0.5 * math.sin(z * 6 + t))))
    facet = math.cos(angle * 6 + t * 0.25)
    wave = radius * 9 + facet * 2.6 - t * 1.6
    return tuple(255 * v for v in hsv_unit(0.03 + radius * 0.22 + facet * 0.09 + 0.07 * math.sin(t * 0.3), 0.92, 0.025 + 0.975 * (0.5 + 0.5 * math.sin(wave)) ** 2))


class FieldSimulation:
    kind = "plasma"
    def __init__(self, columns=MATRIX_COLUMNS, rows=MATRIX_ROWS):
        self.columns, self.rows = columns, rows
        self.k, self.t = 1.0, 0.0
        self.coords = []
        for r in range(rows):
            line = []
            for c in range(columns):
                x, y = (c - (columns - 1) / 2) / ((columns - 1) / 2), (r - (rows - 1) / 2) / ((rows - 1) / 2)
                line.append((c, r, x, y, math.hypot(x, y), math.atan2(y, x)))
            self.coords.append(line)
        self.frame = [[(0, 0, 0)] * columns for _ in range(rows)]
    def set_speed(self, speed):
        self.k = fire_speed_factor(speed)
    def step(self, dt):
        self.t += dt * self.k
        self.frame = [[field_rgb(self.kind, *p, self.t) for p in line] for line in self.coords]
        return self.frame

class TunnelSimulation(FieldSimulation):
    kind = "tunnel"
class AuroraSimulation(FieldSimulation):
    kind = "aurora"
class PlasmaSimulation(FieldSimulation):
    kind = "plasma"
class KaleidoscopeSimulation(FieldSimulation):
    kind = "kaleidoscope"


EXTRA_SIMS = {
    "fireworks": FireworksSimulation,
    "lava": LavaSimulation,
    "stars": StarsSimulation,
    "galaxy": GalaxySimulation,
    "tunnel": TunnelSimulation,
    "aurora": AuroraSimulation,
    "plasma": PlasmaSimulation,
    "kaleidoscope": KaleidoscopeSimulation,
}



def new_picture_id():
    """Короткий уникальный id картинки (буквы и цифры) — общий для ПК и телефона."""
    alphabet = "0123456789abcdefghijklmnopqrstuvwxyz"
    n = int(time.time() * 1000)
    out = ""
    while n:
        n, k = divmod(n, 36)
        out = alphabet[k] + out
    return out + "".join(random.choice(alphabet) for _ in range(4))


class FireSimulation:
    """Огонь: большое пламя по центру на всю высоту, несколько маленьких
    язычков, тлеющие угли внизу и искры. Тот же алгоритм — в прошивке."""

    SMALL_FLAMES = 2 if MATRIX_COLUMNS==9 else 4
    MAX_SPARKS = 12 if MATRIX_COLUMNS==9 else 25

    def __init__(self, columns=MATRIX_COLUMNS, rows=MATRIX_ROWS):
        self.columns = columns
        self.rows = rows
        self.base_row = rows - 2  # нижний ряд (rows-1) — угли
        self.t = 0.0
        self.k = 1.0
        self.main = {
            "cx": (columns - 1) / 2.0, "h": rows + 0.5, "w": 2.5 if columns==9 else 4.4,
            "amp": 1.0 if columns==9 else 1.8, "freq": 0.55, "phase": random.uniform(0, math.tau),
            "seed": 1.0, "age": 0.0, "life": -1.0, "power": 1.0,
        }
        self.small = [self.new_small_flame(spread=True) for _ in range(self.SMALL_FLAMES)]
        self.sparks = []
        self.frame = [[(0, 0, 0)] * columns for _ in range(rows)]

    def set_speed(self, speed):
        self.k = fire_speed_factor(speed)

    def new_small_flame(self, spread=False):
        if random.random() < 0.5:
            cx = random.uniform(1.0, 2.8) if self.columns==9 else random.uniform(2.0, 5.5)
        else:
            cx = random.uniform(self.columns-3.5,self.columns-1.5) if self.columns==9 else random.uniform(self.columns - 6.5, self.columns - 3.0)
        life = random.uniform(3.0, 7.0)
        return {
            "cx": cx, "h": random.uniform(5.0, 10.0), "w": random.uniform(.9,1.5) if self.columns==9 else random.uniform(1.3,2.2),
            "amp": random.uniform(0.5, 1.1), "freq": random.uniform(0.8, 1.3),
            "phase": random.uniform(0, math.tau), "seed": random.uniform(2.0, 100.0),
            "age": random.uniform(0.0, life) if spread else 0.0, "life": life,
            "power": random.uniform(0.55, 0.72),
        }

    @staticmethod
    def growth(flame):
        if flame["life"] < 0:
            return 1.0
        g = min(1.0, flame["age"] / 0.8, (flame["life"] - flame["age"]) / 1.0)
        return max(0.0, g)

    def flame_height(self, flame, g):
        t = self.t
        return flame["h"] * g * (0.85 + 0.15 * fire_noise(t * 2.0, flame["seed"] * 7.1))

    def flame_center(self, flame, h, y):
        t = self.t
        w2 = math.tau * flame["freq"] * t + flame["phase"]
        sway = flame["amp"] * (y ** 1.5 * math.sin(w2) + 0.45 * y * y * math.sin(w2 * 2.3 + 1.3))
        sway += (fire_noise(t * 1.7, h * 0.35 + flame["seed"]) - 0.5) * 1.2 * y
        return flame["cx"] + sway

    def step(self, dt):
        dt *= self.k
        self.t += dt
        t = self.t
        cols, rows, base = self.columns, self.rows, self.base_row

        for i, flame in enumerate(self.small):
            flame["age"] += dt
            if flame["age"] >= flame["life"]:
                self.small[i] = self.new_small_flame()

        heat = [[0.0] * cols for _ in range(rows)]
        for flame in [self.main] + self.small:
            g = self.growth(flame)
            if g <= 0.01:
                continue
            flick = 0.88 + 0.24 * fire_noise(t * 3.5, flame["seed"] * 13.7)
            height = self.flame_height(flame, g)
            width = flame["w"] * (0.55 + 0.45 * g)
            for h in range(base + 1):
                y = h / height
                if y >= 1.12:
                    break
                center = self.flame_center(flame, h, y)
                half = width * max(0.0, 1.0 - y) ** 0.6 * (1.0 + 0.45 * y * (1.0 - y)) + 0.6
                vert = (0.5 + 0.42 * min(y, 0.7) / 0.7) * max(0.0, min(1.0, (1.12 - y) / 0.32))
                r = base - h
                c0 = max(0, int(center - half) - 1)
                c1 = min(cols - 1, int(center + half) + 1)
                for c in range(c0, c1 + 1):
                    d = abs(c - center) / half
                    if d >= 1.0:
                        continue
                    val = (1.0 - d * d) ** 1.4 * vert * flick * flame["power"]
                    old = heat[r][c]
                    heat[r][c] = old + val - old * val

        # турбулентность: шум «ползёт» вверх — пламя лижет и подмигивает
        frame = [[(0, 0, 0)] * cols for _ in range(rows)]
        for r in range(base + 1):
            y_rel = (base - r) / base
            for c in range(cols):
                v = heat[r][c]
                if v <= 0.0:
                    continue
                n = fire_noise(c * 0.55, r * 0.45 + t * 3.2)
                v *= 1.0 + (n - 0.5) * (0.7 + 0.9 * y_rel)
                frame[r][c] = fire_palette(min(1.0, v))

        # угли: коричневые, медленно тлеют, ярче под главным пламенем
        for c in range(cols):
            n1 = fire_noise(c * 0.8, t * 0.7 + 40.0)
            n2 = fire_noise(c * 2.1 + 11.0, t * 1.9)
            glow = 0.35 + 0.45 * n1 + 0.2 * n2
            near = max(0.0, 1.0 - abs(c - self.main["cx"]) / 11.0)
            glow = min(1.0, glow * (0.65 + 0.45 * near)) ** 1.4
            coal = (8 + 50 * glow, 1 + 7 * glow, 0)
            frame[rows - 1][c] = coal
            fr, fg, fb = frame[base][c]
            frame[base][c] = (max(fr, coal[0] * 0.45), max(fg, coal[1] * 0.45), max(fb, coal[2] * 0.45))

        # искры
        if len(self.sparks) < self.MAX_SPARKS and random.random() < 7.5 * dt:
            alive = [f for f in self.small if self.growth(f) > 0.5]
            flame = self.main if (not alive or random.random() < 0.65) else random.choice(alive)
            height = self.flame_height(flame, self.growth(flame))
            hy = random.uniform(0.45, 0.9) * height
            y_rel = min(1.0, hy / height)
            self.sparks.append({
                "x": self.flame_center(flame, int(hy), y_rel) + random.uniform(-1.0, 1.0),
                "y": base - hy, "vx": random.uniform(-1.2, 1.2), "vy": random.uniform(5.0, 9.0),
                "age": 0.0, "life": random.uniform(0.5, 1.2), "wob": random.uniform(0, math.tau),
            })
        alive_sparks = []
        for s in self.sparks:
            s["age"] += dt
            s["x"] += (s["vx"] + math.sin(s["age"] * 7.0 + s["wob"])) * dt
            s["y"] -= s["vy"] * dt
            s["vy"] *= 1.0 - 0.6 * dt
            if s["age"] >= s["life"] or s["y"] < -1.0:
                continue
            alive_sparks.append(s)
            rr = int(round(s["y"]))
            cc = int(round(s["x"]))
            if 0 <= rr < rows and 0 <= cc < cols:
                a = 1.0 - s["age"] / s["life"]
                m = 0.35 + 0.65 * a
                sr, sg, sb = (120 + 135 * a) * m, (12 + 100 * a) * m, 10 * a * m
                fr, fg, fb = frame[rr][cc]
                frame[rr][cc] = (max(fr, sr), max(fg, sg), max(fb, sb))
        self.sparks = alive_sparks
        self.frame = frame
        return frame



class UiCall(QObject):
    """Вызов функции в UI-потоке из фонового потока."""
    call = pyqtSignal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.call.connect(lambda f: f())


def run_in_thread(work, done, invoker):
    """work() в фоне, done(result) — в UI-потоке."""
    def target():
        try:
            result = work()
        except Exception as error:  # noqa: BLE001
            result = error
        invoker.call.emit(lambda: done(result))
    threading.Thread(target=target, daemon=True).start()


# Direct LAN peers use their own sockets; no messages are routed through ESP.
PEER_PORT = 45455
PEER_LIMIT = 4 * 1024 * 1024

def peer_valid(key, value):
    import re
    if not isinstance(key, str) or len(key) > 100: return False
    modes = [m[0] for m in MODE_INFO]
    integer = lambda v, a, b: type(v) is int and a <= v <= b
    rows = lambda v: isinstance(v, list) and len(v) == MATRIX_ROWS and all(isinstance(r, str) and re.fullmatch(r"[0-9a-fA-F]{%d}" % (MATRIX_COLUMNS*6), r) for r in v)
    if key.startswith('picture:'):
        return bool(re.fullmatch(r'[A-Za-z0-9_-]{1,80}',key[8:])) and (value is None or isinstance(value,dict) and value.get('id')==key[8:] and isinstance(value.get('name'),str) and len(value['name'])<=120 and integer(value.get('t'),0,9007199254740991) and rows(value.get('rows')))
    if key.startswith('scenario:'):
        return bool(re.fullmatch(r'[A-Za-z0-9_-]{1,80}',key[9:])) and (value is None or isinstance(value,dict) and value.get('mode') in modes+['random'] and type(value.get('enabled')) is bool and integer(value.get('days'),0,127) and bool(re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',str(value.get('on')))) and (value.get('off')=='' or bool(re.fullmatch(r'(?:[01]\d|2[0-3]):[0-5]\d',str(value.get('off'))))))
    if key.startswith('speed:'): return key[6:] in modes and integer(value,1,100)
    if key.startswith('color:'): return key[6:] in [str(i) for i in range(9)] and isinstance(value,str) and (value=='' or bool(re.fullmatch(r'#[0-9A-Fa-f]{6}',value)))
    if key == 'brightness': return integer(value,5,100)
    if key in ['setting:night','setting:startLast']: return type(value) is bool
    if key == 'setting:timezone': return value in TIMEZONES
    if key == 'mode': return isinstance(value,dict) and value.get('key') in modes+['off'] and type(value.get('random')) is bool and integer(value.get('every'),1,1440)
    return False

class PeerLedger:
    def __init__(self, node=None, records=None):
        import uuid
        self.node = node or uuid.uuid4().hex
        self.records = {}; self.clock = 0
        self.merge(records or {})
    @staticmethod
    def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=False)
    def put(self, key, value, seed=False):
        if not peer_valid(key,value): return False
        old = self.records.get(key)
        if old and self.canonical(old['v']) == self.canonical(value): return False
        self.clock = max(self.clock + 1, int(time.time()*1000))
        self.records[key] = {'s':[0 if seed else self.clock,self.node], 'v':json.loads(json.dumps(value))}
        return True
    def merge(self, incoming):
        import re
        accepted=[]
        if not isinstance(incoming,dict) or len(incoming)>2048: return accepted
        for k, r in incoming.items():
            if not isinstance(r,dict) or 'v' not in r or not isinstance(r.get('s'),list) or len(r['s'])!=2:continue
            s=r['s']
            if type(s[0]) is not int or not 0<=s[0]<=9007199254740991 or not isinstance(s[1],str) or not re.fullmatch('[a-f0-9]{32}',s[1]) or not peer_valid(k,r.get('v')):continue
            old=self.records.get(k)
            if old is None or tuple(s)>tuple(old['s']):
                self.records[k]=json.loads(json.dumps(r));accepted.append(k);self.clock=max(self.clock,s[0])
        return accepted

def peer_scenario_id(value):
    # Same byte-free FNV-1a over this ASCII canonical tuple in JavaScript.
    a=json.dumps([value['enabled'],value['mode'],value['on'],value['off'],value['days']],separators=(',',':'))
    h=2166136261
    for c in a: h=((h^ord(c))*16777619)&0xffffffff
    return 's'+format(h,'08x')

class PeerTransport(QObject):
    received = pyqtSignal(dict)
    def __init__(self, node, parent=None):
        super().__init__(parent)
        import socket,hashlib
        self.node=node;self.running=True;self.lock=threading.Lock();self.records={};self.revision='';self.notify=True;self.error='';self.peers={};self.last_push=0
        self.socket_module=socket;self.addresses={'255.255.255.255'}
        try:
            from PyQt6.QtNetwork import QNetworkInterface
            for iface in QNetworkInterface.allInterfaces():
                for entry in iface.addressEntries():
                    address=entry.broadcast().toString()
                    if address:self.addresses.add(address)
        except Exception:pass
        try:
            self.server=socket.socket();self.server.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);self.server.bind(('0.0.0.0',0));self.server.listen(4);self.server.settimeout(.5);self.port=self.server.getsockname()[1]
            self.udp=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);self.udp.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1);self.udp.setsockopt(socket.SOL_SOCKET,socket.SO_BROADCAST,1);self.udp.bind(('',PEER_PORT));self.udp.settimeout(.05)
            threading.Thread(target=self.serve,daemon=True).start();threading.Thread(target=self.discover,daemon=True).start()
        except OSError as e:self.error=str(e);self.running=False
    def update(self,records):
        import hashlib
        data=json.dumps(records,separators=(',',':'),ensure_ascii=False).encode()
        if len(data)>PEER_LIMIT:return
        with self.lock:self.records=json.loads(data);self.revision=hashlib.sha256(data).hexdigest();self.notify=True
    @staticmethod
    def private(ip):
        import ipaddress
        try:
            a=ipaddress.ip_address(ip);return a.version==4 and (ip.startswith('10.') or ip.startswith('192.168.') or ip.startswith('169.254.') or ip=='127.0.0.1' or (ip.startswith('172.') and 16<=int(ip.split('.')[1])<=31))
        except ValueError:return False
    @staticmethod
    def line(sock, limit):
        b=bytearray()
        while b'\n' not in b:
            p=sock.recv(min(16384,limit+1-len(b)))
            if not p:raise OSError('incomplete peer packet')
            b.extend(p)
            if len(b)>limit:raise OSError('oversized peer packet')
        return json.loads(bytes(b).split(b'\n',1)[0])
    def serve(self):
        while self.running:
            try:c,addr=self.server.accept()
            except OSError:continue
            try:
                c.settimeout(2)
                if not self.private(addr[0]):continue
                q=self.line(c,262144)
                if q.get('p')!=2 or not isinstance(q.get('known'),dict):continue
                with self.lock:r={k:v for k,v in self.records.items() if q['known'].get(k)!=v['s']};rev=self.revision
                c.sendall((json.dumps({'p':2,'rev':rev,'records':r},separators=(',',':'),ensure_ascii=False)+'\n').encode())
            except (OSError,ValueError,TypeError,AttributeError):pass
            finally:c.close()
    def pull(self,ip,port):
        try:
            with self.lock:known={k:r['s'] for k,r in self.records.items()}
            with self.socket_module.create_connection((ip,port),timeout=2) as c:
                c.settimeout(3);c.sendall((json.dumps({'p':2,'known':known},separators=(',',':'))+'\n').encode());r=self.line(c,PEER_LIMIT)
            if r.get('p')==2 and isinstance(r.get('records'),dict):self.received.emit(r['records']);return r.get('rev')
        except (OSError,ValueError,TypeError,AttributeError):pass
        return None
    def discover(self):
        seen={};next_announce=0;last_announce=0
        while self.running:
            now=time.monotonic()
            if now>=next_announce or self.notify and now-last_announce>=.1:
                with self.lock:rev=self.revision
                msg=('LEDPEER2|'+json.dumps({'id':self.node,'port':self.port,'rev':rev},separators=(',',':'))).encode()
                for address in self.addresses:
                    try:self.udp.sendto(msg,(address,PEER_PORT))
                    except OSError:pass
                next_announce=now+2;last_announce=now;self.notify=False
            try:
                data,(ip,_)=self.udp.recvfrom(1024)
                if not self.private(ip) or not data.startswith(b'LEDPEER2|'):continue
                q=json.loads(data[9:]);ident=q.get('id');port=q.get('port');rev=q.get('rev')
                if not isinstance(ident,str) or ident==self.node or len(ident)!=32 or type(port) is not int or not 1<=port<=65535 or not isinstance(rev,str) or len(rev)>64:continue
                self.peers[ident]=now
                if seen.get(ident)!=rev:
                    got=self.pull(ip,port)
                    if got is not None:seen[ident]=got
            except (OSError,ValueError,TypeError,AttributeError):pass
    def close(self):
        self.running=False
        for name in ['udp','server']:
            try:getattr(self,name).close()
            except Exception:pass


class EspLink(QObject):
    discovered = pyqtSignal(str, str)
    state_changed = pyqtSignal(bool)
    wifi_result = pyqtSignal(bool, str)
    state_received = pyqtSignal(dict)

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings
        # облако и сопряжение убраны — чистим старые записи
        for key in ("paired_id", "paired_key", "paired_name", "auto_pair"):
            settings.remove(key)

        self.devices = {}
        self.device_ip = None
        self.device_name = None
        self.local_online = False
        self._reported_online = False
        self.last_seen = 0.0
        self.last_rtt_ms = None
        self.ping_sent_at = 0.0
        self._pending_online = False
        self._pending_count = 0
        self.state = {}
        self.drawing = False       # пока рисуешь — состояние не спрашиваем
        self.quiet_until = 0.0

        self.udp = QUdpSocket(self)
        bind_ok = self.udp.bind(
            QHostAddress.SpecialAddress.AnyIPv4,
            DISCOVERY_PORT,
            QUdpSocket.BindFlag.ShareAddress
            | QUdpSocket.BindFlag.ReuseAddressHint,
        )
        if not bind_ok:
            self.bind_error = (
                "Не удалось занять UDP-порт 45454. "
                "Возможно, запущена вторая копия программы."
            )
        else:
            self.bind_error = None
            self.udp.readyRead.connect(self.read_datagrams)

        self.ping_timer = QTimer(self)
        self.ping_timer.setInterval(PING_INTERVAL_MS)
        self.ping_timer.timeout.connect(self.send_ping)
        self.ping_timer.start()

        self.watchdog_timer = QTimer(self)
        self.watchdog_timer.setInterval(400)
        self.watchdog_timer.timeout.connect(self.check_connection)
        self.watchdog_timer.start()

        # состояние гирлянды (режим, прошивка…) — спрашиваем раз в 5 секунд
        self.state_timer = QTimer(self)
        self.state_timer.setInterval(5000)
        self.state_timer.timeout.connect(self.poll_state)
        self.state_timer.start()

    # ---------- связь ----------
    @property
    def is_online(self):
        return self.local_online

    def update_link(self):
        online = self.is_online
        if online != self._reported_online:
            self._reported_online = online
            self.state_changed.emit(online)

    def _set_state(self, text):
        try:
            data = json.loads(text)
        except (TypeError, ValueError):
            return
        if isinstance(data, dict):
            if MATRIX_PROFILE=='esp32c3-9x20' and (data.get('model')!=MATRIX_PROFILE or data.get('cols')!=MATRIX_COLUMNS or data.get('rows')!=MATRIX_ROWS):return
            self.state = data
            self.state_received.emit(data)

    def poll_state(self):
        if self.drawing or time.monotonic() < self.quiet_until:
            return
        if self.local_online:
            self.request({"type": "state"}, lambda r: r and r.startswith("{") and self._set_state(r))

    def send_udp(self, payload_dict):
        """Мгновенная команда по UDP."""
        if self.local_online and self.device_ip:
            payload = json.dumps(payload_dict, separators=(",", ":"))
            self.udp.writeDatagram(payload.encode("utf-8"), QHostAddress(self.device_ip), DISCOVERY_PORT)

    def send_tcp(self, payload_dict):
        """Команда по TCP без ожидания ответа."""
        if self.local_online and self.device_ip:
            payload = json.dumps(payload_dict)
            sock = QTcpSocket(self)
            sock.connected.connect(lambda: sock.write((payload + "\n").encode("utf-8")))
            sock.bytesWritten.connect(lambda _n: QTimer.singleShot(150, sock.deleteLater))
            sock.errorOccurred.connect(lambda _: sock.deleteLater())
            sock.connectToHost(self.device_ip, COMMAND_PORT)
            QTimer.singleShot(3000, sock.deleteLater)

    def request(self, payload_dict, callback, timeout_ms=4000, ip=None):
        """Команда с ответом: callback(строка ответа или None)."""
        if ip is None and not self.local_online:
            callback(None)
            return
        host = ip or self.device_ip
        if not host:
            callback(None)
            return
        sock = QTcpSocket(self)
        buf = bytearray()
        state = {"done": False}

        def finish(reply):
            if state["done"]:
                return
            state["done"] = True
            sock.abort()
            sock.deleteLater()
            callback(reply)

        def on_read():
            buf.extend(bytes(sock.readAll()))
            if b"\n" in buf:
                finish(bytes(buf).split(b"\n", 1)[0].decode("utf-8", "ignore").strip())

        sock.connected.connect(lambda: sock.write((json.dumps(payload_dict) + "\n").encode("utf-8")))
        sock.readyRead.connect(on_read)
        sock.disconnected.connect(lambda: finish(bytes(buf).decode("utf-8", "ignore").strip() or None))
        sock.errorOccurred.connect(lambda _e: finish(bytes(buf).decode("utf-8", "ignore").strip() or None))
        sock.connectToHost(host, COMMAND_PORT)
        QTimer.singleShot(timeout_ms, lambda: finish(None))

    def read_datagrams(self):
        while self.udp.hasPendingDatagrams():
            size = self.udp.pendingDatagramSize()
            datagram, sender_address, _ = self.udp.readDatagram(size)
            message = bytes(datagram).decode("utf-8", errors="ignore").strip()

            ip=sender_address.toString()
            device=decode_discovery(message,ip)
            if device:
                self.devices[device['profile']]=device
                if device['profile']==MATRIX_PROFILE:
                    changed=self.device_ip!=ip or self.device_name!=device['name']
                    self.device_ip=ip;self.device_name=device['name'];self.last_seen=time.monotonic()
                    if changed:self.discovered.emit(self.device_name,ip)
            if (MATRIX_PROFILE=='esp32-19x20' and message=='PONG' and ip==self.device_ip) or (device and device['profile']==MATRIX_PROFILE):
                if self.ping_sent_at:
                    self.last_rtt_ms=max(1,int((time.monotonic()-self.ping_sent_at)*1000));self.ping_sent_at=0.0
                self.last_seen=time.monotonic()

            self.check_connection()

    def check_connection(self):
        raw_online = (
            self.device_ip is not None
            and time.monotonic() - self.last_seen <= OFFLINE_TIMEOUT_S
        )

        if raw_online != self._pending_online:
            self._pending_online = raw_online
            self._pending_count = 1
        else:
            self._pending_count += 1

        if self._pending_count >= 2 and raw_online != self.local_online:
            self.local_online = raw_online
            self._pending_count = 0
        self.update_link()

    def send_ping(self):
        self.udp.writeDatagram(PING_TEXT,QHostAddress('255.255.255.255'),DISCOVERY_PORT)
        if self.device_ip is None:
            return

        self.ping_sent_at = time.monotonic()
        self.udp.writeDatagram(
            PING_TEXT,
            QHostAddress(self.device_ip),
            DISCOVERY_PORT,
        )

    def send_wifi_credentials_async(self, ssid, password):
        """Асинхронная отправка Wi-Fi-настроек (не блокирует UI).
        Результат приходит сигналом wifi_result(success, message)."""
        if self.device_ip is None or not self.local_online:
            self.wifi_result.emit(False, "Гирлянда не найдена")
            return

        payload = json.dumps(
            {"ssid": ssid, "password": password},
            separators=(",", ":"),
        )

        tcp_socket = QTcpSocket(self)
        state = {"done": False}

        def finish(success, message):
            if state["done"]:
                return
            state["done"] = True
            try:
                tcp_socket.readyRead.disconnect()
                tcp_socket.errorOccurred.disconnect()
            except TypeError:
                pass
            tcp_socket.abort()
            tcp_socket.deleteLater()
            self.wifi_result.emit(success, message)

        def on_connected():
            tcp_socket.write((payload + "\n").encode("utf-8"))

        def on_ready_read():
            reply = bytes(tcp_socket.readAll()).decode(
                "utf-8",
                errors="ignore",
            ).strip()
            if reply == "OK":
                finish(True, "Гирлянда приняла настройки и подключается к Wi-Fi")
            else:
                finish(False, f"Ответ гирлянды: {reply or 'нет ответа'}")

        def on_error(_error):
            finish(False, "Нет связи с гирляндой")

        tcp_socket.connected.connect(on_connected)
        tcp_socket.readyRead.connect(on_ready_read)
        tcp_socket.errorOccurred.connect(on_error)
        tcp_socket.connectToHost(
            QHostAddress(self.device_ip),
            COMMAND_PORT,
        )
        QTimer.singleShot(
            8000,
            lambda: finish(False, "Гирлянда не ответила вовремя"),
        )


class LedMatrix(QWidget):
    """Матрица 19x20 для рисования. Перерисовывает только изменённые
    диоды, а не всё поле — так рисование не тормозит."""

    pixel_painted = pyqtSignal(int, int, QColor)
    stroke_started = pyqtSignal()
    stroke_finished = pyqtSignal()
    color_picked = pyqtSignal(QColor)

    GAP = 4
    PAD = 14

    def __init__(self, columns=MATRIX_COLUMNS, rows=MATRIX_ROWS, parent=None):
        super().__init__(parent)

        self.columns = columns
        self.rows = rows
        self.active_color = QColor("#FFFFFF")
        self.off_color = QColor(DOT_OFF)
        self.pixels = [
            [QColor(self.off_color) for _ in range(columns)]
            for _ in range(rows)
        ]

        self.last_paint_position = None
        self.eraser_mode = False
        self.picker_mode = False

        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.CrossCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent)

        # волна: новые цвета расходятся по матрице, диоды «вспыхивают»
        self.wave_old = None
        self.wave_dist = None
        self.wave_front = 0.0
        self.wave_max = 1.0
        self.wave_anim = QVariantAnimation(self)
        self.wave_anim.setDuration(520)
        self.wave_anim.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self.wave_anim.valueChanged.connect(self._on_wave)
        self.wave_anim.finished.connect(self.stop_wave)

    def animate_to(self, new_pixels, origin="center"):
        """Записывает новые цвета сразу, а на экране показывает их волной."""
        self.stop_wave()
        old = self.pixels
        self.pixels = [[QColor(c) for c in row] for row in new_pixels]
        if not self.isVisible():
            self.update()
            return
        if origin == "top":
            dist = [[float(r) for _c in range(self.columns)] for r in range(self.rows)]
        elif origin == "corner":
            dist = [[(r + c) * 0.7 for c in range(self.columns)] for r in range(self.rows)]
        else:
            cr, cc = (self.rows - 1) / 2, (self.columns - 1) / 2
            dist = [[math.hypot(r - cr, c - cc) for c in range(self.columns)] for r in range(self.rows)]
        self.wave_old = old
        self.wave_dist = dist
        self.wave_max = max(max(row) for row in dist) + 2.5
        self.wave_front = 0.0
        self.wave_anim.setStartValue(0.0)
        self.wave_anim.setEndValue(self.wave_max)
        self.wave_anim.start()

    def _on_wave(self, value):
        self.wave_front = float(value)
        self.update()

    def stop_wave(self):
        if self.wave_old is not None:
            self.wave_anim.stop()
            self.wave_old = None
            self.wave_dist = None
            self.update()

    def set_active_color(self, color):
        self.active_color = QColor(color)

    def is_off(self, color):
        return color.name().upper() in OFF_HEXES or color.name() == "#000000"

    def fill_all(self, color, origin="corner"):
        self.animate_to([[color] * self.columns for _ in range(self.rows)], origin)

    def clear(self):
        self.fill_all(self.off_color, origin="center")

    def grid_values(self):
        gap = self.GAP
        pad = self.PAD
        diameter = min(
            (self.width() - 2 * pad - gap * (self.columns - 1)) / self.columns,
            (self.height() - 2 * pad - gap * (self.rows - 1)) / self.rows,
        )
        grid_width = self.columns * diameter + (self.columns - 1) * gap
        grid_height = self.rows * diameter + (self.rows - 1) * gap
        left = (self.width() - grid_width) / 2
        top = (self.height() - grid_height) / 2
        return diameter, gap, left, top

    def cell_rect(self, row, column):
        diameter, gap, left, top = self.grid_values()
        x = left + column * (diameter + gap)
        y = top + row * (diameter + gap)
        return QRect(int(x) - 1, int(y) - 1, int(diameter) + 3, int(diameter) + 3)

    def cell_at(self, position):
        diameter, gap, left, top = self.grid_values()
        column = int((position.x() - left) // (diameter + gap))
        row = int((position.y() - top) // (diameter + gap))
        if 0 <= column < self.columns and 0 <= row < self.rows:
            return row, column
        return None

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.fillRect(event.rect(), QColor("#000000"))
        painter.setPen(Qt.PenStyle.NoPen)

        diameter, gap, left, top = self.grid_values()
        radius = diameter / 2
        dirty = event.rect()
        if self.wave_old is not None:
            front = self.wave_front
            for row in range(self.rows):
                cy = top + row * (diameter + gap) + radius
                for column in range(self.columns):
                    cx = left + column * (diameter + gap) + radius
                    d = self.wave_dist[row][column]
                    if d > front:
                        painter.setBrush(self.wave_old[row][column])
                        painter.drawEllipse(QPointF(cx, cy), radius, radius)
                        continue
                    behind = front - d
                    color = self.pixels[row][column]
                    scale = 1.0
                    if behind < 2.0:
                        # гребень волны: диод чуть больше и ярче
                        k = 1.0 - behind / 2.0
                        scale = 1.0 + 0.28 * k
                        color = mix_color(color, QColor("#FFFFFF"), 0.35 * k)
                    painter.setBrush(color)
                    painter.drawEllipse(QPointF(cx, cy), radius * scale, radius * scale)
            painter.end()
            return
        for row in range(self.rows):
            cy = top + row * (diameter + gap) + radius
            if cy + radius < dirty.top() or cy - radius > dirty.bottom():
                continue
            for column in range(self.columns):
                cx = left + column * (diameter + gap) + radius
                if cx + radius < dirty.left() or cx - radius > dirty.right():
                    continue
                painter.setBrush(self.pixels[row][column])
                painter.drawEllipse(QPointF(cx, cy), radius, radius)
        painter.end()

    def paint_at(self, position):
        cell = self.cell_at(position)
        if cell is None:
            return
        row, column = cell
        target = self.off_color if self.eraser_mode else self.active_color
        if self.pixels[row][column] != target:
            self.pixels[row][column] = QColor(target)
            self.update(self.cell_rect(row, column))
            self.pixel_painted.emit(row, column, target)

    def mousePressEvent(self, event):
        if event.button() != Qt.MouseButton.LeftButton:
            return
        self.stop_wave()
        if self.picker_mode:
            # пипетка: берём цвет диода, а не рисуем
            cell = self.cell_at(event.position())
            if cell is not None:
                color = self.pixels[cell[0]][cell[1]]
                if not self.is_off(color):
                    self.color_picked.emit(QColor(color))
            return
        self.stroke_started.emit()
        self.last_paint_position = event.position()
        self.paint_at(event.position())

    def mouseMoveEvent(self, event):
        if self.picker_mode or not (event.buttons() & Qt.MouseButton.LeftButton):
            return
        start = self.last_paint_position or event.position()
        current = event.position()
        distance = math.hypot(current.x() - start.x(), current.y() - start.y())
        steps = max(1, int(distance // 3))
        for i in range(1, steps + 1):
            t = i / steps
            self.paint_at(
                QPointF(
                    start.x() + (current.x() - start.x()) * t,
                    start.y() + (current.y() - start.y()) * t,
                )
            )
        self.last_paint_position = current

    def mouseReleaseEvent(self, event):
        if self.last_paint_position is not None:
            self.stroke_finished.emit()
        self.last_paint_position = None


class ColorWheel(QWidget):
    color_changed = pyqtSignal(QColor)

    def __init__(self, diameter=180, parent=None):
        super().__init__(parent)

        self.diameter = diameter
        self.hue = 356 / 360
        self.saturation = 0.83
        self.value = 1.0
        self._wheel_image = None

        self.setFixedSize(diameter, diameter)
        self.setCursor(Qt.CursorShape.ArrowCursor)
        self.setMouseTracking(True)

    def set_diameter(self, diameter):
        self.diameter = diameter
        self._wheel_image = None
        self.setFixedSize(diameter, diameter)
        self.update()

    def current_color(self):
        return QColor.fromHsvF(
            min(max(self.hue, 0.0), 1.0),
            min(max(self.saturation, 0.0), 1.0),
            min(max(self.value, 0.0), 1.0),
        )

    def set_color_silent(self, color):
        hue, saturation, value, _ = color.getHsvF()

        if hue is not None and hue >= 0:
            self.hue = hue
        if saturation is not None:
            self.saturation = saturation
        if value is not None:
            self.value = value

        self.update()

    def _build_wheel_image(self):
        size = max(2, int(self.diameter * self.devicePixelRatioF()))
        center = size / 2
        radius = size / 2

        image = QImage(
            size,
            size,
            QImage.Format.Format_ARGB32_Premultiplied,
        )
        image.fill(Qt.GlobalColor.transparent)

        painter = QPainter(image)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        clip = QPainterPath()
        clip.addEllipse(0, 0, size, size)
        painter.setClipPath(clip)

        painter.fillRect(0, 0, size, size, QColor("#FFFFFF"))

        hues = QConicalGradient(center, center, 0)
        stops = [
            (0.00, "#FF0000"),
            (1 / 6, "#FFFF00"),
            (2 / 6, "#00FF00"),
            (3 / 6, "#00FFFF"),
            (4 / 6, "#0000FF"),
            (5 / 6, "#FF00FF"),
            (1.00, "#FF0000"),
        ]
        for position, hex_color in stops:
            hues.setColorAt(position, QColor(hex_color))

        painter.fillRect(0, 0, size, size, hues)

        fade = QRadialGradient(center, center, radius)
        fade.setColorAt(0.0, QColor(255, 255, 255, 255))
        fade.setColorAt(0.55, QColor(255, 255, 255, 190))
        fade.setColorAt(0.85, QColor(255, 255, 255, 60))
        fade.setColorAt(1.0, QColor(255, 255, 255, 0))

        painter.fillRect(0, 0, size, size, fade)
        painter.end()

        self._wheel_image = image

    def _cursor_position(self):
        angle = self.hue * 2 * math.pi
        radius = self.saturation * (self.diameter / 2 - 2)

        return QPointF(
            self.diameter / 2 + math.cos(angle) * radius,
            self.diameter / 2 - math.sin(angle) * radius,
        )

    def paintEvent(self, event):
        if (
            self._wheel_image is None
            or self._wheel_image.width()
            != int(self.diameter * self.devicePixelRatioF())
        ):
            self._build_wheel_image()

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.drawImage(
            QRect(0, 0, self.diameter, self.diameter),
            self._wheel_image,
        )

        cursor = self._cursor_position()
        cursor_pen = QPen(QColor("#FFFFFF"), 2)
        painter.setPen(cursor_pen)
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawEllipse(cursor, 6, 6)

        painter.setPen(QPen(QColor("#11161E"), 1))
        painter.drawEllipse(cursor, 8, 8)

    def _apply_pick(self, position):
        center = self.diameter / 2
        dx = position.x() - center
        dy = position.y() - center
        distance = math.hypot(dx, dy)
        max_radius = self.diameter / 2 - 2

        if distance > max_radius:
            return

        angle = math.degrees(math.atan2(-dy, dx)) % 360

        self.hue = angle / 360
        self.saturation = distance / max_radius

        self.update()
        self.color_changed.emit(self.current_color())

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._apply_pick(event.position())

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.MouseButton.LeftButton:
            self._apply_pick(event.position())
        else:
            center = self.diameter / 2
            dx = event.position().x() - center
            dy = event.position().y() - center
            if math.hypot(dx, dy) <= self.diameter / 2 - 2:
                self.setCursor(Qt.CursorShape.CrossCursor)
            else:
                self.setCursor(Qt.CursorShape.ArrowCursor)


class ModePreviewWidget(QWidget):
    LED_COLUMNS = MATRIX_COLUMNS
    LED_ROWS = 20

    def __init__(self, mode_key, parent=None):
        super().__init__(parent)
        self.mode_key = mode_key
        # новые дизайны: цвет выключенного диода, промежуток, свечение
        self.off_hex = DOT_OFF
        self.gap = 4
        self.setMinimumHeight(120)
        self.phase = 0.0
        self.flakes = []
        self.speed = 2.0
        self.fire_sim = None
        if mode_key == "snow":
            for _ in range(SNOW_FLAKES):
                self.flakes.append(self.make_flake(first=True))
        elif mode_key == "fire":
            self.fire_sim = FireSimulation(self.LED_COLUMNS, self.LED_ROWS)
        self.rain_sim = RainSimulation(self.LED_COLUMNS, self.LED_ROWS) if mode_key == "rain" else None
        sim_class = EXTRA_SIMS.get(mode_key)
        self.extra_sim = sim_class(self.LED_COLUMNS, self.LED_ROWS) if sim_class else None
        self.rainbow_t = 0.0
        self.rainbow_k = 1.0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        # запускается в showEvent: невидимые превью не крутятся впустую
        self.timer.setInterval(40)

    def make_flake(self, first=False):
        # depth — глубина: 0 = далеко (тусклый, медленный),
        # 1 = близко (яркий, быстрый). Даёт иллюзию объёма
        depth = random.uniform(0.05, 1.0)
        return {
            "x": random.uniform(-0.5, self.LED_COLUMNS - 0.5),
            "y": random.uniform(-4, self.LED_ROWS) if first else random.uniform(-3, -0.5),
            "depth": depth,
            "sway": random.uniform(0.25, 1.1),
            "phase": random.uniform(0, math.pi * 2),
        }

    def set_speed(self, speed):
        # скорость = сколько РЯДОВ в секунду пролетает ближняя снежинка:
        # ползунок 1 = 1.1 ряд/с (20 диодов за ~18 сек)
        # ползунок 100 = 4.0 ряд/с (20 диодов за ~5 сек)
        self.speed = 1.1 + (speed - 1) * (4.0 - 1.1) / 99.0
        if self.fire_sim is not None:
            self.fire_sim.set_speed(speed)
        self.rainbow_k = fire_speed_factor(speed)
        if self.rain_sim is not None:
            self.rain_sim.set_speed(speed)
        if self.extra_sim is not None:
            self.extra_sim.set_speed(speed)
        self.timer.setInterval(20)

    def tick(self):
        self.phase += 0.05
        if self.mode_key == "snow":
            dt = self.timer.interval() / 1000.0
            for flake in self.flakes:
                flake["y"] += self.speed * dt * (0.35 + 1.3 * flake["depth"])
                flake["phase"] += dt * 2.0 * flake["sway"]
            self.flakes = [f for f in self.flakes if f["y"] < self.LED_ROWS + 1]
            while len(self.flakes) < SNOW_FLAKES:
                self.flakes.append(self.make_flake())
        elif self.mode_key == "fire":
            self.fire_sim.step(self.timer.interval() / 1000.0)
        elif self.mode_key == "rain":
            self.rain_sim.step(self.timer.interval() / 1000.0)
        elif self.extra_sim is not None:
            self.extra_sim.step(self.timer.interval() / 1000.0)
        elif self.mode_key == "rainbow":
            self.rainbow_t += self.timer.interval() / 1000.0 * self.rainbow_k
        self.update()

    def showEvent(self, event):
        # анимация крутится только когда превью видно — меньше нагрузка
        self.timer.start()
        super().showEvent(event)

    def hideEvent(self, event):
        self.timer.stop()
        super().hideEvent(event)

    def led_geometry(self):
        gap = self.gap
        columns = self.LED_COLUMNS
        rows = self.LED_ROWS
        available_w = self.width() - gap * (columns + 1)
        available_h = self.height() - gap * (rows + 1)
        diameter = max(4.0, min(available_w / columns, available_h / rows))
        grid_w = columns * diameter + (columns - 1) * gap
        grid_h = rows * diameter + (rows - 1) * gap
        left = (self.width() - grid_w) / 2
        top = (self.height() - grid_h) / 2
        return diameter, gap, left, top

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        diameter, gap, left, top = self.led_geometry()
        columns = self.LED_COLUMNS
        rows = self.LED_ROWS
        cell = diameter + gap
        if self.mode_key in ("fire", "rainbow", "rain") or self.extra_sim is not None:
            brightness = None
        else:
            # снег: каждая снежинка светит яркостью по своей глубине,
            # тусклые (дальние) падают медленнее ярких (ближних)
            brightness = [[0.0] * columns for _ in range(rows)]
            for flake in self.flakes:
                fx = flake["x"] + math.sin(flake["phase"] + self.phase) * flake["sway"]
                fy = flake["y"]
                pc = int(round(fx))
                pr = int(round(fy))
                base = 0.18 + 0.82 * flake["depth"]
                for r in range(max(0, pr - 1), min(rows, pr + 2)):
                    for c in range(max(0, pc - 1), min(columns, pc + 2)):
                        distance = math.hypot(c - fx, r - fy)
                        add = max(0.0, 1.0 - distance / 1.5) * base
                        if add > brightness[r][c]:
                            brightness[r][c] = add
        off_color = QColor(self.off_hex)
        leds = []
        border_pen = QPen(Qt.PenStyle.NoPen)
        for r in range(rows):
            for c in range(columns):
                if self.mode_key in ("fire", "rain") or self.extra_sim is not None:
                    # эмуляция светодиода: диод светит линейно, а глаз
                    # видит тёмные оттенки гораздо ярче — поэтому ^0.45.
                    # Так превью выглядит как настоящая гирлянда
                    sim = self.extra_sim or (self.fire_sim if self.mode_key == "fire" else self.rain_sim)
                    led = sim.frame[r][c]
                    lifted = [255.0 * (min(255.0, v) / 255.0) ** 0.45 for v in led]
                    alpha = min(1.0, max(lifted) / 90.0)
                    color = QColor(
                        int(off_color.red() * (1 - alpha) + lifted[0] * alpha),
                        int(off_color.green() * (1 - alpha) + lifted[1] * alpha),
                        int(off_color.blue() * (1 - alpha) + lifted[2] * alpha),
                    )
                elif self.mode_key == "rainbow":
                    red, green, blue = rainbow_rgb(c, r, self.rainbow_t)
                    color = QColor(int(red), int(green), int(blue))
                elif (level := brightness[r][c]) > 0.02:
                    t = min(1.0, level)
                    if self.off_hex != "#3A4553":
                        # новые дизайны: снежинка разгорается из «чёрного»
                        color = QColor(
                            int(off_color.red() + (238 - off_color.red()) * t),
                            int(off_color.green() + (244 - off_color.green()) * t),
                            int(off_color.blue() + (255 - off_color.blue()) * t),
                        )
                    else:
                        color = QColor(int(35 + (238 - 35) * t), int(44 + (244 - 44) * t), int(58 + (255 - 58) * t))
                else:
                    color = off_color
                x = left + c * cell
                y = top + r * cell
                leds.append((x + diameter / 2, y + diameter / 2, color))
        painter.setPen(border_pen)
        for cx, cy, color in leds:
            painter.setBrush(color)
            painter.drawEllipse(QPointF(cx, cy), diameter / 2, diameter / 2)
        painter.end()


# ======================================================================
#  Интерфейс Dot Matrix
# ======================================================================

ACCENT = "#FF2B2B"
FG = "#E8E8E8"
MUTED = "#777777"
MUTED2 = "#8A8A8A"
LINE = "#2A2A2A"
LINE2 = "#3A3A3A"
MONO = "Consolas, 'Liberation Mono', 'Courier New', monospace"

CUSTOM_COUNT = 9

# чистые цвета: красный, оранжевый, жёлтый, зелёный, голубой,
# синий, фиолетовый, розовый, белый
QUICK_COLORS = [
    "#FF0000", "#FF8000", "#FFFF00", "#00FF00", "#00FFFF",
    "#0000FF", "#8000FF", "#FF00FF", "#FFFFFF",
]

MODE_INFO = [
    ("snow", "Снег", "Мягкие снежинки разной глубины"),
    ("fire", "Огонь", "Языки пламени, угли и искры"),
    ("rainbow", "Радужная волна", "Плавный перелив цветов"),
    ("rain", "Дождь", "Капли в стиле Minecraft"),
    ("fireworks", "Фейерверк", "Ракеты, вспышки и искры"),
    ("lava", "Лава-лампа", "Плавные капли лавы"),
    ("stars", "Звёздное небо", "Мерцание и падающие звёзды"),
    ("galaxy", "Галактика", "Вращающиеся спиральные рукава"),
    ('tunnel', 'Туннель', 'Яркие квадратные волны в глубину'),
    ('aurora', 'Северное сияние', 'Мягкие зелёно-бирюзовые занавесы'),
    ('plasma', 'Плазма', 'Плавные цветные потоки'),
    ('kaleidoscope', 'Калейдоскоп', 'Шесть вращающихся световых граней'),
]

MAX_SCENARIOS = 8

# случайный режим: гирлянда сама меняет режимы каждые N минут (прошивка v10+)
RANDOM_INTERVALS = [(1, "1 мин"), (5, "5 мин"), (10, "10 мин"), (15, "15 мин"), (30, "30 мин"),
                    (60, "1 час"), (120, "2 часа"), (180, "3 часа")]


def mode_title(key):
    if key == "random":
        return "Случайный"
    return next((t for k, t, _d in MODE_INFO if k == key), key)
WEEKDAYS = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]
WEEKDAYS_FULL = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]
TIME_SYNC_MS = 15 * 60 * 1000   # время на гирлянду — раз в 15 минут

TIMEZONES = ["UTC+3", "UTC+5", "UTC+8", "UTC+0", "UTC+6", "UTC+7", "UTC+12"]

ICON_PATHS = {
    "draw": '<path d="M4 20l4-1 11-11-3-3L5 16z"/><path d="M14 6l3 3"/>',
    "modes": '<path d="M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z"/><path d="M19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z"/>',
    "scen": '<path d="M5 4h14v16H5z"/><path d="M9 9l6 3-6 3z"/>',
    "wifi": '<path d="M2 9a15 15 0 0 1 20 0"/><path d="M5 12.5a10 10 0 0 1 14 0"/><path d="M8.5 16a5 5 0 0 1 7 0"/><circle cx="12" cy="19" r="1"/>',
    "eraser": '<path d="M7 20h13"/><path d="M4 15l9-9 6 6-7 7H8z"/>',
    "fill": '<path d="M5 11l7-7 7 7-7 7z"/><path d="M20 15s2 2.5 2 4a2 2 0 0 1-4 0c0-1.5 2-4 2-4z"/>',
    "trash": '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/>',
    "shuffle": '<path d="M3 7h3c5 0 7 10 12 10h3"/><path d="M3 17h3c2 0 3.5-1.6 4.7-3.5M13.3 9.5C14.5 8.1 16 7 18 7h3"/><path d="M18 4l3 3-3 3M18 14l3 3-3 3"/>',
    "pick": '<path d="M14 4l6 6-9 9H5v-6z"/>',
    "sun": '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M5 19l1.5-1.5M17.5 6.5L19 5"/>',
    "clock": '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    "upd": '<path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v4h-4"/>',
    "chip": '<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
    "moon": '<path d="M20 14A8 8 0 1 1 10 4a7 7 0 0 0 10 10z"/>',
    "plus": '<path d="M12 5v14M5 12h14"/>',
    "undo": '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
    "redo": '<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
    "play": '<path d="M7 4l13 8-13 8z"/>',
    "eye": '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    "eye_off": '<path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/><path d="M4 20L20 4"/>',
}

_PIXMAP_CACHE = {}


def svg_pixmap(name, color, size=20, stroke=1.8):
    key = (name, color, size, stroke)
    if key in _PIXMAP_CACHE:
        return _PIXMAP_CACHE[key]
    pixmap = QPixmap(size * 2, size * 2)
    pixmap.setDevicePixelRatio(2.0)
    pixmap.fill(Qt.GlobalColor.transparent)
    if QSvgRenderer is not None and name in ICON_PATHS:
        svg = (
            f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" '
            f'fill="none" stroke="{color}" stroke-width="{stroke}" '
            f'stroke-linecap="round" stroke-linejoin="round">{ICON_PATHS[name]}</svg>'
        )
        renderer = QSvgRenderer(QByteArray(svg.encode("utf-8")))
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        renderer.render(painter, QRectF(0, 0, size, size))
        painter.end()
    _PIXMAP_CACHE[key] = pixmap
    return pixmap


def svg_icon(name, color, on_color=None, size=20, stroke=1.8):
    icon = QIcon()
    icon.addPixmap(svg_pixmap(name, color, size, stroke), QIcon.Mode.Normal, QIcon.State.Off)
    icon.addPixmap(svg_pixmap(name, on_color or color, size, stroke), QIcon.Mode.Normal, QIcon.State.On)
    return icon


def led_pixmap(colors, cell, gap, off, pad=0, bg=None):
    """Картинка из точек-диодов. colors — ряды QColor (None = выключен)."""
    rows = len(colors)
    columns = len(colors[0]) if rows else 0
    width = int(round(pad * 2 + columns * cell + (columns - 1) * gap))
    height = int(round(pad * 2 + rows * cell + (rows - 1) * gap))
    pixmap = QPixmap(width * 2, height * 2)
    pixmap.setDevicePixelRatio(2.0)
    pixmap.fill(QColor(bg) if bg else Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing)
    painter.setPen(Qt.PenStyle.NoPen)
    off_color = QColor(off)
    for r, row in enumerate(colors):
        for c, color in enumerate(row):
            painter.setBrush(color if color is not None else off_color)
            painter.drawEllipse(
                QPointF(pad + c * (cell + gap) + cell / 2, pad + r * (cell + gap) + cell / 2),
                cell / 2, cell / 2,
            )
    painter.end()
    return pixmap


def plural_pictures(count):
    if count % 10 == 1 and count % 100 != 11:
        word = "картинка"
    elif 2 <= count % 10 <= 4 and not 12 <= count % 100 <= 14:
        word = "картинки"
    else:
        word = "картинок"
    return f"{count} {word}"


def h3_html(text):
    return f"<span style='color:{ACCENT}'>●</span>&nbsp;&nbsp;{text.upper()}"


STYLESHEET = f"""
    QWidget {{
        color: {FG};
        font-family: {MONO};
        font-size: 13px;
    }}
    QLabel {{ background: transparent; }}
    QFrame#mcard {{
        background: #000000;
        border: 1px solid {LINE};
        border-radius: 20px;
    }}
    QFrame#topbar {{
        background: transparent;
        border: none;
        border-bottom: 1px dashed {LINE};
    }}
    QFrame#ledbg {{ background: #000000; border: none; border-radius: 14px; }}
    QLabel#h3 {{ color: {MUTED2}; font-size: 11px; }}
    QLabel#lbl {{ color: {MUTED}; font-size: 11px; }}
    QLabel#mut {{ color: {MUTED}; font-size: 12px; }}
    QLabel#mut13 {{ color: {MUTED}; font-size: 13px; }}
    QLabel#hint {{ color: {MUTED}; font-size: 11px; }}
    QLabel#hex {{ font-size: 16px; }}
    QLabel#name15 {{ font-size: 15px; font-weight: 600; }}
    QLabel#name19 {{ font-size: 19px; font-weight: 700; }}
    QLabel#name22 {{ font-size: 22px; font-weight: 700; }}
    QLabel#value {{ color: {MUTED}; font-size: 13px; }}
    QLabel#status {{ color: {FG}; font-size: 11px; }}
    QPushButton {{
        background: #000000;
        color: {FG};
        border: 1px solid {LINE2};
        border-radius: 20px;
        padding: 0 16px;
        min-height: 40px;
        font-size: 12px;
    }}
    QPushButton:hover {{ border-color: #FFFFFF; }}
    QPushButton:disabled {{ color: #555555; }}
    QPushButton#btnr {{ background: {ACCENT}; color: #FFFFFF; border: none; }}
    QPushButton#btnr:hover {{ background: #FF4D4D; }}
    QPushButton#link {{
        background: transparent; border: none; padding: 0; min-height: 0;
        color: {MUTED2}; font-size: 11px; letter-spacing: 1.5px;
    }}
    QPushButton#link:hover {{ color: #FFFFFF; }}
    QPushButton#small {{
        min-height: 30px;
        padding: 0 12px;
        border-radius: 15px;
    }}
    QPushButton#small:disabled {{ border-color: #222222; }}
    QPushButton#tool {{
        border-radius: 21px;
        padding: 0;
        min-height: 42px;
        max-height: 42px;
    }}
    QPushButton#tool:checked {{ background: {ACCENT}; border-color: {ACCENT}; }}
    QPushButton#toolsm {{
        background: transparent;
        border-radius: 14px;
        padding: 0;
        min-height: 28px;
        max-height: 28px;
    }}
    QPushButton#tab {{
        background: transparent;
        color: {MUTED};
        border: none;
        border-radius: 15px;
        padding: 0 13px;
        min-height: 30px;
        max-height: 30px;
    }}
    QPushButton#tab:hover {{ color: #FFFFFF; }}
    QPushButton#tab:checked {{ background: #FFFFFF; color: #000000; }}
    QLineEdit {{
        background: #000000;
        border: 1px solid {LINE2};
        border-radius: 12px;
        padding: 0 14px;
        min-height: 40px;
        font-size: 14px;
        selection-background-color: {ACCENT};
    }}
    QLineEdit:focus {{ border-color: #FFFFFF; }}
    QLineEdit#hexedit {{
        background: transparent;
        border: none;
        border-bottom: 1px solid transparent;
        border-radius: 0;
        padding: 0;
        min-height: 22px;
        font-size: 16px;
    }}
    QLineEdit#hexedit:focus {{ border-bottom: 1px solid {ACCENT}; }}
    QComboBox {{
        background: transparent;
        color: {MUTED};
        border: none;
        padding: 2px 4px;
        font-size: 13px;
    }}
    QComboBox:hover {{ color: {FG}; }}
    QComboBox::drop-down {{ border: none; width: 14px; }}
    QComboBox::down-arrow {{ image: none; }}
    QComboBox QAbstractItemView {{
        background: #0A0A0A;
        color: {FG};
        border: 1px solid {LINE2};
        selection-background-color: {ACCENT};
        selection-color: #FFFFFF;
        outline: none;
    }}
    QFrame#scen {{ background: #000000; border: 1px solid {LINE}; border-radius: 16px; }}
    QFrame#scen[on="false"] QLabel, QFrame#scen[on="false"] QTimeEdit {{ color: #555555; }}
    QComboBox#modecombo, QTimeEdit {{
        background: #000000;
        color: {FG};
        border: 1px solid {LINE2};
        border-radius: 14px;
        padding: 3px 12px;
        min-height: 22px;
        font-size: 13px;
    }}
    QComboBox#modecombo:hover, QTimeEdit:hover {{ border-color: #FFFFFF; }}
    QTimeEdit {{ font-size: 15px; padding: 3px 10px; }}
    QTimeEdit:focus {{ border-color: {ACCENT}; }}
    QTimeEdit:disabled {{ color: #444444; border-color: #222222; }}
    QPushButton#day {{
        background: transparent;
        color: {MUTED};
        border: 1px solid {LINE2};
        border-radius: 14px;
        padding: 0;
        min-height: 28px;
        max-height: 28px;
        min-width: 36px;
        max-width: 36px;
        font-size: 11px;
    }}
    QPushButton#day:hover {{ border-color: #FFFFFF; color: #FFFFFF; }}
    QPushButton#day:checked {{ background: #FFFFFF; color: #000000; border-color: #FFFFFF; }}
    QPushButton#chip {{
        background: transparent; color: {MUTED}; border: 1px solid {LINE2};
        border-radius: 14px; padding: 0 10px; min-height: 28px; max-height: 28px; font-size: 11px;
    }}
    QPushButton#chip:hover {{ border-color: #FFFFFF; color: #FFFFFF; }}
    QPushButton#chip:checked {{ color: #FFFFFF; border-color: {ACCENT}; }}
    QFrame#li {{ background: transparent; border: none; border-bottom: 1px dashed #222222; }}
    QFrame#li_last {{ background: transparent; border: none; }}
    QFrame#mode {{ background: transparent; border: none; }}
    QFrame#mode_soon {{ background: transparent; border: 1px dashed {LINE2}; border-radius: 18px; }}
    QFrame#tile {{ background: #000000; border: 1px solid {LINE}; border-radius: 16px; }}
    QPushButton#thumb, QPushButton#thumbbig, QPushButton#addtile {{
        background: #000000;
        border: 1px solid {LINE};
        border-radius: 14px;
        padding: 0;
    }}
    QPushButton#thumb, QPushButton#addtile {{ min-height: 86px; max-height: 86px; }}
    QPushButton#thumbbig {{ min-height: 152px; max-height: 152px; }}
    QPushButton#addtile {{ background: transparent; border: 1px dashed {LINE2}; }}
    QPushButton#thumb:hover, QPushButton#thumbbig:hover, QPushButton#addtile:hover {{ border-color: #FFFFFF; }}
    QScrollArea {{ background: transparent; border: none; }}
    QScrollBar:vertical {{ background: transparent; width: 6px; margin: 0; }}
    QScrollBar::handle:vertical {{ background: #2C2C2E; border-radius: 3px; min-height: 24px; }}
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
    QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{ background: transparent; height: 0; }}
    QToolTip {{ background: #000000; color: {FG}; border: 1px solid {LINE2}; }}
"""


# ---------- анимированные виджеты ----------
def mix_color(a, b, t):
    """Плавный переход между двумя цветами (t = 0..1)."""
    t = max(0.0, min(1.0, t))
    return QColor(
        int(a.red() + (b.red() - a.red()) * t),
        int(a.green() + (b.green() - a.green()) * t),
        int(a.blue() + (b.blue() - a.blue()) * t),
        int(a.alpha() + (b.alpha() - a.alpha()) * t),
    )


def make_anim(parent, duration, on_value, curve=QEasingCurve.Type.OutCubic):
    anim = QVariantAnimation(parent)
    anim.setDuration(duration)
    anim.setEasingCurve(curve)
    anim.valueChanged.connect(on_value)
    return anim


class DotTabBar(QWidget):
    """Вкладки в шапке: белая «таблетка» плавно переезжает к выбранной
    вкладке, а текст под ней перетекает из белого в чёрный."""

    current_changed = pyqtSignal(int)
    PAD = 13
    SPACING = 4
    HEIGHT = 30

    def __init__(self, titles, parent=None):
        super().__init__(parent)
        self.titles = [t.upper() for t in titles]
        self.current = 0
        self.hover = -1
        self.hover_level = [0.0] * len(self.titles)
        self.font_ = QFont()
        self.font_.setFamilies(["Consolas", "Liberation Mono", "Courier New"])
        self.font_.setPixelSize(13)
        self.font_.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 1.5)
        self.rects = []
        self.pill = QRectF()
        self._from = QRectF()
        self._to = QRectF()
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(40)
        self.slide = make_anim(self, 380, self._on_slide, QEasingCurve.Type.OutBack)
        self.hover_timer = QTimer(self)
        self.hover_timer.setInterval(16)
        self.hover_timer.timeout.connect(self._on_hover_tick)
        self._layout()

    def _layout(self):
        metrics = QFontMetricsF(self.font_)
        x = 0.0
        top = (40 - self.HEIGHT) / 2
        self.rects = []
        for title in self.titles:
            width = metrics.horizontalAdvance(title) + 2 * self.PAD
            self.rects.append(QRectF(x, top, width, self.HEIGHT))
            x += width + self.SPACING
        self.setFixedWidth(int(x - self.SPACING + 2))
        self.pill = QRectF(self.rects[self.current])

    def set_current(self, index, animate=True):
        if index == self.current and not self.pill.isNull():
            return
        self.current = index
        target = QRectF(self.rects[index])
        if animate and self.isVisible():
            self._from = QRectF(self.pill)
            self._to = target
            self.slide.stop()
            self.slide.setStartValue(0.0)
            self.slide.setEndValue(1.0)
            self.slide.start()
        else:
            self.pill = target
            self.update()

    def _on_slide(self, t):
        t = float(t)
        a, b = self._from, self._to
        # таблетка чуть растягивается в полёте — эффект «жидкости»
        left = a.left() + (b.left() - a.left()) * t
        right = a.right() + (b.right() - a.right()) * t
        stretch = math.sin(min(1.0, max(0.0, t)) * math.pi) * 6
        self.pill = QRectF(QPointF(left - stretch / 2, a.top()), QPointF(right + stretch / 2, a.bottom()))
        self.update()

    def _on_hover_tick(self):
        busy = False
        for i in range(len(self.titles)):
            goal = 1.0 if i == self.hover else 0.0
            level = self.hover_level[i]
            if abs(goal - level) > 0.01:
                self.hover_level[i] = level + (goal - level) * 0.25
                busy = True
            else:
                self.hover_level[i] = goal
        self.update()
        if not busy:
            self.hover_timer.stop()

    def index_at(self, pos):
        for i, rect in enumerate(self.rects):
            if rect.contains(QPointF(pos)):
                return i
        return -1

    def mouseMoveEvent(self, event):
        index = self.index_at(event.position())
        if index != self.hover:
            self.hover = index
            self.hover_timer.start()

    def leaveEvent(self, event):
        self.hover = -1
        self.hover_timer.start()
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            index = self.index_at(event.position())
            if index >= 0:
                self.current_changed.emit(index)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setFont(self.font_)
        flags = int(Qt.AlignmentFlag.AlignCenter)
        muted = QColor(MUTED)
        white = QColor("#FFFFFF")
        for i, rect in enumerate(self.rects):
            level = self.hover_level[i]
            if level > 0.01:
                # мягкая подложка под наведённой вкладкой
                painter.setPen(Qt.PenStyle.NoPen)
                painter.setBrush(QColor(255, 255, 255, int(22 * level)))
                painter.drawRoundedRect(rect, rect.height() / 2, rect.height() / 2)
            painter.setPen(mix_color(muted, white, level))
            painter.drawText(rect, flags, self.titles[i])
        # белая таблетка и чёрный текст только внутри неё
        path = QPainterPath()
        path.addRoundedRect(self.pill, self.pill.height() / 2, self.pill.height() / 2)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(white)
        painter.drawPath(path)
        painter.setClipPath(path)
        painter.setPen(QColor("#000000"))
        for i, rect in enumerate(self.rects):
            painter.drawText(rect, flags, self.titles[i])
        painter.end()


class StatusDot(QWidget):
    """Точка статуса: онлайн — «радар» расходится кругами,
    поиск — мягко дышит, офлайн — просто горит."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(18, 18)
        self.color = QColor("#555555")
        self.state = None
        self.phase = 0.0
        self.anim = QVariantAnimation(self)
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)
        self.anim.setLoopCount(-1)
        self.anim.valueChanged.connect(self._on_phase)

    def set_state(self, state, color):
        if state == self.state:
            return
        self.state = state
        self.color = QColor(color)
        if state in ("online", "search"):
            self.anim.setDuration(1600 if state == "online" else 1200)
            if self.anim.state() != QAbstractAnimation.State.Running:
                self.anim.start()
        else:
            self.anim.stop()
            self.phase = 0.0
        self.update()

    def _on_phase(self, value):
        self.phase = float(value)
        self.update()

    def showEvent(self, event):
        if self.state in ("online", "search"):
            self.anim.start()
        super().showEvent(event)

    def hideEvent(self, event):
        self.anim.stop()
        super().hideEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        center = QPointF(self.width() / 2, self.height() / 2)
        color = QColor(self.color)
        if self.state == "online":
            ring = QColor(color)
            ring.setAlpha(int(170 * (1 - self.phase)))
            painter.setPen(QPen(ring, 1.4))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            radius = 4 + 4.5 * self.phase
            painter.drawEllipse(center, radius, radius)
        elif self.state == "search":
            level = 0.5 - 0.5 * math.cos(self.phase * 2 * math.pi)
            color = mix_color(QColor("#3A3A3E"), QColor("#A0A0A5"), level)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(color)
        painter.drawEllipse(center, 4, 4)
        painter.end()


class ColorBlob(QWidget):
    """Большой образец текущего цвета: цвет перетекает плавно."""

    def __init__(self, size, parent=None):
        super().__init__(parent)
        self.setFixedSize(size, size)
        self.color = QColor("#FF0000")
        self._from = QColor(self.color)
        self._to = QColor(self.color)
        self.scale = 1.0
        self.anim = make_anim(self, 220, self._on_value)
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)

    def set_color(self, color, animate=True):
        color = QColor(color)
        if color == self._to:
            return
        self._from = QColor(self.color)
        self._to = color
        if animate and self.isVisible():
            self.anim.stop()
            self.anim.start()
        else:
            self.color = color
            self.update()

    def _on_value(self, t):
        t = float(t)
        self.color = mix_color(self._from, self._to, t)
        # лёгкий «пульс» при смене цвета
        self.scale = 1.0 - 0.06 * math.sin(t * math.pi)
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(self.color)
        side = self.width() * self.scale
        offset = (self.width() - side) / 2
        painter.drawRoundedRect(QRectF(offset, offset, side, side), 18 * self.scale, 18 * self.scale)
        painter.end()


class PageStack(QStackedWidget):
    """Переключение страниц: старая уезжает и гаснет,
    новая выезжает с той стороны, куда нажали."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.overlay = None
        self.direction = 1
        self.anim = make_anim(self, 320, self._on_value)
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)
        self.anim.finished.connect(self._finish)

    def slide_to(self, index):
        if index == self.currentIndex():
            return
        if not self.isVisible():
            self.setCurrentIndex(index)
            return
        self._finish()
        self.direction = 1 if index > self.currentIndex() else -1
        old = self.currentWidget()
        snapshot = old.grab() if old is not None else QPixmap()
        self.setCurrentIndex(index)
        overlay = QLabel(self)
        overlay.setPixmap(snapshot)
        overlay.setGeometry(0, 0, snapshot.width() or self.width(), snapshot.height() or self.height())
        effect = QGraphicsOpacityEffect(overlay)
        overlay.setGraphicsEffect(effect)
        overlay.show()
        overlay.raise_()
        self.overlay = (overlay, effect)
        self.anim.stop()
        self.anim.start()

    def _on_value(self, t):
        t = float(t)
        page = self.currentWidget()
        shift = 46 * self.direction
        if page is not None:
            page.move(int(shift * (1 - t)), 0)
        if self.overlay is not None:
            overlay, effect = self.overlay
            overlay.move(int(-shift * 0.6 * t), 0)
            effect.setOpacity(max(0.0, 1 - t * 1.6))

    def _finish(self):
        if self.overlay is not None:
            overlay, _effect = self.overlay
            self.overlay = None
            overlay.hide()
            overlay.deleteLater()
        page = self.currentWidget()
        if page is not None:
            page.move(0, 0)


class ModeCard(QFrame):
    """Карточка режима: рамка и фон плавно разгораются при наведении."""

    clicked = pyqtSignal()
    hovered = pyqtSignal(bool)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.level = 0.0
        self.anim = make_anim(self, 200, self._on_value)

    def _animate(self, goal):
        self.anim.stop()
        self.anim.setStartValue(self.level)
        self.anim.setEndValue(goal)
        self.anim.start()

    def _on_value(self, value):
        self.level = float(value)
        self.update()

    def enterEvent(self, event):
        self._animate(1.0)
        self.hovered.emit(True)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._animate(0.0)
        self.hovered.emit(False)
        super().leaveEvent(event)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mousePressEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        level = self.level
        if level > 0.01:
            # еле заметное свечение вокруг рамки
            for width, alpha in ((5, 10), (3, 20)):
                glow = QColor(255, 255, 255, int(alpha * level))
                painter.setPen(QPen(glow, width))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawRoundedRect(rect.adjusted(2, 2, -2, -2), 16, 16)
        painter.setPen(QPen(mix_color(QColor(LINE), QColor("#A8A8A8"), level), 1))
        painter.setBrush(mix_color(QColor("#000000"), QColor("#080808"), level))
        painter.drawRoundedRect(rect, 18, 18)
        painter.end()


class ToggleSwitch(QAbstractButton):
    """Точечный переключатель: красная точка справа — включено."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(46, 24)
        self.highlight = False
        self.knob = 0.0
        self.knob_anim = make_anim(self, 220, self._on_knob, QEasingCurve.Type.OutBack)
        self.toggled.connect(self._animate_knob)

    def _animate_knob(self, checked):
        goal = 1.0 if checked else 0.0
        if not self.isVisible():
            self.knob = goal
            self.update()
            return
        self.knob_anim.stop()
        self.knob_anim.setStartValue(self.knob)
        self.knob_anim.setEndValue(goal)
        self.knob_anim.start()

    def _on_knob(self, value):
        self.knob = float(value)
        self.update()

    def set_highlight(self, value):
        if self.highlight != value:
            self.highlight = value
            self.update()

    def enterEvent(self, event):
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = QRectF(0.5, 0.5, self.width() - 1, self.height() - 1)
        on = self.isChecked()
        lit = self.highlight or self.underMouse()
        if lit:
            # мягкое свечение вокруг тумблера при наведении на режим
            glow = QColor(ACCENT if on else "#FFFFFF")
            for width, alpha in ((5, 22), (3, 40)):
                glow.setAlpha(alpha)
                painter.setPen(QPen(glow, width))
                painter.drawRoundedRect(rect.adjusted(2, 2, -2, -2), rect.height() / 2 - 2, rect.height() / 2 - 2)
        if on:
            border = "#FFFFFF"
        elif self.underMouse():
            border = "#FFFFFF"
        elif lit:
            border = "#BBBBBB"
        else:
            border = "#444444"
        painter.setPen(QPen(QColor(border), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(rect, rect.height() / 2, rect.height() / 2)
        knob = 16
        t = self.knob
        x = 4 + (self.width() - knob - 8) * t
        off_color = QColor("#DDDDDD" if lit else "#555555")
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(mix_color(off_color, QColor(ACCENT), max(0.0, min(1.0, t))))
        painter.drawEllipse(QRectF(x, (self.height() - knob) / 2, knob, knob))
        painter.end()


class DotSlider(QSlider):
    """Ползунок из точек: белые — пройдено, красная — текущее значение."""

    STEP = 10

    def __init__(self, parent=None):
        super().__init__(Qt.Orientation.Horizontal, parent)
        self.setFixedHeight(22)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def _count(self):
        return max(2, int((self.width() - 4) // self.STEP))

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setPen(Qt.PenStyle.NoPen)
        cy = self.height() / 2
        span = self.maximum() - self.minimum()
        fraction = (self.value() - self.minimum()) / span if span else 0.0
        count = self._count()
        lit = int(round(fraction * (count - 1)))
        for i in range(count):
            cx = 4 + i * self.STEP
            if i == lit:
                painter.setBrush(QColor(ACCENT))
                painter.drawEllipse(QPointF(cx, cy), 4.0, 4.0)
            else:
                painter.setBrush(QColor("#FFFFFF" if i < lit else "#333333"))
                painter.drawEllipse(QPointF(cx, cy), 2.0, 2.0)
        painter.end()

    def _value_at(self, x):
        count = self._count()
        index = min(count - 1, max(0, round((x - 4) / self.STEP)))
        return self.minimum() + round(index / (count - 1) * (self.maximum() - self.minimum()))

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.setSliderDown(True)
            self.setValue(self._value_at(event.position().x()))
            event.accept()

    def mouseMoveEvent(self, event):
        if event.buttons() & Qt.MouseButton.LeftButton:
            self.setValue(self._value_at(event.position().x()))
            event.accept()

    def mouseReleaseEvent(self, event):
        self.setSliderDown(False)
        event.accept()

    def set_silent(self, value):
        if self.value() != value:
            self.blockSignals(True)
            self.setValue(value)
            self.blockSignals(False)
            self.update()


class SwatchButton(QAbstractButton):
    """Круглый образец цвета. Пустой — пунктир с плюсом."""

    def __init__(self, size=26, parent=None):
        super().__init__(parent)
        self.color = None
        self.selected = False
        self.swatch = size
        self.setFixedSize(size + 8, size + 8)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.hover_level = 0.0
        self.hover_anim = make_anim(self, 160, self._on_hover)

    def _hover_to(self, goal):
        self.hover_anim.stop()
        self.hover_anim.setStartValue(self.hover_level)
        self.hover_anim.setEndValue(goal)
        self.hover_anim.start()

    def _on_hover(self, value):
        self.hover_level = float(value)
        self.update()

    def enterEvent(self, event):
        self._hover_to(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event):
        self._hover_to(0.0)
        super().leaveEvent(event)

    def set_state(self, color, selected):
        new_color = QColor(color) if color else None
        if new_color != self.color or selected != self.selected:
            self.color = new_color
            self.selected = selected
            self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        center = QPointF(self.width() / 2, self.height() / 2)
        radius = self.swatch / 2
        level = self.hover_level
        hover = level > 0.5
        if level > 0.01 and not self.selected:
            # подсветка контура при наведении: кольцо плавно проявляется
            painter.setPen(QPen(QColor(200, 200, 200, int(230 * level)), 1.4))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            ring = radius + 0.8 + 1.8 * level
            painter.drawEllipse(center, ring, ring)
        if self.color is None:
            if self.selected:
                painter.setPen(QPen(QColor("#FFFFFF"), 1.6))
                painter.setBrush(Qt.BrushStyle.NoBrush)
                painter.drawEllipse(center, radius + 2.6, radius + 2.6)
            line = "#FFFFFF" if (hover or self.selected) else "#6E6E73"
            painter.setPen(QPen(QColor(line if hover or self.selected else "#5A5A5E"), 1.4, Qt.PenStyle.DashLine))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawEllipse(center, radius - 1, radius - 1)
            painter.setPen(QPen(QColor(line), 1.4))
            painter.drawLine(QPointF(center.x() - 4, center.y()), QPointF(center.x() + 4, center.y()))
            painter.drawLine(QPointF(center.x(), center.y() - 4), QPointF(center.x(), center.y() + 4))
        else:
            painter.setPen(Qt.PenStyle.NoPen)
            inner = radius
            if self.selected:
                painter.setBrush(QColor("#FFFFFF"))
                painter.drawEllipse(center, radius + 3, radius + 3)
                painter.setBrush(QColor("#000000"))
                painter.drawEllipse(center, radius + 1.2, radius + 1.2)
                inner = radius - 1.5
            painter.setBrush(self.color)
            painter.drawEllipse(center, inner, inner)
        painter.end()


class ConfirmOverlay(QWidget):
    """Подтверждение снизу окна — как на телефоне: «Отмена» / «Удалить»."""

    def __init__(self, window, question, name, note, preview, on_yes):
        super().__init__(window)
        from PyQt6.QtCore import QVariantAnimation
        self.on_yes = on_yes
        self.closing = False
        self.progress = 0.0
        self.setGeometry(window.rect())
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.panel = QFrame(self)
        self.panel.setObjectName("sheet")
        self.panel.setStyleSheet(
            f"QFrame#sheet {{ background: #0B0B0B; border: 1px solid {LINE2}; border-bottom: none;"
            " border-top-left-radius: 28px; border-top-right-radius: 28px; }"
        )
        layout = QVBoxLayout(self.panel)
        layout.setContentsMargins(28, 22, 28, 26)
        layout.setSpacing(8)
        layout.addWidget(window.h3("Удаление"))
        layout.addSpacing(8)
        if preview is not None:
            layout.addWidget(preview, 0, Qt.AlignmentFlag.AlignHCenter)
            layout.addSpacing(6)
        title = QLabel(question)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"color: {FG}; font-size: 18px; font-weight: 700;")
        layout.addWidget(title)
        if name:
            label = QLabel(name)
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            label.setWordWrap(True)
            label.setStyleSheet(f"color: {FG}; font-size: 13px;")
            layout.addWidget(label)
        hint = QLabel(note)
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet(f"color: {MUTED}; font-size: 12px;")
        layout.addWidget(hint)
        layout.addSpacing(12)
        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        cancel = window.button("Отмена")
        cancel.clicked.connect(self.dismiss)
        yes = window.button("Удалить", "btnr", icon="trash")
        yes.clicked.connect(self.accept)
        buttons.addWidget(cancel, 1)
        buttons.addWidget(yes, 1)
        layout.addLayout(buttons)
        self.panel.setFixedWidth(min(520, max(360, window.width() - 80)))
        self.panel.adjustSize()
        self.anim = QVariantAnimation(self)
        self.anim.setDuration(260)
        self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.anim.valueChanged.connect(self.set_progress)
        self.anim.finished.connect(self.on_anim_done)
        window.installEventFilter(self)
        self.set_progress(0.0)
        self.show()
        self.raise_()
        self.setFocus()
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)
        self.anim.start()

    def set_progress(self, value):
        self.progress = float(value)
        x = (self.width() - self.panel.width()) // 2
        h = self.panel.height()
        self.panel.move(x, int(self.height() - h * self.progress))
        self.update()

    def eventFilter(self, obj, event):
        if obj is self.parent() and event.type() == event.Type.Resize:
            self.setGeometry(self.parent().rect())
            self.set_progress(self.progress)
        return False

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(0, 0, 0, int(170 * self.progress)))
        painter.end()

    def mousePressEvent(self, event):
        if not self.panel.geometry().contains(event.position().toPoint()):
            self.dismiss()

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape:
            self.dismiss()
        elif event.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.accept()

    def close_sheet(self):
        if self.closing:
            return
        self.closing = True
        self.anim.stop()
        self.anim.setDuration(200)
        self.anim.setStartValue(self.progress)
        self.anim.setEndValue(0.0)
        self.anim.start()

    def dismiss(self):
        self.on_yes = None
        self.close_sheet()

    def accept(self):
        self.close_sheet()

    def on_anim_done(self):
        if not self.closing:
            return
        self.parent().removeEventFilter(self)
        action = self.on_yes
        self.hide()
        self.deleteLater()
        if action:
            QTimer.singleShot(0, action)


class Window(QWidget):
    PAGES = ["Рисование", "Режимы", "Сценарии", "Картинки", "Настройки"]

    def __init__(self):
        super().__init__()

        if getattr(sys, "frozen", False):
            self.base_dir = os.path.dirname(sys.executable)
        else:
            self.base_dir = APP_DIR

        self.setObjectName("main_window")
        self.setWindowTitle("LED Matrix Studio")
        self.setFixedSize(1100, 700)
        icon_path = os.path.join(self.base_dir, "icon.ico")
        if os.path.exists(icon_path):
            self.setWindowIcon(QIcon(icon_path))

        self.settings = ProfileSettings()
        self.current_color = QColor("#FF0000")
        self.active_mode = None
        self._mode_active = False
        self.matrix_history = []
        self.matrix_redo = []
        self._bg = None

        # «Мои цвета» хранятся под новым ключом: старые сохранённые
        # цвета сбрасываются один раз, все 9 кружков начинаются пустыми
        self.settings.remove("recent_colors")
        recent = str(self.settings.value("my_colors", ""))
        self.custom_colors = (recent.split(",") if recent else []) + [""] * CUSTOM_COUNT
        self.custom_colors = self.custom_colors[:CUSTOM_COUNT]
        self.custom_slot = None

        self.selected_mode = str(self.settings.value("last_mode", "fire") or "fire")
        if self.selected_mode not in [m[0] for m in MODE_INFO]:
            self.selected_mode = "fire"

        self.scenarios = self.load_scenarios()
        self.time_sent_at = None

        self.pictures_path = os.path.join(self.base_dir, "saved_pictures.json" if MATRIX_PROFILE=="esp32-19x20" else "saved_pictures.c3mini9.json")
        if MATRIX_PROFILE=="esp32-19x20": self.import_old_pictures()
        self.saved_pictures = []
        self.load_saved_pictures()

        self.esp_link = EspLink(self.settings, self)
        # пиксели копятся ~12 мс и уходят одним UDP-пакетом
        self._pixel_queue = {}
        self._pixel_prev = {}   # прошлая пачка — повторяем её в следующем пакете на случай потери
        self._pixel_timer = QTimer(self)
        self._pixel_timer.setSingleShot(True)
        self._pixel_timer.setInterval(12)
        self._pixel_timer.timeout.connect(self.flush_pixels)
        # после штриха — весь холст по TCP, чтобы гирлянда точно совпала с программой
        self._picture_timer = QTimer(self)
        self._picture_timer.setSingleShot(True)
        self._picture_timer.setInterval(250)
        self._picture_timer.timeout.connect(self.flush_matrix_send)
        self.ui_call = UiCall(self)
        self.update_info = None
        self.fw_target = 0
        self.fw_sent_at = 0.0
        self.udp_sender = QUdpSocket(self)

        self.matrix = LedMatrix(MATRIX_COLUMNS, MATRIX_ROWS)
        try:
            saved_canvas=json.loads(str(self.settings.value('local_canvas','[]')))
            if len(saved_canvas)==MATRIX_ROWS and all(len(row)==MATRIX_COLUMNS*6 for row in saved_canvas):
                self.matrix.pixels=[[QColor('#'+row[c*6:c*6+6]) for c in range(MATRIX_COLUMNS)] for row in saved_canvas]
        except (ValueError,TypeError):pass
        self.matrix.pixel_painted.connect(self.on_pixel_painted)
        self.matrix.stroke_started.connect(self.on_stroke_started)
        self.matrix.stroke_finished.connect(self.on_stroke_finished)
        self.matrix.color_picked.connect(self.on_color_picked)

        self.setStyleSheet(STYLESHEET)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        root.addWidget(self.build_topbar())
        body = QWidget()
        body_layout = QVBoxLayout(body)
        body_layout.setContentsMargins(26, 20, 26, 20)
        self.stack = PageStack()
        body_layout.addWidget(self.stack)
        root.addWidget(body, 1)

        self.stack.addWidget(self.build_draw_page())
        self.stack.addWidget(self.build_modes_page())
        self.stack.addWidget(self.build_scenarios_page())
        self.stack.addWidget(self.build_pictures_page())
        self.stack.addWidget(self.build_settings_page())

        brightness = int(self.settings.value("brightness", 75))
        self.set_brightness_widgets(brightness)

        self.esp_link.discovered.connect(lambda *_: self.refresh_status())
        self.esp_link.discovered.connect(
            lambda *_: QTimer.singleShot(600, lambda: self.on_timezone_changed(self.tz_combo.currentText()))
        )
        self.esp_link.state_changed.connect(lambda *_: self.refresh_status())
        self.esp_link.state_changed.connect(self.on_link_state)
        self.esp_link.wifi_result.connect(self.on_wifi_result)
        self.esp_link.state_received.connect(self.on_device_state)
        QTimer.singleShot(3000, lambda: self.check_updates(silent=True))

        self.status_timer = QTimer(self)
        self.status_timer.setInterval(1000)
        self.status_timer.timeout.connect(self.refresh_status)
        self.status_timer.start()

        self.mode_speed_timer = QTimer(self)
        self.mode_speed_timer.setSingleShot(True)
        self.mode_speed_timer.setInterval(120)
        self.mode_speed_timer.timeout.connect(self.flush_mode_speed)

        # время на гирлянду: при подключении и потом раз в 15 минут
        self.time_sync_timer = QTimer(self)
        self.time_sync_timer.setInterval(TIME_SYNC_MS)
        self.time_sync_timer.timeout.connect(self.send_time)
        self.time_sync_timer.start()

        # сценарии уходят на гирлянду не сразу, а через 0,7 с после правки
        self.scen_send_timer = QTimer(self)
        self.scen_send_timer.setSingleShot(True)
        self.scen_send_timer.setInterval(700)
        self.scen_send_timer.timeout.connect(self.send_schedule)

        self.clock_timer = QTimer(self)
        self.clock_timer.setInterval(500)
        self.clock_timer.timeout.connect(self.refresh_clock)

        self.set_color(self.current_color)
        self.refresh_pictures()
        self.refresh_status()
        self.refresh_tools()
        self.select_mode(self.selected_mode)
        self.show_page(0)
        # фокус на окне, а не в поле ввода — курсор не мигает при запуске
        self.setFocusPolicy(Qt.FocusPolicy.ClickFocus)
        self.setFocus()
        self.init_peers()

    def init_peers(self):
        import uuid
        try:saved=json.loads(str(self.settings.value('peer_records_v2','{}')))
        except Exception:saved={}
        node=str(self.settings.value('peer_node_v2','')) or uuid.uuid4().hex
        self.settings.setValue('peer_node_v2',node)
        self.peer_ledger=PeerLedger(node,saved);self._peer_view={};self._peer_dirty=True;self._peer_applying=False
        self.peer_apply(list(self.peer_ledger.records))
        self.peer_capture(seed=True)
        self.peer_transport=PeerTransport(node,self);self.peer_transport.received.connect(self.peer_receive)
        self.peer_transport.update(self.peer_wire())
        self.peer_timer=QTimer(self);self.peer_timer.setInterval(100);self.peer_timer.timeout.connect(self.peer_capture);self.peer_timer.start()
        self.peer_save_timer=QTimer(self);self.peer_save_timer.setInterval(1000);self.peer_save_timer.timeout.connect(self.peer_persist);self.peer_save_timer.start()

    def peer_snapshot(self):
        out={'brightness':int(self.settings.value('brightness',75)),
             'mode':{'key':self.active_mode or 'off','random':bool(getattr(self,'random_on',False)),'every':self.rnd_every()},
             'setting:night':self.settings.value('night_mode','false')=='true',
             'setting:startLast':self.settings.value('start_last_mode','false')=='true',
             'setting:timezone':str(self.settings.value('timezone','UTC+3'))}
        for k,_,_ in MODE_INFO:out['speed:'+k]=int(self.settings.value('speed_'+k,65))
        for i,c in enumerate(self.custom_colors):out['color:'+str(i)]=c
        for p in self.saved_pictures:out['picture:'+p['id']]={k:p[k] for k in ['id','name','t','rows']}
        for s in self.scenarios:
            value={k:s[k] for k in ['enabled','mode','on','off','days']}
            if not s.get('id'):s['id']=peer_scenario_id(value)
            out['scenario:'+s['id']]=value
        return out

    def peer_capture(self,seed=False):
        if getattr(self,'_peer_applying',False):return
        snapshot=self.peer_snapshot();changed=False
        for k,v in snapshot.items():
            if k not in self._peer_view or PeerLedger.canonical(v)!=PeerLedger.canonical(self._peer_view[k]):
                if seed and k in self.peer_ledger.records:continue
                changed=self.peer_ledger.put(k,v,seed) or changed
        for k in self._peer_view.keys()-snapshot.keys():
            if k.startswith(('picture:','scenario:')):changed=self.peer_ledger.put(k,None) or changed
        self._peer_view=json.loads(json.dumps(snapshot))
        if changed:
            self._peer_dirty=True
            if hasattr(self,'peer_transport'):self.peer_transport.update(self.peer_wire())
        if hasattr(self,'peer_status'):
            n=sum(time.monotonic()-t<5 for t in list(self.peer_transport.peers.values())) if hasattr(self,'peer_transport') else 0
            self.peer_status.setText(('Локальная синхронизация: устройств рядом — '+str(n)) if not getattr(getattr(self,'peer_transport',None),'error','') else 'Локальная синхронизация недоступна: проверь разрешение сети для приложения')

    def peer_persist(self):
        if getattr(self,'_peer_dirty',False):
            self.settings.setValue('peer_records_v2',json.dumps(self.peer_ledger.records,separators=(',',':')));self._peer_dirty=False

    def peer_receive(self,records):
        prefix=MATRIX_PROFILE+'/'
        records={k[len(prefix):]:v for k,v in records.items() if k.startswith(prefix)}
        # Capture pending local edits before merging: receiving never erases an unsent local edit.
        self.peer_capture()
        keys=self.peer_ledger.merge(records)
        if not keys:return
        self.peer_apply(keys);self._peer_view=json.loads(json.dumps(self.peer_snapshot()));self._peer_dirty=True
        self.peer_transport.update(self.peer_wire())

    def peer_apply(self,keys):
        self._peer_applying=True
        try:
            values={k:r['v'] for k,r in self.peer_ledger.records.items()};modes=[k for k,_,_ in MODE_INFO]
            if 'mode' in keys:
                v=values['mode'];self.active_mode=v['key'] if v['key']!='off' else None;self._mode_active=bool(self.active_mode);self.random_on=v['random'];self.settings.setValue('rnd_every',v['every']);self.set_rnd_combo(v['every'])
                if self.active_mode:self.settings.setValue('last_mode',self.active_mode);self.select_mode(self.active_mode)
                self.mark_sent({'type':'mode'});self.refresh_modes_state()
            for k in keys:
                v=values[k]
                if k.startswith('speed:'):
                    mode=k[6:];self.settings.setValue('speed_'+mode,v);self.mode_cards[mode][2].set_speed(v)
                    if self.selected_mode==mode:self.speed_slider.set_silent(v);self.speed_value.setText(str(v));self.big_preview is not None and self.big_preview.set_speed(v)
                    self.mark_sent({'type':'speed'})
                elif k=='brightness':self.settings.setValue('brightness',v);self.set_brightness_widgets(v);self.mark_sent({'type':'brightness'})
                elif k in ['setting:night','setting:startLast']:
                    target='night_mode' if k.endswith('night') else 'start_last_mode';self.settings.setValue(target,'true' if v else 'false');widget=self.night_toggle if target=='night_mode' else self.last_toggle;widget.blockSignals(True);widget.setChecked(v);widget.blockSignals(False)
                    if target=='night_mode':self.send_night_udp()
                elif k=='setting:timezone':
                    self.settings.setValue('timezone',v);self.tz_combo.blockSignals(True);self.tz_combo.setCurrentText(v);self.tz_combo.blockSignals(False)
            if any(k.startswith('color:') for k in keys):
                for i in range(9):self.custom_colors[i]=values.get('color:'+str(i),self.custom_colors[i])
                self.settings.setValue('my_colors',','.join(self.custom_colors));self.refresh_custom()
            if any(k.startswith('picture:') for k in keys):
                self.saved_pictures=[v for k,v in values.items() if k.startswith('picture:') and v is not None];self.saved_pictures.sort(key=lambda p:(p['t'],p['id']));self.persist_saved_pictures();self.refresh_pictures()
            if any(k.startswith('scenario:') for k in keys):
                self.scenarios=[dict(v,id=k[9:]) for k,v in sorted(values.items()) if k.startswith('scenario:') and v is not None];self.settings.setValue('scenarios',json.dumps(self.scenarios));self.refresh_scenarios()
                if len(self.scenarios)>MAX_SCENARIOS:self.update_result.setText('Сохранены все сценарии; гирлянда поддерживает первые 8. Удали лишние перед отправкой.')
        finally:self._peer_applying=False

    # ---------- фон ----------
    def paintEvent(self, event):
        # чёрный фон с еле заметной сеткой точек (рисуется один раз)
        if self._bg is None or self._bg.size() != self.size():
            self._bg = QPixmap(self.size())
            self._bg.fill(QColor("#000000"))
            painter = QPainter(self._bg)
            painter.setRenderHint(QPainter.RenderHint.Antialiasing)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor("#161616"))
            for y in range(6, self.height(), 12):
                for x in range(6, self.width(), 12):
                    painter.drawEllipse(QPointF(x, y), 1.1, 1.1)
            painter.end()
        painter = QPainter(self)
        painter.drawPixmap(event.rect(), self._bg, event.rect())
        painter.end()

    # ---------- фабрики виджетов ----------
    def label(self, text, name=None, caps=False, track=None):
        label = QLabel(text.upper() if caps else text)
        if name:
            label.setObjectName(name)
        if caps or track:
            set_tracking(label, track if track is not None else 2.0)
        return label

    def h3(self, text):
        label = QLabel(h3_html(text))
        label.setObjectName("h3")
        set_tracking(label, 2.5)
        return label

    def button(self, text, kind=None, icon=None, small=False):
        button = QPushButton(text.upper())
        if small:
            button.setObjectName("small")
        elif kind:
            button.setObjectName(kind)
        set_tracking(button, 1.5)
        if icon:
            button.setIcon(svg_icon(icon, "#FFFFFF" if kind == "btnr" else FG, size=16))
            button.setIconSize(QSize(16, 16))
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        return button

    def card(self):
        frame = QFrame()
        frame.setObjectName("mcard")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 18, 18, 18)
        layout.setSpacing(0)
        return frame, layout

    def clear_layout(self, layout):
        while layout.count():
            item = layout.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
            elif item.layout() is not None:
                self.clear_layout(item.layout())

    # ---------- шапка ----------
    def build_topbar(self):
        bar = QFrame()
        bar.setObjectName("topbar")
        bar.setFixedHeight(70)
        layout = QHBoxLayout(bar)
        layout.setContentsMargins(26, 0, 26, 0)
        layout.setSpacing(4)
        logo = QLabel()
        logo.setPixmap(dot_text_pixmap("LED MATRIX", 3.0, 1.2, "#FFFFFF", "#1C1C1C"))
        layout.addWidget(logo)
        layout.addSpacing(30)
        self.tab_bar = DotTabBar(self.PAGES)
        self.tab_bar.current_changed.connect(self.show_page)
        layout.addWidget(self.tab_bar)
        layout.addStretch()
        self.pill_dot = StatusDot()
        layout.addWidget(self.pill_dot)
        layout.addSpacing(2)
        self.pill_text = self.label("", "status", track=.5)
        layout.addWidget(self.pill_text)
        self.device_select=QToolButton();self.device_select.setArrowType(Qt.ArrowType.DownArrow);self.device_select.setToolTip('Выбрать гирлянду');self.device_select.setFixedWidth(18);self.device_select.setStyleSheet('border:0;background:transparent;color:white')
        self.device_select.clicked.connect(self.show_device_menu);layout.addWidget(self.device_select)
        self.pill_text.mousePressEvent=lambda event:self.show_device_menu()
        return bar

    def show_device_menu(self):
        menu=QMenu(self)
        dual=str(ROOT_SETTINGS.value('dual_enabled','true'))!='false'
        for key,p in MATRIX_PROFILES.items():
            if not dual and key!='esp32-19x20':continue
            d=self.esp_link.devices.get(key,{})
            online=time.monotonic()-d.get('seen',0)<OFFLINE_TIMEOUT_S
            a=menu.addAction(p['name']+' · '+(d.get('ip','') if online else 'не в сети'))
            a.setCheckable(True);a.setChecked(key==MATRIX_PROFILE);a.triggered.connect(lambda checked=False,k=key:self.switch_device(k))
        menu.addSeparator();a=menu.addAction('Две гирлянды');a.setCheckable(True);a.setChecked(dual)
        a.triggered.connect(lambda checked:self.set_dual_mode(checked))
        menu.addSeparator();rollback=menu.addAction('Вернуть прежнюю программу · v20');rollback.setEnabled(INSTALLED);rollback.triggered.connect(self.rollback_single)
        menu.exec(self.device_select.mapToGlobal(self.device_select.rect().bottomRight()))

    def rollback_single(self):
        if not INSTALLED or self.fw_sent_at or getattr(self,'_fw_retry_pending',False):return
        if QMessageBox.question(self,'Возврат к одной гирлянде','Вернуть программу v20 для 19×20? Данные обеих гирлянд сохранятся.',QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:return
        self.update_result.setText('Скачиваю сохранённую программу v20…')
        def work():
            import importlib.util,shutil
            data=fetch_update_bytes('https://raw.githubusercontent.com/nf97700-glitch/LED-Matrix-Updates/968a87bc1722175cd387584cc316fcc06a1cb274/pc/LEDMatrixStudio.pyc',expected_sha='7d0617043a6e61d53b78a5c37ad1f0ba360a810119d2a6c59632894851f06532')
            if data[:4]!=importlib.util.MAGIC_NUMBER:raise ValueError('Неверный формат сохранённой программы')
            target=os.path.abspath(__file__)
            if not target.endswith('.pyc'):raise ValueError('Возврат доступен только в установленной программе')
            with open(target+'.new','wb') as f:f.write(data)
            shutil.copy2(target,target+'.dual-backup');os.replace(target+'.new',target)
        def done(result):
            if isinstance(result,Exception):self.update_result.setText('Не удалось вернуть прежнюю программу: '+str(result));return
            ROOT_SETTINGS.setValue('matrix_profile','esp32-19x20');ROOT_SETTINGS.setValue('dual_enabled','false');ROOT_SETTINGS.sync();self.restart_program()
        run_in_thread(work,done,self.ui_call)

    def set_dual_mode(self,enabled):
        if self.fw_sent_at or getattr(self,'_fw_retry_pending',False):return
        ROOT_SETTINGS.setValue('dual_enabled','true' if enabled else 'false');ROOT_SETTINGS.sync()
        if not enabled and MATRIX_PROFILE!='esp32-19x20':self.switch_device('esp32-19x20')

    def switch_device(self,key):
        if key not in MATRIX_PROFILES or key==MATRIX_PROFILE:return
        if self.fw_sent_at or getattr(self,'_fw_retry_pending',False):
            self.update_result.setText('Дождись завершения обновления гирлянды');return
        ROOT_SETTINGS.setValue('matrix_profile',key);ROOT_SETTINGS.sync();self.restart_program()

    def peer_wire(self):return {MATRIX_PROFILE+'/'+k:r for k,r in self.peer_ledger.records.items()}

    def show_page(self, index):
        self.tab_bar.set_current(index)
        self.stack.slide_to(index)
        if index == 2:
            self.refresh_clock()
            self.clock_timer.start()
        else:
            self.clock_timer.stop()
        if index == 3:
            self.refresh_current_preview()
        elif index == 4:
            self.refresh_status()

    # ---------- Рисование ----------
    def build_draw_page(self):
        page = QWidget()
        row = QHBoxLayout(page)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(16)

        matrix_card, layout = self.card()
        matrix_card.setFixedWidth(557)
        header = QHBoxLayout()
        header.addWidget(self.h3(f"Холст · {MATRIX_COLUMNS}×{MATRIX_ROWS}"))
        header.addStretch()
        self.undo_button = self.button("", small=True, icon="undo")
        self.undo_button.setToolTip("Назад (Ctrl+Z)")
        self.undo_button.setFixedSize(46, 30)
        self.undo_button.clicked.connect(self.undo_matrix)
        header.addWidget(self.undo_button)
        header.addSpacing(8)
        self.redo_button = self.button("", small=True, icon="redo")
        self.redo_button.setToolTip("Вперёд (Ctrl+Y)")
        self.redo_button.setFixedSize(46, 30)
        self.redo_button.clicked.connect(self.redo_matrix)
        header.addWidget(self.redo_button)
        for keys, slot in (("Ctrl+Z", self.undo_matrix), ("Ctrl+Y", self.redo_matrix),
                           ("Ctrl+Shift+Z", self.redo_matrix)):
            QShortcut(QKeySequence(keys), self, activated=slot)
        self.update_history_buttons()
        layout.addLayout(header)
        layout.addSpacing(16)

        body = QHBoxLayout()
        body.setSpacing(16)
        tools = QVBoxLayout()
        tools.setSpacing(10)
        self.tool_buttons = {}
        for key, tip in (
            ("draw", "Кисть"),
            ("eraser", "Ластик"),
            ("fill", "Залить всё текущим цветом"),
            ("pick", "Пипетка: взять цвет с холста"),
            ("trash", "Очистить холст"),
        ):
            button = QPushButton()
            button.setObjectName("tool")
            button.setFixedSize(44, 44)
            button.setToolTip(tip)
            button.setIcon(svg_icon(key, "#BBBBBB", "#FFFFFF", size=20))
            button.setIconSize(QSize(20, 20))
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            if key in ("draw", "eraser", "pick"):
                button.setCheckable(True)
            button.clicked.connect(lambda checked=False, k=key: self.on_tool(k))
            tools.addWidget(button)
            self.tool_buttons[key] = button
        tools.addStretch()
        body.addLayout(tools)
        self.matrix.setFixedSize(461, 484)
        body.addWidget(self.matrix, 0, Qt.AlignmentFlag.AlignTop)
        layout.addLayout(body)
        layout.addStretch()
        row.addWidget(matrix_card)

        right = QVBoxLayout()
        right.setContentsMargins(0, 0, 0, 0)
        right.setSpacing(16)
        right.addWidget(self.build_color_card(), 1)
        right.addWidget(self.build_saved_card())
        row.addLayout(right, 1)
        return page

    def build_color_card(self):
        card, layout = self.card()
        layout.addWidget(self.h3("Цвет"))
        layout.addSpacing(14)

        top = QHBoxLayout()
        top.setSpacing(18)
        self.color_wheel = ColorWheel(168)
        self.color_wheel.color_changed.connect(lambda color: self.set_color(color, origin="wheel"))
        top.addWidget(self.color_wheel)
        info = QVBoxLayout()
        info.setSpacing(10)
        info.addStretch()
        self.big_swatch = ColorBlob(62)
        self.swatch_shadow = QGraphicsDropShadowEffect(self.big_swatch)
        self.swatch_shadow.setBlurRadius(28)
        self.swatch_shadow.setOffset(0, 6)
        self.big_swatch.setGraphicsEffect(self.swatch_shadow)
        info.addWidget(self.big_swatch)
        self.hex_edit = QLineEdit()
        self.hex_edit.setObjectName("hexedit")
        self.hex_edit.setFixedWidth(110)
        self.hex_edit.editingFinished.connect(self.on_hex_edited)
        info.addWidget(self.hex_edit)
        self.rgb_label = self.label("", "mut")
        info.addWidget(self.rgb_label)
        info.addStretch()
        top.addLayout(info)
        top.addStretch()
        layout.addLayout(top)

        layout.addSpacing(10)
        layout.addWidget(self.label("Быстрые цвета", "lbl", caps=True))
        layout.addSpacing(4)
        # оба ряда в одной сетке 9 колонок — кружки стоят ровно друг под другом
        quick_grid = QGridLayout()
        quick_grid.setContentsMargins(0, 0, 0, 0)
        quick_grid.setHorizontalSpacing(0)
        quick_grid.setVerticalSpacing(0)
        self.quick_swatches = []
        for index, color in enumerate(QUICK_COLORS):
            swatch = SwatchButton(26)
            swatch.setToolTip(color)
            swatch.clicked.connect(lambda checked=False, c=color: self.set_color(c))
            quick_grid.addWidget(swatch, 0, index, Qt.AlignmentFlag.AlignCenter)
            self.quick_swatches.append((swatch, color))
        layout.addLayout(quick_grid)

        layout.addSpacing(8)
        custom_head = QHBoxLayout()
        custom_head.addWidget(self.label("Мои цвета", "lbl", caps=True))
        custom_head.addStretch()
        self.custom_save_button = QPushButton("+ СОХРАНИТЬ ЦВЕТ")
        self.custom_save_button.setObjectName("link")
        self.custom_save_button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.custom_save_button.setToolTip("Записать текущий цвет в выбранный кружок «Моих цветов»")
        self.custom_save_button.clicked.connect(self.save_custom_color)
        custom_head.addWidget(self.custom_save_button)
        layout.addLayout(custom_head)
        layout.addSpacing(4)
        custom_grid = QGridLayout()
        custom_grid.setContentsMargins(0, 0, 0, 0)
        custom_grid.setHorizontalSpacing(0)
        custom_grid.setVerticalSpacing(0)
        self.custom_swatches = []
        for index in range(CUSTOM_COUNT):
            swatch = SwatchButton(26)
            swatch.setToolTip("Клик — выбрать кружок и взять его цвет.\n"
                              "Чтобы записать в него цвет — «Сохранить цвет»")
            swatch.clicked.connect(lambda checked=False, i=index: self.on_custom_clicked(i))
            custom_grid.addWidget(swatch, 0, index, Qt.AlignmentFlag.AlignCenter)
            self.custom_swatches.append(swatch)
        for column in range(CUSTOM_COUNT):
            quick_grid.setColumnStretch(column, 1)
            custom_grid.setColumnStretch(column, 1)
        layout.addLayout(custom_grid)
        self.custom_feedback = QTimer(self)
        self.custom_feedback.setSingleShot(True)
        self.custom_feedback.timeout.connect(lambda: self.custom_save_button.setText("+ СОХРАНИТЬ ЦВЕТ"))

        layout.addSpacing(10)
        layout.addWidget(self.label("Яркость", "lbl", caps=True))
        layout.addSpacing(6)
        bright_row = QHBoxLayout()
        bright_row.setSpacing(12)
        sun = QLabel()
        sun.setPixmap(svg_pixmap("sun", FG, 18))
        bright_row.addWidget(sun)
        self.bright_slider = DotSlider()
        self.bright_slider.setRange(5, 100)
        self.bright_slider.valueChanged.connect(self.on_brightness_changed)
        bright_row.addWidget(self.bright_slider, 1)
        self.bright_value = self.label("75%", "hex")
        self.bright_value.setFixedWidth(44)
        self.bright_value.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        bright_row.addWidget(self.bright_value)
        layout.addLayout(bright_row)
        layout.addStretch()
        return card

    def build_saved_card(self):
        card, layout = self.card()
        header = QHBoxLayout()
        header.addWidget(self.h3("Сохранённые"))
        header.addStretch()
        self.saved_count = self.label("", "mut")
        header.addWidget(self.saved_count)
        layout.addLayout(header)
        layout.addSpacing(12)
        self.saved_row = QHBoxLayout()
        self.saved_row.setSpacing(8)
        layout.addLayout(self.saved_row)
        return card

    # ---------- инструменты ----------
    def on_tool(self, key):
        if key == "draw":
            self.matrix.picker_mode = False
            self.matrix.eraser_mode = False
        elif key == "eraser":
            self.matrix.picker_mode = False
            self.matrix.eraser_mode = True
        elif key == "pick":
            self.matrix.eraser_mode = False
            self.matrix.picker_mode = True
        elif key == "fill":
            self.fill_matrix()
        elif key == "trash":
            self.clear_matrix()
        self.refresh_tools()

    def refresh_tools(self):
        if self.matrix.picker_mode:
            active = "pick"
        elif self.matrix.eraser_mode:
            active = "eraser"
        else:
            active = "draw"
        for key in ("draw", "eraser", "pick"):
            self.tool_buttons[key].setChecked(key == active)
        self.matrix.setCursor(
            Qt.CursorShape.PointingHandCursor if active == "pick" else Qt.CursorShape.CrossCursor
        )

    def on_color_picked(self, color):
        self.set_color(color)
        self.matrix.picker_mode = False
        self.refresh_tools()

    # ---------- цвет ----------
    def set_color(self, color, origin=None):
        self.current_color = QColor(color)
        self.matrix.set_active_color(self.current_color)
        if self.matrix.eraser_mode or self.matrix.picker_mode:
            self.matrix.eraser_mode = False
            self.matrix.picker_mode = False
            self.refresh_tools()
        if origin != "wheel":
            self.color_wheel.set_color_silent(self.current_color)

        name = self.current_color.name()
        self.big_swatch.set_color(self.current_color)
        glow = QColor(self.current_color)
        glow.setAlpha(140)
        self.swatch_shadow.setColor(glow)
        self.hex_edit.setText(name.upper())
        self.rgb_label.setText(
            f"R{self.current_color.red()} G{self.current_color.green()} B{self.current_color.blue()}"
        )
        for swatch, value in self.quick_swatches:
            swatch.set_state(value, value.upper() == name.upper())
        self.refresh_custom()

    def on_hex_edited(self):
        color = QColor(self.hex_edit.text().strip())
        if color.isValid():
            self.set_color(color, origin="hex")
        else:
            self.hex_edit.setText(self.current_color.name().upper())

    def refresh_custom(self):
        for index, swatch in enumerate(self.custom_swatches):
            swatch.set_state(self.custom_colors[index], index == self.custom_slot)

    def on_custom_clicked(self, index):
        # клик только выбирает кружок — сохранённый цвет случайно не перезапишется
        self.custom_slot = index
        value = self.custom_colors[index]
        if value:
            self.set_color(value)
        self.refresh_custom()

    def save_custom_color(self):
        index = self.custom_slot
        if index is None:
            empty = [i for i, value in enumerate(self.custom_colors) if not value]
            if not empty:
                self.custom_save_button.setText("ВЫБЕРИ КРУЖОК")
                self.custom_feedback.start(1500)
                return
            index = empty[0]
        self.custom_slot = index
        self.custom_colors[index] = self.current_color.name().upper()
        self.settings.setValue("my_colors", ",".join(self.custom_colors))
        self.settings.sync()
        self.custom_save_button.setText("СОХРАНЕНО ✓")
        self.custom_feedback.start(1200)
        self.refresh_custom()

    # ---------- яркость ----------
    def set_brightness_widgets(self, value):
        for slider in (self.bright_slider, self.mode_bright_slider):
            slider.set_silent(value)
        text = f"{value}%"
        self.bright_value.setText(text)
        self.mode_bright_value.setText(text)
        self.start_bright_value.setText(text)

    def on_brightness_changed(self, value):
        self.set_brightness_widgets(value)
        self.settings.setValue("brightness", value)
        self.send_brightness_udp(value)

    def send_brightness_udp(self, value):
        """Яркость — по UDP без задержки: ползунок тянем, гирлянда
        меняет яркость в реальном времени."""
        self.send_udp({"type": "brightness", "value": int(value)})

    # ---------- матрица и история ----------
    def matrix_snapshot(self):
        return [[QColor(c) for c in row] for row in self.matrix.pixels]

    def update_history_buttons(self):
        if hasattr(self, "undo_button"):
            self.undo_button.setEnabled(bool(self.matrix_history))
            self.redo_button.setEnabled(bool(self.matrix_redo))

    def push_matrix_history(self):
        # новое действие — «вперёд» больше некуда
        self.matrix_history.append(self.matrix_snapshot())
        del self.matrix_history[:-50]
        self.matrix_redo.clear()
        self.update_history_buttons()

    def undo_matrix(self):
        if not self.matrix_history:
            return
        self.matrix_redo.append(self.matrix_snapshot())
        del self.matrix_redo[:-50]
        self.apply_history_snapshot(self.matrix_history.pop())

    def redo_matrix(self):
        if not self.matrix_redo:
            return
        self.matrix_history.append(self.matrix_snapshot())
        del self.matrix_history[:-50]
        self.apply_history_snapshot(self.matrix_redo.pop())

    def apply_history_snapshot(self, snapshot):
        self.update_history_buttons()
        self.matrix.stop_wave()
        self.matrix.pixels = snapshot
        self.matrix.update()
        self.stop_mode()
        self.flush_matrix_send()

    def fill_matrix(self):
        self.push_matrix_history()
        self.matrix.fill_all(self.current_color)
        self.stop_mode()
        self.flush_matrix_send()

    def clear_matrix(self):
        self.push_matrix_history()
        self.matrix.clear()
        if self._mode_active:
            # идёт режим — чистим только рисунок в программе,
            # а гирлянда продолжает играть режим
            return
        self.flush_matrix_send(all_black=True)

    def on_stroke_started(self):
        """Первый клик по холсту: запоминаем для «Назад»
        и гасим режим на гирлянде, чтобы сразу началось рисование."""
        self.push_matrix_history()
        self.esp_link.drawing = True
        self._picture_timer.stop()
        self._pixel_prev = {}
        # если шёл режим — гирлянда очистится; после штриха дошлём
        # весь рисунок, чтобы на ней было то же, что и в программе
        self._resend_after_stroke = self._mode_active
        self.stop_mode()

    def on_stroke_finished(self):
        self.esp_link.drawing = False
        self.esp_link.quiet_until = time.monotonic() + 1.5
        self.flush_pixels()
        if getattr(self, "_resend_after_stroke", False):
            self._resend_after_stroke = False
            self._picture_timer.stop()
            self.flush_matrix_send()
        else:
            self._picture_timer.start()

    def led_hex(self, color):
        hex_color = color.name().upper()
        return "000000" if hex_color in OFF_HEXES else hex_color[1:]

    def on_pixel_painted(self, row, column, color):
        # только UDP — мгновенно, без TCP-handshake и без полной картинки;
        # col — номер висюльки (0..18), row — светодиод в ней (0..19)
        if not self.esp_link.is_online:
            return
        self._pixel_queue[(column, row)] = [column, row, self.led_hex(color)]
        if not self._pixel_timer.isActive():
            self._pixel_timer.start()

    def flush_pixels(self):
        self._pixel_timer.stop()
        if not self._pixel_queue:
            return
        merged = dict(self._pixel_prev)
        merged.update(self._pixel_queue)
        self._pixel_prev = dict(self._pixel_queue)
        items = list(merged.values())
        self._pixel_queue.clear()
        for i in range(0, len(items), 24):
            part = items[i:i + 24]
            if len(part) == 1:
                col, row, hex_color = part[0]
                self.send_udp({"type": "pixel", "col": col, "row": row, "color": hex_color})
            else:
                self.send_udp({"type": "pixels", "pixels": part})

    def flush_matrix_send(self, all_black=False):
        if not self.esp_link.is_online:
            return
        if all_black:
            rows = ["000000" * self.matrix.columns for _ in range(self.matrix.rows)]
        else:
            # незарисованные пиксели уходят чёрным
            rows = ["".join(self.led_hex(color) for color in row) for row in self.matrix.pixels]
        self.send_async({"type": "picture", "rows": rows})

    # ---------- сеть ----------
    def send_udp(self, payload_dict):
        """Мгновенная команда (дома — UDP, вне дома — через интернет)."""
        self.mark_sent(payload_dict)
        self.esp_link.send_udp(payload_dict)

    def send_async(self, payload_dict):
        """Команда без ожидания ответа (дома — TCP, вне дома — через интернет)."""
        self.mark_sent(payload_dict)
        self.esp_link.send_tcp(payload_dict)

    def mark_sent(self, payload_dict):
        # помним, когда сами меняли режим/скорость/яркость: пару секунд
        # не принимаем старые значения от гирлянды, чтобы ползунок не прыгал
        if not hasattr(self, "_sent_at"):
            self._sent_at = {}
        self._sent_at[payload_dict.get("type")] = time.monotonic()

    def recently_sent(self, kind, seconds=3.0):
        return time.monotonic() - getattr(self, "_sent_at", {}).get(kind, -99.0) < seconds

    def sync_from_device(self, state):
        """Синхронизация с телефоном: что выбрали там — то видно и здесь."""
        if not hasattr(self, "mode_cards"):
            return
        keys = [m[0] for m in MODE_INFO]
        mode = state.get("mode")
        if isinstance(mode, str) and not self.recently_sent("mode"):
            playing = mode if mode in keys else None
            if playing != self.active_mode:
                self.active_mode = playing
                self._mode_active = playing is not None
                if playing:
                    self.settings.setValue("last_mode", playing)
                    if playing != self.selected_mode:
                        self.select_mode(playing)
                self.refresh_modes_state()
        rnd = state.get("rnd")
        if isinstance(rnd, int) and not self.recently_sent("mode"):
            on = rnd > 0
            if on and rnd != self.rnd_every():
                self.settings.setValue("rnd_every", rnd)
                self.set_rnd_combo(rnd)
            if on != getattr(self, "random_on", False):
                self.random_on = on
                self.refresh_modes_state()
        speed = state.get("speed")
        if (self.active_mode and isinstance(speed, int) and 1 <= speed <= 100
                and not self.recently_sent("speed") and not self.recently_sent("mode")):
            key = self.active_mode
            if int(self.settings.value(f"speed_{key}", 65)) != speed:
                self.settings.setValue(f"speed_{key}", speed)
                self.mode_cards[key][2].set_speed(speed)
                if key == self.selected_mode:
                    self.speed_slider.set_silent(speed)
                    self.speed_value.setText(str(speed))
                    if self.big_preview is not None:
                        self.big_preview.set_speed(speed)
        bright = state.get("brightness")
        if (isinstance(bright, int) and 1 <= bright <= 100 and not self.recently_sent("brightness")
                and int(self.settings.value("brightness", 75)) != bright):
            self.settings.setValue("brightness", bright)
            self.set_brightness_widgets(bright)
        night = state.get("night")
        if night in (0, 1) and not self.recently_sent("night"):
            value = "true" if night == 1 else "false"
            if self.settings.value("night_mode", "false") != value:
                self.settings.setValue("night_mode", value)
                self.night_toggle.blockSignals(True)
                self.night_toggle.setChecked(night == 1)
                self.night_toggle.blockSignals(False)

    def tz_offset(self):
        tz_text = str(self.settings.value("timezone", "UTC+3")).replace("UTC", "").strip()
        try:
            return int(tz_text) if tz_text else 0
        except ValueError:
            return 0

    def on_timezone_changed(self, text):
        self.settings.setValue("timezone", text)
        if hasattr(self, "clock_tz"):
            self.refresh_clock()
        # вместе с часовым поясом отправляем и точное время
        QTimer.singleShot(350, self.send_time)

    def send_time(self):
        """Текущее время (UTC) и часовой пояс — гирлянда их запоминает
        и по ним включает сценарии, даже когда программа закрыта."""
        if not self.esp_link.is_online:
            return
        self.send_async({"type": "time", "epoch": int(time.time()), "offset": self.tz_offset()})
        self.time_sent_at = time.time()
        if hasattr(self, "clock_sync"):
            self.refresh_clock()

    def on_link_state(self, online):
        """Гирлянда появилась в сети: яркость и (по желанию) последний режим."""
        if online:
            QTimer.singleShot(900, self.after_connected)

    def after_connected(self):
        if not self.esp_link.is_online:
            return
        self.send_time()
        # сценарии не перезаписываем: общий список хранит гирлянда (см. sync_scenarios_from_device)
        self.send_night_udp()
        self.send_brightness_udp(self.bright_slider.value())
        if self.settings.value("start_last_mode", "false") == "true":
            last = str(self.settings.value("last_mode", "") or "")
            if last and not self._mode_active and (last == "random" or last in [m[0] for m in MODE_INFO]):
                self.apply_mode(last)

    # ---------- ночной режим ----------
    # Ночной режим работает на самой гирлянде (23:00–07:00, яркость 5%),
    # даже когда все приложения закрыты: время ESP берёт из NTP.
    # Тумблер только отправляет настройку {"type":"night","enabled":...}.
    def set_night_mode(self, enabled):
        self.settings.setValue("night_mode", "true" if enabled else "false")
        self.send_night_udp()

    def send_night_udp(self):
        self.send_udp({"type": "night", "enabled": self.settings.value("night_mode", "false") == "true"})

    # ---------- картинки ----------
    def load_saved_pictures(self):
        self.saved_pictures = []
        try:
            with open(self.pictures_path, "r", encoding="utf-8") as file:
                data = json.load(file)
            if isinstance(data, list):
                self.saved_pictures = [
                    item for item in data if isinstance(item, dict) and "rows" in item
                ]
        except (OSError, ValueError, UnicodeDecodeError):
            pass
        now = int(time.time() * 1000)
        count = len(self.saved_pictures)
        for i, item in enumerate(self.saved_pictures):
            if not item.get("id"):
                item["id"] = new_picture_id() + str(i)
            if not item.get("t"):
                item["t"] = now - (count - i) * 1000

    def import_old_pictures(self):
        """Установленная программа один раз забирает картинки из старой папки (PyCharm)."""
        if not INSTALLED or os.path.exists(self.pictures_path):
            return
        old = os.path.join(os.path.expanduser("~"), "PycharmProjects", "LED-Matrix-Studio", "saved_pictures.json")
        try:
            with open(old, "rb") as src, open(self.pictures_path, "wb") as dst:
                dst.write(src.read())
        except OSError:
            pass

    def persist_saved_pictures(self):
        try:
            with open(self.pictures_path, "w", encoding="utf-8") as file:
                json.dump(self.saved_pictures, file, ensure_ascii=False)
        except OSError:
            # нет прав на запись рядом с exe — не падаем
            pass

    def _normalized_row_hex(self, row_hex, columns):
        return ((row_hex or "").upper() + "000000" * columns)[: columns * 6]

    def picture_qcolors(self, rows):
        """Строки сохранённой картинки -> ряды QColor (None = выключен)."""
        columns = self.matrix.columns
        if not isinstance(rows, list):
            rows = []
        result = []
        for r in range(self.matrix.rows):
            row_hex = self._normalized_row_hex(rows[r] if r < len(rows) else "", columns)
            line = []
            for c in range(columns):
                hex_color = "#" + row_hex[c * 6:(c + 1) * 6]
                color = QColor(hex_color)
                if not color.isValid() or hex_color in OFF_HEXES or hex_color == "#000000":
                    line.append(None)
                else:
                    line.append(color)
            result.append(line)
        return result

    def save_current_picture(self, name=""):
        name = (name or "").strip() or f"Картинка {len(self.saved_pictures) + 1}"
        rows = ["".join(self.led_hex(color) for color in row) for row in self.matrix.pixels]
        self.saved_pictures.append({"id": new_picture_id(), "t": int(time.time() * 1000), "name": name, "rows": rows})
        self.persist_saved_pictures()
        self.sync_pictures()
        self.refresh_pictures()

    def load_picture(self, index):
        if not (0 <= index < len(self.saved_pictures)):
            return
        self.push_matrix_history()
        colors = self.picture_qcolors(self.saved_pictures[index].get("rows", []))
        pixels = [
            [color if color is not None else self.matrix.off_color for color in row]
            for row in colors
        ]
        self.matrix.animate_to(pixels, origin="top")
        self.stop_mode()
        self.flush_matrix_send()

    def ask_delete_picture(self, index):
        if not (0 <= index < len(self.saved_pictures)):
            return
        pic = self.saved_pictures[index]
        preview = QLabel()
        preview.setPixmap(self.picture_thumb(pic.get("rows", []), 6, 2))
        ConfirmOverlay(self, "Удалить картинку?", "«" + str(pic.get("name", "")) + "»",
                       "Вернуть её уже не получится", preview,
                       lambda p=pic: self.delete_picture_item(p))

    def delete_picture_item(self, pic):
        for i, other in enumerate(self.saved_pictures):
            if other is pic:
                self.delete_picture(i)
                return

    def delete_picture(self, index):
        if not (0 <= index < len(self.saved_pictures)):
            return
        del self.saved_pictures[index]
        self.persist_saved_pictures()
        self.refresh_pictures()
        self.sync_pictures()

    # ---------- синхронизация картинок через гирлянду (прошивка v9+) ----------
    def sync_pictures(self):
        if hasattr(self, 'peer_ledger'): return  # library exchange is peer-to-peer, never through ESP
        state = self.esp_link.state or {}
        rev = state.get("picsRev")
        if not self.esp_link.is_online or not isinstance(rev, int) or rev < 0:
            return
        if getattr(self, "_pics_syncing", False):
            self._pics_again = True
            return
        self._pics_syncing = True
        self._pics_again = False
        self._pics_step(self._pics_sync_gen(), None)

    def _pics_step(self, gen, reply):
        try:
            payload = gen.send(reply)
        except StopIteration:
            self._pics_syncing = False
            if getattr(self, "_pics_again", False):
                QTimer.singleShot(0, self.sync_pictures)
            return
        except Exception:
            self._pics_syncing = False
            return
        self.esp_link.request(payload, lambda r: QTimer.singleShot(0, lambda: self._pics_step(gen, r)), 5000)

    def _pics_sync_gen(self):
        """Сверка с гирляндой: новое — докачиваем/отправляем, удалённое — удаляем везде."""
        try:
            known = set(json.loads(str(self.settings.value("pics_known", "[]") or "[]")))
        except ValueError:
            known = set()
        changed = False
        try:
            for _attempt in range(2):
                reply = yield {"type": "pics_list"}
                try:
                    data = json.loads(reply or "")
                    items = data["items"]
                except (ValueError, KeyError, TypeError):
                    return
                remote = {it.get("id"): it for it in items if isinstance(it, dict)}
                local_ids = {p["id"] for p in self.saved_pictures}
                ops = 0
                for pic in list(self.saved_pictures):
                    if pic["id"] in remote:
                        continue
                    if pic["id"] in known:
                        # удалили на телефоне
                        self.saved_pictures.remove(pic)
                        known.discard(pic["id"])
                        changed = True
                        continue
                    answer = yield {"type": "pic_put", "id": pic["id"], "name": pic.get("name", ""),
                                    "t": int(pic.get("t", 0)), "rows": pic["rows"]}
                    if answer == "OK":
                        known.add(pic["id"])
                        ops += 1
                    elif answer is None or answer == "FULL":
                        break
                for pid, item in remote.items():
                    if pid in local_ids:
                        known.add(pid)
                        continue
                    if pid in known:
                        # удалили здесь, пока гирлянда была не в сети
                        yield {"type": "pic_del", "id": pid}
                        known.discard(pid)
                        ops += 1
                        continue
                    answer = yield {"type": "pic_get", "id": pid}
                    try:
                        got = json.loads(answer or "")
                        self.saved_pictures.append({"id": pid, "t": int(got.get("t", 0)),
                                                    "name": str(got.get("name", "")), "rows": got["rows"]})
                        known.add(pid)
                        changed = True
                    except (ValueError, KeyError, TypeError):
                        pass
                if not ops:
                    self._pics_seen_rev = data.get("rev")
                    break
        finally:
            self.settings.setValue("pics_known", json.dumps(sorted(known)))
            if changed:
                self.saved_pictures.sort(key=lambda p: p.get("t", 0))
                self.persist_saved_pictures()
                self.refresh_pictures()

    def sync_scenarios_from_device(self, lines):
        """Сценарии с телефона: гирлянда хранит общий список."""
        if hasattr(self, 'peer_ledger'): return
        if not isinstance(lines, list) or self.recently_sent("schedule", 4.0) or self.scen_send_timer.isActive():
            return
        keys = [m[0] for m in MODE_INFO] + ["random"]
        incoming = []
        for line in lines:
            parts = str(line).split(",")
            if len(parts) < 5 or parts[4] not in keys:
                continue
            try:
                on, off = int(parts[2]), int(parts[3])
                incoming.append({
                    "enabled": parts[0] == "1",
                    "mode": parts[4],
                    "on": f"{on // 60:02d}:{on % 60:02d}",
                    "off": f"{off // 60:02d}:{off % 60:02d}" if off >= 0 else "",
                    "days": int(parts[1]) & 127,
                })
            except ValueError:
                continue
        if incoming == self.scenarios:
            self.settings.setValue("scen_synced", "true")
            return
        if not incoming and self.scenarios and self.settings.value("scen_synced", "false") != "true":
            # первая встреча с гирляндой без сценариев — отдаём ей свои
            self.settings.setValue("scen_synced", "true")
            self.send_schedule()
            return
        focus = QApplication.focusWidget()
        if focus is not None and hasattr(self, "scen_list") and self.isAncestorOf(focus) and focus.objectName() == "scen_edit":
            return
        self.scenarios = incoming[:MAX_SCENARIOS]
        self.settings.setValue("scen_synced", "true")
        self.settings.setValue("scenarios", json.dumps(self.scenarios))
        self.refresh_scenarios()

    def picture_thumb(self, rows, cell, gap):
        return led_pixmap(self.picture_qcolors(rows), cell, gap, "#262626")

    def refresh_pictures(self):
        pictures = self.saved_pictures
        self.saved_count.setText(plural_pictures(len(pictures)))
        self.clear_layout(self.saved_row)
        shown = list(enumerate(pictures))[-3:][::-1]
        for index, picture in shown:
            thumb = QPushButton()
            thumb.setObjectName("thumb")
            thumb.setFixedSize(84, 88)
            thumb.setIcon(QIcon(self.picture_thumb(picture.get("rows", []), 2.8, 0.9)))
            thumb.setIconSize(QSize(70, 74))
            thumb.setToolTip(f"{picture.get('name', '')} — открыть")
            thumb.setCursor(Qt.CursorShape.PointingHandCursor)
            thumb.clicked.connect(lambda checked=False, i=index: self.load_picture(i))
            self.saved_row.addWidget(thumb)
        add = QPushButton()
        add.setObjectName("addtile")
        add.setFixedSize(46 if shown else 84, 88)
        add.setIcon(svg_icon("plus", MUTED, size=22))
        add.setIconSize(QSize(22, 22))
        add.setToolTip("Сохранить текущую картинку")
        add.setCursor(Qt.CursorShape.PointingHandCursor)
        add.clicked.connect(lambda: self.save_current_picture())
        self.saved_row.addWidget(add)
        if not shown:
            hint = self.label("Нажми +, чтобы сохранить рисунок", "hint")
            hint.setWordWrap(True)
            self.saved_row.addWidget(hint, 1)
        self.saved_row.addStretch()
        self.refresh_pictures_page()

    def build_pictures_page(self):
        page = QWidget()
        row = QHBoxLayout(page)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(16)

        new_card, layout = self.card()
        new_card.setFixedWidth(300)
        layout.addWidget(self.h3("Новая картинка"))
        layout.addSpacing(14)
        self.current_preview = QLabel()
        self.current_preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.current_preview)
        layout.addSpacing(6)
        layout.addWidget(self.label("Название", "lbl", caps=True))
        layout.addSpacing(6)
        self.new_name = QLineEdit()
        self.new_name.setPlaceholderText("Например, Сердечко")
        self.new_name.returnPressed.connect(self.save_picture_named)
        layout.addWidget(self.new_name)
        layout.addSpacing(12)
        save = self.button("Сохранить", "btnr", icon="plus")
        save.clicked.connect(self.save_picture_named)
        layout.addWidget(save)
        layout.addStretch()
        row.addWidget(new_card)

        list_card, list_layout = self.card()
        header = QHBoxLayout()
        header.addWidget(self.h3("Сохранённые"))
        header.addStretch()
        self.pictures_count = self.label("", "mut")
        header.addWidget(self.pictures_count)
        list_layout.addLayout(header)
        list_layout.addSpacing(14)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        container = QWidget()
        # только сам контейнер прозрачный — не перебиваем стили кнопок внутри
        container.setObjectName("scrollbox")
        container.setStyleSheet("QWidget#scrollbox { background: transparent; }")
        self.pictures_grid = QGridLayout(container)
        self.pictures_grid.setContentsMargins(0, 0, 6, 0)
        self.pictures_grid.setSpacing(12)
        self.pictures_grid.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        scroll.setWidget(container)
        list_layout.addWidget(scroll, 1)
        row.addWidget(list_card, 1)
        return page

    def save_picture_named(self):
        self.save_current_picture(self.new_name.text())
        self.new_name.clear()

    def refresh_current_preview(self):
        colors = [
            [None if self.matrix.is_off(color) else QColor(color) for color in row]
            for row in self.matrix.pixels
        ]
        self.current_preview.setPixmap(led_pixmap(colors, 10, 3, DOT_OFF, pad=12, bg="#000000"))

    def refresh_pictures_page(self):
        if not hasattr(self, "pictures_grid"):
            return
        pictures = self.saved_pictures
        self.pictures_count.setText(plural_pictures(len(pictures)))
        self.clear_layout(self.pictures_grid)
        if not pictures:
            empty = self.label(
                "Пока нет сохранённых картинок.\nНарисуй что-нибудь и сохрани слева.", "mut13"
            )
            self.pictures_grid.addWidget(empty, 0, 0)
            return
        for index, picture in enumerate(pictures):
            tile = QFrame()
            tile.setObjectName("tile")
            tile_layout = QVBoxLayout(tile)
            tile_layout.setContentsMargins(10, 10, 10, 10)
            tile_layout.setSpacing(8)
            thumb = QPushButton()
            thumb.setObjectName("thumbbig")
            thumb.setIcon(QIcon(self.picture_thumb(picture.get("rows", []), 5, 2)))
            thumb.setIconSize(QSize(131, 138))
            thumb.setFixedSize(147, 154)
            thumb.setCursor(Qt.CursorShape.PointingHandCursor)
            thumb.setToolTip("Открыть на холсте")
            thumb.clicked.connect(lambda checked=False, i=index: self.open_picture(i))
            tile_layout.addWidget(thumb, 0, Qt.AlignmentFlag.AlignHCenter)
            name_row = QHBoxLayout()
            name = QLabel(str(picture.get("name", "")))
            name.setStyleSheet("font-size: 12px;")
            name.setMaximumWidth(110)
            name_row.addWidget(name, 1)
            delete = QPushButton()
            delete.setObjectName("toolsm")
            delete.setFixedSize(30, 30)
            delete.setIcon(svg_icon("trash", MUTED2, size=16))
            delete.setIconSize(QSize(16, 16))
            delete.setToolTip("Удалить")
            delete.setCursor(Qt.CursorShape.PointingHandCursor)
            delete.clicked.connect(lambda checked=False, i=index: self.ask_delete_picture(i))
            name_row.addWidget(delete)
            tile_layout.addLayout(name_row)
            self.pictures_grid.addWidget(tile, index // 4, index % 4)

    def open_picture(self, index):
        # сначала открываем матрицу, чтобы картинка проявилась волной
        self.show_page(0)
        self.load_picture(index)

    # ---------- Режимы ----------
    def build_modes_page(self):
        page = QWidget()
        row = QHBoxLayout(page)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(16)

        # режимов больше, чем влезает в окно — сетка прокручивается
        modes_scroll = QScrollArea()
        modes_scroll.setWidgetResizable(True)
        modes_scroll.setFrameShape(QFrame.Shape.NoFrame)
        modes_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        grid_widget = QWidget()
        grid_widget.setObjectName("modebox")
        grid_widget.setStyleSheet("QWidget#modebox { background: transparent; }")
        modes_scroll.setWidget(grid_widget)
        modes_scroll.viewport().setObjectName("modeview")
        modes_scroll.viewport().setStyleSheet("QWidget#modeview { background: transparent; }")
        modes_scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        grid = QGridLayout(grid_widget)
        grid.setContentsMargins(0, 0, 6, 0)
        grid.setSpacing(14)
        grid.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.mode_cards = {}
        for index, (key, title, description) in enumerate(MODE_INFO):
            card = ModeCard()
            card.setObjectName("mode")
            card.setCursor(Qt.CursorShape.PointingHandCursor)
            card.clicked.connect(lambda k=key: self.select_mode(k))
            card.hovered.connect(lambda inside, k=key: self.on_mode_hover(k, inside))
            layout = QVBoxLayout(card)
            layout.setContentsMargins(12, 12, 12, 12)
            layout.setSpacing(10)
            frame = QFrame()
            frame.setObjectName("ledbg")
            frame_layout = QVBoxLayout(frame)
            frame_layout.setContentsMargins(10, 10, 10, 10)
            preview = ModePreviewWidget(key, frame)
            preview.gap = 2
            preview.setMinimumHeight(0)
            preview.setFixedSize(MATRIX_COLUMNS * 7 + (MATRIX_COLUMNS-1) * 2, 20 * 7 + 19 * 2)
            preview.set_speed(int(self.settings.value(f"speed_{key}", 65)))
            frame_layout.addWidget(preview, 0, Qt.AlignmentFlag.AlignCenter)
            layout.addWidget(frame)
            info_row = QHBoxLayout()
            info = QVBoxLayout()
            info.setSpacing(2)
            info.addWidget(self.label(title, "name15", caps=True, track=1.5))
            desc = self.label(description, "mut")
            desc.setWordWrap(True)
            info.addWidget(desc)
            info_row.addLayout(info, 1)
            toggle = ToggleSwitch()
            toggle.clicked.connect(lambda checked=False, k=key: self.on_mode_toggle(k, checked))
            # скрытый тумблер держит место, чтобы текст не прыгал
            policy = toggle.sizePolicy()
            policy.setRetainSizeWhenHidden(True)
            toggle.setSizePolicy(policy)
            info_row.addWidget(toggle, 0, Qt.AlignmentFlag.AlignTop)
            layout.addLayout(info_row)
            layout.addStretch()
            grid.addWidget(card, index // 3, index % 3)
            self.mode_cards[key] = (card, toggle, preview)

        soon = QFrame()
        soon.setObjectName("mode_soon")
        soon_layout = QVBoxLayout(soon)
        soon_layout.addStretch()
        plus = QLabel()
        plus.setPixmap(svg_pixmap("plus", MUTED, 28))
        plus.setAlignment(Qt.AlignmentFlag.AlignCenter)
        soon_layout.addWidget(plus)
        soon_text = self.label("Скоро новые режимы", "mut13")
        soon_text.setAlignment(Qt.AlignmentFlag.AlignCenter)
        soon_layout.addWidget(soon_text)
        soon_layout.addStretch()
        soon.setMinimumHeight(120)
        grid.addWidget(soon, len(MODE_INFO) // 3, len(MODE_INFO) % 3)
        for column in range(3):
            grid.setColumnStretch(column, 1)
        row.addWidget(modes_scroll, 1)

        side, layout = self.card()
        side.setFixedWidth(320)
        self.side_header = self.h3("Сейчас играет")
        layout.addWidget(self.side_header)
        layout.addSpacing(12)
        big_frame = QFrame()
        big_frame.setObjectName("ledbg")
        big_layout = QVBoxLayout(big_frame)
        big_layout.setContentsMargins(12, 12, 12, 12)
        # одно большое превью, у него просто меняется режим
        self.big_preview_layout = big_layout
        self.big_preview = None
        layout.addWidget(big_frame)
        layout.addSpacing(12)
        self.side_name = self.label("", "name22", caps=True, track=1.5)
        layout.addWidget(self.side_name)
        self.side_desc = self.label("", "mut13")
        layout.addWidget(self.side_desc)
        layout.addSpacing(12)

        speed_row = QHBoxLayout()
        speed_row.addWidget(self.label("Скорость", None, caps=True, track=1.5))
        speed_row.addStretch()
        self.speed_value = self.label("65", "value")
        speed_row.addWidget(self.speed_value)
        layout.addLayout(speed_row)
        layout.addSpacing(8)
        self.speed_slider = DotSlider()
        self.speed_slider.setRange(1, 100)
        self.speed_slider.valueChanged.connect(self.on_speed_changed)
        layout.addWidget(self.speed_slider)
        layout.addSpacing(12)

        bright_row = QHBoxLayout()
        bright_row.addWidget(self.label("Яркость", None, caps=True, track=1.5))
        bright_row.addStretch()
        self.mode_bright_value = self.label("75%", "value")
        bright_row.addWidget(self.mode_bright_value)
        layout.addLayout(bright_row)
        layout.addSpacing(8)
        self.mode_bright_slider = DotSlider()
        self.mode_bright_slider.setRange(5, 100)
        self.mode_bright_slider.valueChanged.connect(self.on_brightness_changed)
        layout.addWidget(self.mode_bright_slider)
        layout.addSpacing(14)

        rnd_row = QHBoxLayout()
        rnd_row.addWidget(self.label("Случайный: смена", None, caps=True, track=1.5))
        rnd_row.addStretch()
        self.rnd_combo = QComboBox()
        self.rnd_combo.setObjectName("modecombo")
        self.rnd_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        for minutes, text in RANDOM_INTERVALS:
            self.rnd_combo.addItem(text, minutes)
        self.set_rnd_combo(self.rnd_every())
        self.rnd_combo.currentIndexChanged.connect(self.on_rnd_every)
        rnd_row.addWidget(self.rnd_combo)
        layout.addLayout(rnd_row)
        layout.addStretch()

        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        # режимы включаются тумблером на карточке; «Случайно» — гирлянда сама меняет режимы
        self.random_button = self.button("Случайно", icon="shuffle")
        self.random_button.setToolTip("Режимы будут сменять друг друга. Нажми ещё раз — сразу следующий")
        self.random_button.clicked.connect(self.start_random)
        buttons.addWidget(self.random_button, 1)
        stop = self.button("Стоп")
        stop.clicked.connect(self.stop_mode_forced)
        buttons.addWidget(stop, 1)
        layout.addLayout(buttons)
        row.addWidget(side)
        return page

    def select_mode(self, key):
        self.selected_mode = key
        title, description = next((t, d) for k, t, d in MODE_INFO if k == key)
        self.side_name.setText(title.upper())
        self.side_desc.setText(description)
        if self.big_preview is not None:
            self.big_preview.deleteLater()
        preview = ModePreviewWidget(key)
        preview.gap = 3
        preview.setMinimumHeight(0)
        preview.setFixedSize(MATRIX_COLUMNS * 9 + (MATRIX_COLUMNS-1) * 3, 20 * 9 + 19 * 3)
        self.big_preview_layout.addWidget(preview, 0, Qt.AlignmentFlag.AlignCenter)
        self.big_preview = preview
        if self.isVisible():
            # новое превью плавно проявляется
            effect = QGraphicsOpacityEffect(preview)
            effect.setOpacity(0.0)
            preview.setGraphicsEffect(effect)
            fade = QPropertyAnimation(effect, b"opacity", preview)
            fade.setDuration(320)
            fade.setStartValue(0.0)
            fade.setEndValue(1.0)
            fade.setEasingCurve(QEasingCurve.Type.OutCubic)
            fade.finished.connect(lambda p=preview: p.setGraphicsEffect(None))
            fade.start()
        speed = int(self.settings.value(f"speed_{key}", 65))
        self.speed_slider.set_silent(speed)
        self.speed_value.setText(str(speed))
        preview.set_speed(speed)
        self.refresh_modes_state()

    def on_speed_changed(self, value):
        key = self.selected_mode
        self.speed_value.setText(str(value))
        self.settings.setValue(f"speed_{key}", value)
        if self.big_preview is not None:
            self.big_preview.set_speed(value)
        self.mode_cards[key][2].set_speed(value)
        # скорость уходит на гирлянду не чаще раза в 120 мс
        self._pending_speed = (key, int(value))
        self.mode_speed_timer.start()

    def flush_mode_speed(self):
        if hasattr(self, "_pending_speed"):
            key, speed = self._pending_speed
            if self.active_mode and self.active_mode != key:
                return   # на гирлянде играет другой режим — его скорость не трогаем
            # ползунок только меняет скорость — режим не запускает
            self.send_udp({"type": "speed", "mode": key, "value": speed})

    def rnd_every(self):
        try:
            return int(self.settings.value("rnd_every", 15))
        except (TypeError, ValueError):
            return 15

    def set_rnd_combo(self, minutes):
        index = self.rnd_combo.findData(minutes)
        if index < 0:
            self.rnd_combo.addItem(f"{minutes} мин", minutes)
            index = self.rnd_combo.count() - 1
        self.rnd_combo.blockSignals(True)
        self.rnd_combo.setCurrentIndex(index)
        self.rnd_combo.blockSignals(False)

    def on_rnd_every(self, _index):
        self.settings.setValue("rnd_every", int(self.rnd_combo.currentData()))
        if getattr(self, "random_on", False):
            self.start_random()
        if hasattr(self, "scenarios") and any(it["mode"] == "random" for it in self.scenarios):
            self.scen_send_timer.start()

    def start_random(self):
        if 0 < self.device_fw() < 10:
            from PyQt6.QtWidgets import QToolTip
            b = self.random_button
            QToolTip.showText(b.mapToGlobal(b.rect().topLeft()),
                              "Случайный режим появился в прошивке v10 — обновите гирлянду в Настройках", b)
        speeds = ",".join(str(int(self.settings.value(f"speed_{k}", 65))) for k, _t, _d in MODE_INFO)
        self.random_on = True
        self._mode_active = True
        self.settings.setValue("last_mode", "random")
        self.send_udp({"type": "mode", "mode": "random", "every": self.rnd_every(), "speeds": speeds})
        self.refresh_modes_state()
        # какой режим выпал — сразу спрашиваем у гирлянды
        QTimer.singleShot(400, self.poll_after_random)

    def poll_after_random(self):
        getattr(self, "_sent_at", {}).pop("mode", None)
        self.esp_link.poll_state()

    def apply_mode(self, key):
        if key in NEW_MODE_KEYS and 0 < self.device_fw() < 15:
            from PyQt6.QtWidgets import QToolTip
            QToolTip.showText(self.mapToGlobal(self.rect().center()), "Новые режимы требуют прошивку v15 — обновите гирлянду в Настройках", self)
            return
        if key == "random":
            self.start_random()
            return
        self.random_on = False
        self._mode_active = True
        self.active_mode = key
        self.settings.setValue("last_mode", key)
        # UDP вместо TCP: без handshake, поэтому режим включается мгновенно
        self.send_udp({"type": "mode", "mode": key, "speed": int(self.settings.value(f"speed_{key}", 65))})
        self.refresh_modes_state()

    def stop_mode(self):
        """Выключает режим и гасит гирлянду. При рисовании вызывается
        на каждый штрих, поэтому шлёт команду только если режим шёл."""
        if not self._mode_active:
            return
        self._mode_active = False
        self.active_mode = None
        self.random_on = False
        self.send_udp({"type": "mode", "mode": "off", "speed": 65})
        self.send_udp({"type": "clear"})
        self.refresh_modes_state()

    def stop_mode_forced(self):
        self._mode_active = True
        self.stop_mode()

    def on_mode_hover(self, key, inside):
        self.hovered_mode = key if inside else None
        _card, toggle, _preview = self.mode_cards[key]
        toggle.set_highlight(inside)
        self.refresh_modes_state()

    def on_mode_toggle(self, key, checked):
        if checked and key in EXTRA_SIMS and key not in NEW_MODE_KEYS and 0 < self.device_fw() < 8:
            # старая прошивка не знает новых режимов — подсказываем обновиться
            from PyQt6.QtWidgets import QToolTip
            toggle = self.mode_cards[key][1]
            QToolTip.showText(toggle.mapToGlobal(toggle.rect().bottomLeft()),
                              "Этот режим появился в прошивке v8 — обновите гирлянду в Настройках", toggle)
        if checked:
            self.select_mode(key)
            self.apply_mode(key)
        else:
            self.stop_mode_forced()
        self.refresh_modes_state()

    def refresh_modes_state(self):
        if not hasattr(self, "mode_cards"):
            return
        playing = self.active_mode
        for key, (_card, toggle, _preview) in self.mode_cards.items():
            toggle.setChecked(key == playing)
            hovered = key == getattr(self, "hovered_mode", None)
            toggle.setVisible(key == playing or hovered)
        random_on = getattr(self, "random_on", False)
        if playing and playing == self.selected_mode:
            text = "Сейчас играет · случайно" if random_on else "Сейчас играет"
        else:
            text = "Выбранный режим"
        self.side_header.setText(h3_html(text))
        if hasattr(self, "random_button"):
            self.random_button.setStyleSheet(
                f"QPushButton {{ border: 2px solid {ACCENT}; color: #FFFFFF; }}" if random_on else ""
            )

    # ---------- Сценарии ----------
    def build_scenarios_page(self):
        page = QWidget()
        row = QHBoxLayout(page)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(16)

        list_card, list_layout = self.card()
        header = QHBoxLayout()
        header.addWidget(self.h3("Включение по времени"))
        header.addStretch()
        self.scen_count = self.label("", "mut")
        header.addWidget(self.scen_count)
        header.addSpacing(12)
        self.scen_add = self.button("Добавить", small=True)
        self.scen_add.setIcon(svg_icon("plus", FG, size=14))
        self.scen_add.setIconSize(QSize(14, 14))
        self.scen_add.clicked.connect(self.add_scenario)
        header.addWidget(self.scen_add)
        list_layout.addLayout(header)
        list_layout.addSpacing(14)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        container = QWidget()
        # только сам контейнер прозрачный — не перебиваем стили кнопок внутри
        container.setObjectName("scrollbox")
        container.setStyleSheet("QWidget#scrollbox { background: transparent; }")
        self.scen_list = QVBoxLayout(container)
        self.scen_list.setContentsMargins(0, 0, 6, 0)
        self.scen_list.setSpacing(10)
        scroll.setWidget(container)
        list_layout.addWidget(scroll, 1)
        row.addWidget(list_card, 1)

        side, layout = self.card()
        side.setFixedWidth(300)
        layout.addWidget(self.h3("Время"))
        layout.addSpacing(22)
        self.clock_label = QLabel()
        self.clock_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.clock_label)
        layout.addSpacing(14)
        self.clock_date = self.label("", "mut13")
        self.clock_date.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.clock_date)
        layout.addSpacing(4)
        self.clock_tz = self.label("", "mut")
        self.clock_tz.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(self.clock_tz)
        layout.addSpacing(22)
        sync_row = QHBoxLayout()
        sync_row.setSpacing(8)
        self.clock_dot = StatusDot()
        sync_row.addWidget(self.clock_dot)
        self.clock_sync = self.label("", "mut")
        self.clock_sync.setWordWrap(True)
        sync_row.addWidget(self.clock_sync, 1)
        layout.addLayout(sync_row)
        layout.addSpacing(12)
        sync_button = self.button("Отправить время")
        sync_button.clicked.connect(self.send_time_now)
        layout.addWidget(sync_button)
        layout.addStretch()
        note = self.label(
            "Сценарии и время хранятся в самой гирлянде: она включит режим "
            "по расписанию, даже если программа закрыта. Если гирлянду "
            "обесточить, время восстановится из интернета (при домашнем Wi-Fi) "
            "или при следующем запуске программы.",
            "hint",
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        row.addWidget(side)

        self.refresh_scenarios()
        return page

    # ---------- сценарии: данные ----------
    def load_scenarios(self):
        try:
            data = json.loads(str(self.settings.value("scenarios", "[]") or "[]"))
        except ValueError:
            data = []
        keys = [m[0] for m in MODE_INFO] + ["random"]
        result = []
        for item in data if isinstance(data, list) else []:
            if not isinstance(item, dict) or item.get("mode") not in keys:
                continue
            result.append({
                "id": item.get("id", ""),
                "enabled": bool(item.get("enabled", True)),
                "mode": item["mode"],
                "on": str(item.get("on", "18:00"))[:5],
                "off": str(item.get("off", "") or "")[:5],
                "days": int(item.get("days", 127)) & 127,
            })
        return result  # peer merge must never silently discard saved scenarios

    def persist_scenarios(self):
        self.settings.setValue("scenarios", json.dumps(self.scenarios))
        self.scen_send_timer.start()

    @staticmethod
    def minutes(text):
        try:
            hours, mins = text.split(":")
            return int(hours) * 60 + int(mins)
        except (ValueError, AttributeError):
            return -1

    def send_schedule(self):
        """Все сценарии одной командой: «вкл,дни,начало,конец,режим,скорость»."""
        if not self.esp_link.is_online:
            return
        if len(self.scenarios)>MAX_SCENARIOS:
            self.update_result.setText('Сценарии сохранены, но не отправлены: гирлянда поддерживает максимум 8. Удали лишние.')
            return
        items = []
        for item in self.scenarios[:MAX_SCENARIOS]:
            if item["mode"] == "random":
                speed = self.rnd_every()   # для случайного — интервал смены, минуты
            else:
                speed = int(self.settings.value(f"speed_{item['mode']}", 65))
            items.append(",".join(str(v) for v in (
                1 if item["enabled"] else 0,
                item["days"],
                self.minutes(item["on"]),
                self.minutes(item["off"]) if item["off"] else -1,
                item["mode"],
                speed,
            )))
        self.send_async({"type": "schedule", "items": items})

    def add_scenario(self):
        if len(self.scenarios) >= MAX_SCENARIOS:
            return
        self.scenarios.append({"enabled": True, "mode": self.selected_mode, "on": "18:00", "off": "23:00", "days": 127})
        self.persist_scenarios()
        self.refresh_scenarios(animate_last=True)

    def ask_delete_scenario(self, index):
        if not (0 <= index < len(self.scenarios)):
            return
        item = self.scenarios[index]
        if item["mode"] in [m[0] for m in MODE_INFO]:
            preview = ModePreviewWidget(item["mode"])
            preview.gap = 2
            preview.setMinimumHeight(0)
            preview.setFixedSize(MATRIX_COLUMNS * 6 + (MATRIX_COLUMNS-1) * 2, 20 * 6 + 19 * 2)
            preview.set_speed(int(self.settings.value(f"speed_{item['mode']}", 65)))
        else:
            preview = QLabel()
            preview.setPixmap(svg_pixmap("shuffle", FG, 64))
        ConfirmOverlay(self, "Удалить сценарий?", self.scenario_summary(item),
                       "Гирлянда перестанет включаться по нему", preview,
                       lambda it=item: self.delete_scenario_item(it))

    def delete_scenario_item(self, item):
        # по ссылке, а не по номеру: список мог обновиться, пока открыто окно
        for i, other in enumerate(self.scenarios):
            if other is item:
                self.delete_scenario(i)
                return

    def delete_scenario(self, index):
        if 0 <= index < len(self.scenarios):
            del self.scenarios[index]
            self.persist_scenarios()
            self.refresh_scenarios()

    def update_scenario(self, index, **changes):
        if not (0 <= index < len(self.scenarios)):
            return
        self.scenarios[index].update(changes)
        self.persist_scenarios()
        frame, summary = self.scen_rows[index]
        if "enabled" in changes:
            frame.setProperty("on", "true" if changes["enabled"] else "false")
            for widget in [frame] + frame.findChildren(QWidget):
                widget.style().unpolish(widget)
                widget.style().polish(widget)
        summary.setText(self.scenario_summary(self.scenarios[index]))

    def scenario_summary(self, item):
        days = item["days"]
        if days == 127:
            when = "каждый день"
        elif days == 31:
            when = "по будням"
        elif days == 96:
            when = "по выходным"
        elif days == 0:
            when = "дни не выбраны"
        else:
            when = ", ".join(WEEKDAYS[i] for i in range(7) if days >> i & 1)
        title = mode_title(item["mode"])
        text = f"{title} в {item['on']}"
        if item["off"]:
            text += f", выкл. в {item['off']}"
        return f"{text} · {when}"

    # ---------- сценарии: интерфейс ----------
    def refresh_scenarios(self, animate_last=False):
        self.clear_layout(self.scen_list)
        self.scen_rows = []
        count = len(self.scenarios)
        self.scen_count.setText(f"{count} / {MAX_SCENARIOS}")
        self.scen_add.setEnabled(count < MAX_SCENARIOS)
        if not count:
            empty = QWidget()
            box = QVBoxLayout(empty)
            box.addSpacing(70)
            icon = QLabel()
            icon.setPixmap(svg_pixmap("clock", MUTED, 44, 1.4))
            icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
            box.addWidget(icon)
            box.addSpacing(14)
            title = self.label("Сценариев пока нет", "name19", caps=True, track=1.5)
            title.setAlignment(Qt.AlignmentFlag.AlignCenter)
            box.addWidget(title)
            box.addSpacing(6)
            text = self.label(
                "Нажми «Добавить» — и гирлянда сама включит\nнужный режим в заданное время.", "mut13"
            )
            text.setAlignment(Qt.AlignmentFlag.AlignCenter)
            box.addWidget(text)
            self.scen_list.addWidget(empty)
            self.scen_list.addStretch()
            return
        for index, item in enumerate(self.scenarios):
            frame = self.build_scenario_row(index, item)
            self.scen_list.addWidget(frame)
            if animate_last and index == count - 1:
                # новая карточка плавно проявляется
                effect = QGraphicsOpacityEffect(frame)
                effect.setOpacity(0.0)
                frame.setGraphicsEffect(effect)
                fade = QPropertyAnimation(effect, b"opacity", frame)
                fade.setDuration(350)
                fade.setStartValue(0.0)
                fade.setEndValue(1.0)
                fade.setEasingCurve(QEasingCurve.Type.OutCubic)
                fade.finished.connect(lambda f=frame: f.setGraphicsEffect(None))
                fade.start()
        self.scen_list.addStretch()

    def build_scenario_row(self, index, item):
        frame = QFrame()
        frame.setObjectName("scen")
        frame.setProperty("on", "true" if item["enabled"] else "false")
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(16, 12, 12, 12)
        layout.setSpacing(10)

        top = QHBoxLayout()
        top.setSpacing(10)
        toggle = ToggleSwitch()
        toggle.setChecked(item["enabled"])
        toggle.setToolTip("Сценарий включён / выключен")
        toggle.toggled.connect(lambda on, i=index: self.update_scenario(i, enabled=on))
        top.addWidget(toggle)
        combo = QComboBox()
        combo.setObjectName("modecombo")
        combo.setCursor(Qt.CursorShape.PointingHandCursor)
        for key, title, _desc in MODE_INFO:
            combo.addItem(title, key)
        combo.addItem("Случайный", "random")
        combo.setCurrentIndex(max(0, combo.findData(item["mode"])))
        combo.currentIndexChanged.connect(
            lambda _n, i=index, c=combo: self.update_scenario(i, mode=c.currentData())
        )
        top.addWidget(combo)
        top.addStretch()

        top.addWidget(self.label("Вкл", "lbl", caps=True))
        on_edit = QTimeEdit(QTime.fromString(item["on"], "HH:mm"))
        on_edit.setDisplayFormat("HH:mm")
        on_edit.setButtonSymbols(QTimeEdit.ButtonSymbols.NoButtons)
        on_edit.setToolTip("Время включения")
        on_edit.timeChanged.connect(
            lambda t, i=index: self.update_scenario(i, on=t.toString("HH:mm"))
        )
        top.addWidget(on_edit)
        top.addSpacing(6)

        off_chip = QPushButton("ВЫКЛ")
        off_chip.setObjectName("chip")
        off_chip.setCheckable(True)
        off_chip.setChecked(bool(item["off"]))
        off_chip.setCursor(Qt.CursorShape.PointingHandCursor)
        off_chip.setToolTip("Выключать гирлянду в заданное время")
        set_tracking(off_chip, 1.5)
        top.addWidget(off_chip)
        off_edit = QTimeEdit(QTime.fromString(item["off"] or "23:00", "HH:mm"))
        off_edit.setDisplayFormat("HH:mm")
        off_edit.setButtonSymbols(QTimeEdit.ButtonSymbols.NoButtons)
        off_edit.setEnabled(bool(item["off"]))
        off_edit.setToolTip("Время выключения")
        off_edit.timeChanged.connect(
            lambda t, i=index, chip=off_chip: chip.isChecked()
            and self.update_scenario(i, off=t.toString("HH:mm"))
        )
        off_chip.toggled.connect(
            lambda on, i=index, edit=off_edit: (
                edit.setEnabled(on),
                self.update_scenario(i, off=edit.time().toString("HH:mm") if on else ""),
            )
        )
        top.addWidget(off_edit)
        top.addSpacing(4)
        delete = QPushButton()
        delete.setObjectName("toolsm")
        delete.setFixedSize(30, 30)
        delete.setIcon(svg_icon("trash", MUTED2, size=16))
        delete.setIconSize(QSize(16, 16))
        delete.setToolTip("Удалить сценарий")
        delete.setCursor(Qt.CursorShape.PointingHandCursor)
        delete.clicked.connect(lambda checked=False, i=index: self.ask_delete_scenario(i))
        top.addWidget(delete)
        layout.addLayout(top)

        bottom = QHBoxLayout()
        bottom.setSpacing(6)
        day_buttons = []
        for day in range(7):
            chip = QPushButton(WEEKDAYS[day].upper())
            chip.setObjectName("day")
            chip.setCheckable(True)
            chip.setChecked(bool(item["days"] >> day & 1))
            chip.setCursor(Qt.CursorShape.PointingHandCursor)
            bottom.addWidget(chip)
            day_buttons.append(chip)
        for chip in day_buttons:
            chip.toggled.connect(
                lambda _on, i=index, buttons=day_buttons: self.update_scenario(
                    i, days=sum(1 << d for d, b in enumerate(buttons) if b.isChecked())
                )
            )
        bottom.addSpacing(10)
        summary = self.label(self.scenario_summary(item), "mut")
        bottom.addWidget(summary, 1)
        layout.addLayout(bottom)
        self.scen_rows.append((frame, summary))
        return frame

    def send_time_now(self):
        if not self.esp_link.is_online:
            self.clock_sync.setText("Гирлянда не в сети — время уйдёт при подключении")
            return
        self.send_time()
        QTimer.singleShot(500, self.send_schedule)

    def refresh_clock(self):
        if not hasattr(self, "clock_label"):
            return
        now = time.localtime()
        colon = ":" if now.tm_sec % 2 == 0 else ";"
        text = time.strftime("%H", now) + colon + time.strftime("%M", now)
        if getattr(self, "_clock_text", None) != text:
            self._clock_text = text
            # двоеточие мигает раз в секунду
            self.clock_label.setPixmap(dot_text_pixmap(text, 5.0, 2.0, "#FFFFFF", "#161616"))
        months = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля",
                  "августа", "сентября", "октября", "ноября", "декабря"]
        self.clock_date.setText(f"{now.tm_mday} {months[now.tm_mon - 1]}, {WEEKDAYS_FULL[now.tm_wday]}")
        offset = self.tz_offset()
        self.clock_tz.setText(f"Часовой пояс гирлянды: UTC{offset:+d}")
        if not self.esp_link.is_online:
            self.clock_dot.set_state("offline", "#555555")
            self.clock_sync.setText("Гирлянда не в сети — время уйдёт при подключении")
        elif self.time_sent_at:
            self.clock_dot.set_state("online", ACCENT)
            sent = time.strftime("%H:%M", time.localtime(self.time_sent_at))
            self.clock_sync.setText(f"Время отправлено на гирлянду в {sent}")
        else:
            self.clock_dot.set_state("search", "#8E8E93")
            self.clock_sync.setText("Отправляю время…")

    # ---------- Настройки ----------
    def list_row(self, icon, title, right, last=False):
        frame = QFrame()
        frame.setObjectName("li_last" if last else "li")
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(0, 11, 0, 11)
        layout.setSpacing(12)
        icon_label = QLabel()
        icon_label.setPixmap(svg_pixmap(icon, MUTED, 19))
        layout.addWidget(icon_label)
        layout.addWidget(QLabel(title))
        layout.addStretch()
        layout.addWidget(right)
        return frame

    def build_settings_page(self):
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        page = QWidget()
        page.setObjectName("setbox")
        page.setStyleSheet("QWidget#setbox { background: transparent; }")
        scroll.setWidget(page)
        # стиль только для самого viewport: без селектора он перекрывал фон всех кнопок внутри
        scroll.viewport().setObjectName("setview")
        scroll.viewport().setStyleSheet("QWidget#setview { background: transparent; }")
        scroll.setStyleSheet("QScrollArea { background: transparent; border: none; }")
        row = QHBoxLayout(page)
        row.setContentsMargins(0, 0, 6, 0)
        row.setSpacing(16)

        left = QVBoxLayout()
        left.setSpacing(16)

        device, layout = self.card()
        layout.addWidget(self.h3("Гирлянда"))
        layout.addSpacing(14)
        top = QHBoxLayout()
        top.setSpacing(16)
        rainbow = [
            [QColor(*[int(v) for v in rainbow_rgb(c, r, 1.3)]) for c in range(MATRIX_COLUMNS)]
            for r in range(20)
        ]
        thumb = QLabel()
        thumb.setPixmap(led_pixmap(rainbow, 3, 1, DOT_OFF, pad=8, bg="#000000"))
        thumb.setStyleSheet(f"border: 1px solid {LINE}; border-radius: 14px;")
        top.addWidget(thumb)
        info = QVBoxLayout()
        info.setSpacing(3)
        info.addStretch()
        self.device_name = self.label("ESP32 Matrix", "name19")
        info.addWidget(self.device_name)
        info.addWidget(self.label(f"{MATRIX_COLUMNS} лент · {MATRIX_COLUMNS*MATRIX_ROWS} светодиодов", "mut13"))
        status_row = QHBoxLayout()
        status_row.setSpacing(8)
        self.device_dot = StatusDot()
        status_row.addWidget(self.device_dot)
        self.device_status = QLabel("")
        status_row.addWidget(self.device_status)
        status_row.addStretch()
        info.addSpacing(5)
        info.addLayout(status_row)
        info.addStretch()
        top.addLayout(info, 1)
        layout.addLayout(top)
        layout.addSpacing(8)
        self.net_value = self.label("—", "value")
        self.ip_value = self.label("—", "value")
        layout.addWidget(self.list_row("wifi", "Сеть", self.net_value))
        layout.addWidget(self.list_row("chip", "IP-адрес", self.ip_value))
        layout.addWidget(self.list_row("modes", "Точка доступа", self.label("Matrix", "value"), last=True))
        left.addWidget(device)

        wifi, layout = self.card()
        layout.addWidget(self.h3("Подключение к Wi-Fi"))
        layout.addSpacing(12)
        layout.addWidget(self.label("Имя сети (SSID)", "lbl", caps=True))
        layout.addSpacing(6)
        self.ssid_edit = QLineEdit()
        self.ssid_edit.setPlaceholderText("Например, Home_WiFi")
        self.ssid_edit.setText(str(self.settings.value("wifi_ssid", "")))
        layout.addWidget(self.ssid_edit)
        layout.addSpacing(12)
        layout.addWidget(self.label("Пароль", "lbl", caps=True))
        layout.addSpacing(6)
        self.password_edit = QLineEdit()
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.password_edit.setPlaceholderText("Пароль сети")
        self.password_visible = False
        self.eye_action = self.password_edit.addAction(
            svg_icon("eye", MUTED, size=18), QLineEdit.ActionPosition.TrailingPosition
        )
        self.eye_action.setToolTip("Показать пароль")
        self.eye_action.triggered.connect(self.toggle_password)
        layout.addWidget(self.password_edit)
        layout.addSpacing(6)
        self.wifi_result = self.label("", "hint")
        self.wifi_result.setWordWrap(True)
        layout.addWidget(self.wifi_result)
        layout.addSpacing(6)
        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        cancel = self.button("Отмена")
        cancel.clicked.connect(self.cancel_wifi)
        buttons.addWidget(cancel, 1)
        self.connect_button = self.button("Подключить", "btnr")
        self.connect_button.clicked.connect(self.send_wifi)
        buttons.addWidget(self.connect_button, 1)
        layout.addLayout(buttons)
        left.addWidget(wifi)
        left.addStretch()
        row.addLayout(left, 1)

        right = QVBoxLayout()
        params, layout = self.card()
        layout.addWidget(self.h3("Параметры"))
        layout.addSpacing(6)
        self.tz_combo = QComboBox()
        self.tz_combo.addItems(TIMEZONES)
        self.tz_combo.setCurrentText(str(self.settings.value("timezone", "UTC+3")))
        self.tz_combo.currentTextChanged.connect(self.on_timezone_changed)
        self.tz_combo.setCursor(Qt.CursorShape.PointingHandCursor)
        layout.addWidget(self.list_row("clock", "Часовой пояс", self.tz_combo))
        self.start_bright_value = self.label("75%", "value")
        layout.addWidget(self.list_row("sun", "Яркость при запуске", self.start_bright_value))
        self.night_toggle = ToggleSwitch()
        self.night_toggle.setChecked(self.settings.value("night_mode", "false") == "true")
        self.night_toggle.toggled.connect(self.set_night_mode)
        layout.addWidget(self.list_row("moon", "Ночной режим 23:00–07:00", self.night_toggle))
        self.last_toggle = ToggleSwitch()
        self.last_toggle.setChecked(self.settings.value("start_last_mode", "false") == "true")
        self.last_toggle.toggled.connect(
            lambda on: self.settings.setValue("start_last_mode", "true" if on else "false")
        )
        layout.addWidget(self.list_row("play", "Запускать последний режим", self.last_toggle, last=True))
        layout.addSpacing(8)
        note = self.label(
            "Яркость при запуске — текущая яркость, она отправляется гирлянде при подключении. "
            "Ночной режим работает на самой гирлянде, даже когда приложения закрыты: "
            "с 23:00 до 07:00 яркость 5%.",
            "hint",
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        right.addWidget(params)

        upd, layout = self.card()
        layout.addWidget(self.h3("Обновления"))
        self.peer_status = self.label("Локальная синхронизация: поиск приложений…", "hint")
        self.peer_status.setWordWrap(True)
        layout.addWidget(self.peer_status)
        layout.addSpacing(6)
        self.app_version_value = self.label("—", "value")
        self.fw_version_value = self.label("—", "value")
        layout.addWidget(self.list_row("draw", "Программа", self.app_version_value))
        layout.addWidget(self.list_row("chip", f"Прошивка · {MATRIX_COLUMNS}×{MATRIX_ROWS}", self.fw_version_value, last=True))
        layout.addSpacing(8)
        self.update_result = self.label("", "hint")
        self.update_result.setWordWrap(True)
        layout.addWidget(self.update_result)
        layout.addSpacing(10)
        self.update_app_button = self.button("Обновить программу", "btnr")
        self.update_app_button.clicked.connect(self.update_program)
        self.update_app_button.hide()
        self.update_fw_button = self.button("Обновить прошивку", "btnr")
        self.update_fw_button.clicked.connect(self.update_firmware)
        self.update_fw_button.hide()
        # кнопки обновлений — в одну строку, чтобы страница не листалась
        update_row = QHBoxLayout()
        update_row.setSpacing(10)
        update_row.addWidget(self.update_app_button, 1)
        update_row.addWidget(self.update_fw_button, 1)
        layout.addLayout(update_row)
        layout.addSpacing(8)
        self.check_updates_button = self.button("Проверить обновления", icon="upd")
        self.check_updates_button.clicked.connect(lambda: self.check_updates(silent=False))
        layout.addWidget(self.check_updates_button)
        right.addWidget(upd)
        right.addStretch()
        row.addLayout(right, 1)
        QTimer.singleShot(0, self.show_program_version)
        return scroll

    # ---------- обновления ----------
    def run_git(self, *args, timeout=60):
        flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            ["git", *args],
            cwd=APP_DIR,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=timeout,
            creationflags=flags,
        )
        if result.returncode != 0:
            raise RuntimeError((result.stderr or result.stdout or "git error").strip().splitlines()[-1])
        return result.stdout.strip()

    def show_program_version(self):
        if INSTALLED:
            self.app_version_value.setText(f"v{APP_VERSION}")
            return

        def work():
            return self.run_git("log", "-1", "--format=%cd · %h", "--date=format:%d.%m.%Y", timeout=10)

        def done(result):
            self.app_version_value.setText("—" if isinstance(result, Exception) else result)

        run_in_thread(work, done, self.ui_call)

    def device_fw(self):
        state = self.esp_link.state or {}
        if not self.esp_link.is_online:
            return 0
        return int(state.get("fw") or 1)

    def refresh_updates(self):
        if not hasattr(self, "fw_version_value"):
            return
        fw = self.device_fw()
        self.fw_version_value.setText(f"v{fw}" if fw else "—")
        info = self.update_info or {}
        firmware = profile_firmware(info)
        target = int(firmware.get("version") or 0)
        running = (self.esp_link.state or {}).get("ota") == "run" or self.fw_sent_at or getattr(self,'_fw_retry_pending',False)
        show = bool(fw and target > fw and not running)
        self.update_fw_button.setVisible(show)
        if show:
            self.update_fw_button.setText(f"{MATRIX_COLUMNS}×{MATRIX_ROWS} · ПРОШИВКА → V{target}")

    def check_updates(self, silent=False):
        self.check_updates_button.setEnabled(False)
        if not silent:
            self.update_result.setText("Проверяю…")

        def work():
            commits = None
            git_error = None
            if not INSTALLED:
                try:
                    self.run_git("fetch", "-q", timeout=40)
                    commits = int(self.run_git("rev-list", "--count", "HEAD..@{u}", timeout=10) or 0)
                except Exception as error:  # noqa: BLE001
                    git_error = str(error)
            info = None
            try:
                url = UPDATES_URL + "version.json?t=" + str(int(time.time()))
                req = urllib.request.Request(url, headers={"Cache-Control": "no-cache"})
                info = json.loads(fetch_update_bytes(url, timeout=3, max_bytes=262144, attempts=2, budget=8).decode("utf-8"))
            except Exception:  # noqa: BLE001
                info = None
            return commits, git_error, info

        def done(result):
            self.check_updates_button.setEnabled(True)
            if isinstance(result, Exception):
                commits, git_error, info = None, str(result), None
            else:
                commits, git_error, info = result
            if info:
                self.update_info = info
            if INSTALLED:
                pc = (info or {}).get("pc") or {}
                commits = 1 if int(pc.get("version") or 0) > APP_VERSION else 0
                if info is None:
                    git_error = "нет интернета"
            self.refresh_updates()
            self.update_app_button.setVisible(bool(commits))
            if commits and INSTALLED:
                self.update_app_button.setText(f"ПРОГРАММА → V{info['pc']['version']}")
            elif commits:
                self.update_app_button.setText(f"ПРОГРАММА ({commits})")
            if silent:
                return
            parts = []
            if commits:
                parts.append("Есть новая версия программы.")
            elif git_error:
                parts.append(
                    "Программу проверить не удалось — нет интернета?" if INSTALLED
                    else "Программу проверить не удалось (нужен git и интернет)."
                )
            if self.update_fw_button.isVisible():
                parts.append(f"Есть новая прошивка для {MATRIX_LABEL}.")
            elif info is None:
                parts.append("Файл обновлений прошивки недоступен.")
            if not parts:
                parts.append("Всё обновлено ✓")
            self.update_result.setText(" ".join(parts))

        run_in_thread(work, done, self.ui_call)

    def update_program(self):
        self.update_app_button.setEnabled(False)
        self.update_result.setText("Скачиваю обновление…")

        def work():
            if INSTALLED:
                return self.download_program()
            return self.run_git("pull", "-q", "--ff-only", timeout=120)

        def done(result):
            self.update_app_button.setEnabled(True)
            if isinstance(result, Exception):
                self.update_result.setText(f"Не получилось обновить: {result}")
                return
            self.update_result.setText("Готово — перезапускаю…")
            QTimer.singleShot(500, self.restart_program)

        run_in_thread(work, done, self.ui_call)

    def download_program(self):
        """Скачивает новую версию программы и подменяет файл (рядом остаётся копия старой)."""
        import importlib.util
        pc = (self.update_info or {}).get("pc") or {}
        if int(pc.get("runtime") or 1) > runtime_version():
            raise RuntimeError("нужна переустановка — запусти установщик ещё раз")
        def report(text): self.ui_call.call.emit(lambda t=text: self.update_result.setText(t))
        data = fetch_update_bytes(pc["url"],progress=report,expected_sha=pc.get('sha256'))
        target = os.path.abspath(__file__)
        if target.endswith(".pyc") and data[:4] != importlib.util.MAGIC_NUMBER:
            raise RuntimeError("файл обновления повреждён")
        tmp = target + ".new"
        with open(tmp, "wb") as file:
            file.write(data)
        import shutil
        if os.path.exists(target): shutil.copy2(target, target + '.old')
        os.replace(tmp, target)
        return "ok"

    def restart_program(self):
        self.closeEvent_save()
        self.esp_link.udp.close()
        if hasattr(self,'peer_transport'): self.peer_transport.close()
        script = os.path.abspath(__file__)
        flags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
        subprocess.Popen([sys.executable, script], cwd=os.path.dirname(script), creationflags=flags)
        QApplication.quit()

    def update_firmware(self):
        if getattr(self,'_fw_retry_pending',False) or self.fw_sent_at: return
        self._fw_retry = 0
        self.start_ota_attempt()

    def start_ota_attempt(self):
        self._fw_retry_pending = False
        firmware = profile_firmware(self.update_info)
        url = firmware.get("url")
        if url and ((MATRIX_PROFILE=='esp32c3-9x20' and not url.endswith('/firmware/esp32c3-9x20/LEDMatrix.bin')) or (MATRIX_PROFILE=='esp32-19x20' and '/esp32c3-9x20/' in url)):
            self.update_result.setText('Отказ: файл прошивки не соответствует выбранной гирлянде');return
        if not url or not self.esp_link.is_online:
            self.update_result.setText('Для обновления дождись подключения гирлянды')
            return
        if self.device_fw() >= int(firmware.get('version') or 0): return
        self.update_fw_button.setEnabled(False)

        def done(reply):
            self.update_fw_button.setEnabled(True)
            if reply and reply.startswith("OK"):
                self.fw_target = int(firmware.get("version") or 0)
                self.fw_sent_at = time.time()
                self.update_result.setText(
                    "Гирлянда скачивает прошивку — нижний ряд покажет прогресс. Не выключай её."
                )
            elif reply:
                self.update_result.setText(
                    "Гирлянда отказалась: старая прошивка не умеет обновляться по воздуху — "
                    "прошей её один раз кабелем."
                )
            else:
                self.update_result.setText("Нет ответа от гирлянды")
            self.refresh_updates()

        self.esp_link.request({"type": "ota", "url": url, "sha256": firmware.get('sha256','')}, done, 6000)

    def on_device_state(self, state):
        if state.get("name"):
            self.esp_link.device_name = state["name"]
        self.sync_from_device(state)
        rev = state.get("picsRev")
        if isinstance(rev, int) and rev >= 0 and rev != getattr(self, "_pics_seen_rev", None):
            self.sync_pictures()
        if "sched" in state and hasattr(self, "scen_list"):
            self.sync_scenarios_from_device(state.get("sched"))
        if self.fw_sent_at:
            ota = str(state.get("ota") or "")
            if ota.startswith("fail"):
                self.fw_sent_at = 0.0
                reason = ota[5:].strip()
                if "partition" in reason.lower() or "раздел" in reason.lower():
                    self.update_result.setText(
                        "В гирлянде нет места для обновления по воздуху. Прошей её один раз кабелем "
                        "со схемой Partition Scheme: «Default 4MB with spiffs» — дальше обновления пойдут по воздуху."
                    )
                elif self.device_fw() < 16 and getattr(self,'_fw_retry',0) < 2 and any(x in reason.lower() for x in ['timeout','time out','refused','connection','connect','stream','aborted']):
                    self._fw_retry = getattr(self,'_fw_retry',0) + 1
                    self._fw_retry_pending = True
                    self.update_result.setText(f'Обрыв загрузки — повтор {self._fw_retry + 1}/3 через 3 секунды…')
                    QTimer.singleShot(3000, self.start_ota_attempt)
                else:
                    attempts = getattr(self, '_fw_retry', 0) + 1
                    message = f"Не удалось обновить (попыток: {attempts}): " + reason
                    if self.device_fw() < 16 and 'aborted' in reason.lower():
                        message += ". Прошивка v15 скрыла исходную ошибку. Нужен лог монитора порта во время OTA; если OTA не проходит, v16 можно установить кабелем."
                    self.update_result.setText(message)
            elif self.fw_target and int(state.get("fw") or 0) >= self.fw_target:
                self.fw_sent_at = 0.0
                self.update_result.setText(f"Прошивка обновлена до v{state.get('fw')} ✓")
            elif time.time() - self.fw_sent_at > 330:
                self.fw_sent_at = 0.0
                self.update_result.setText("Не дождался гирлянды — проверь её позже")
        self.refresh_updates()

    def toggle_password(self):
        self.password_visible = not self.password_visible
        self.password_edit.setEchoMode(
            QLineEdit.EchoMode.Normal if self.password_visible else QLineEdit.EchoMode.Password
        )
        self.eye_action.setIcon(svg_icon("eye_off" if self.password_visible else "eye", MUTED, size=18))
        self.eye_action.setToolTip("Скрыть пароль" if self.password_visible else "Показать пароль")

    def cancel_wifi(self):
        self.ssid_edit.setText(str(self.settings.value("wifi_ssid", "")))
        self.password_edit.clear()
        self.wifi_result.setText("")

    def send_wifi(self):
        ssid = self.ssid_edit.text().strip()
        if not ssid:
            self.wifi_result.setText("Введи имя сети")
            return
        if not self.esp_link.is_online:
            self.wifi_result.setText("Гирлянда не в сети")
            return
        self.connect_button.setEnabled(False)
        self.wifi_result.setText("Отправка настроек…")
        self._pending_ssid = ssid
        # асинхронно — UI не замерзает, результат придёт сигналом wifi_result
        self.esp_link.send_wifi_credentials_async(ssid, self.password_edit.text())

    def on_wifi_result(self, success, message):
        self.connect_button.setEnabled(True)
        self.wifi_result.setText(message)
        if success:
            self.settings.setValue("wifi_ssid", getattr(self, "_pending_ssid", ""))
            self.password_edit.clear()
            self.refresh_status()

    # ---------- статус ----------
    def link_state(self):
        link = self.esp_link
        if getattr(link, "bind_error", None):
            return "error"
        if link.is_online:
            return "online"
        if link.device_ip is None:
            return "search"
        return "offline"

    def refresh_status(self):
        link = self.esp_link
        state = self.link_state()
        color = {"error": "#FFFFFF", "search": "#8E8E93", "online": ACCENT, "offline": "#555555"}[state]
        self.pill_text.setText({
            "error": "ОШИБКА СЕТИ",
            "search": "ПОИСК…",
            "online": f"ONLINE · {link.device_ip}",
            "offline": "OFFLINE",
        }[state])
        tooltip = getattr(link, "bind_error", None) or ""
        if state == "online" and link.last_rtt_ms is not None:
            tooltip = f"Ответ на ping: {link.last_rtt_ms} мс"
        self.pill_text.setToolTip(tooltip)
        self.pill_dot.set_state(state, color)
        self.device_dot.set_state(state, color)
        self.device_status.setText(
            {"online": "Подключена",
             "search": "Поиск…", "offline": "Не в сети", "error": "Ошибка сети"}[state]
        )
        self.device_name.setText(link.device_name or MATRIX_LABEL)
        self.ip_value.setText(link.device_ip or "—")
        self.refresh_updates()
        if state == "online" and link.device_ip and link.device_ip.startswith("192.168.4."):
            self.net_value.setText("Точка доступа")
        else:
            self.net_value.setText(str(self.settings.value("wifi_ssid", "") or "—"))

    def closeEvent_save(self):
        self.settings.setValue('local_canvas',json.dumps([''.join(self.led_hex(c) for c in row) for row in self.matrix.pixels]))
        if hasattr(self,'peer_ledger'): self.peer_capture(); self.peer_persist()
        self.settings.setValue("my_colors", ",".join(self.custom_colors))
        self.settings.setValue("brightness", self.bright_slider.value())
        self.settings.sync()

    def closeEvent(self, event):
        if hasattr(self,'peer_transport'): self.peer_transport.close()
        self.closeEvent_save()
        event.accept()


def main():
    if sys.platform == "win32":
        # своя иконка на панели задач, а не значок Python
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("nf97700.LEDMatrixStudio")
        except (AttributeError, OSError):
            pass
    app = QApplication(sys.argv)
    if "--selftest" in sys.argv:
        QTimer.singleShot(3000, app.quit)
    window = Window()
    # окно плавно появляется при запуске
    window.setWindowOpacity(0.0)
    window.show()
    fade = QPropertyAnimation(window, b"windowOpacity", window)
    fade.setDuration(380)
    fade.setStartValue(0.0)
    fade.setEndValue(1.0)
    fade.setEasingCurve(QEasingCurve.Type.OutCubic)
    fade.start()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
