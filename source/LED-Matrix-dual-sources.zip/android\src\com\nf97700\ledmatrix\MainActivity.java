package com.nf97700.ledmatrix;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Vibrator;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final int UDP_PORT = 45454, TCP_PORT = 3333;
    /** версия интерфейса, вшитая в APK (WEB_VERSION в assets/index.html) */
    static final int ASSET_WEB_VER = 22;
    boolean pendingInstall = false;
    WebView web;
    Handler ui = new Handler(Looper.getMainLooper());
    ExecutorService tcpPool = Executors.newSingleThreadExecutor();
    ExecutorService udpPool = Executors.newSingleThreadExecutor();
    ExecutorService httpPool = Executors.newCachedThreadPool();
    SharedPreferences prefs;
    PeerTransportLan peerLan;
    DatagramSocket sock;
    volatile boolean running;
    WifiManager.MulticastLock mlock;
    WifiManager.WifiLock wlock;   // без энергосбережения Wi-Fi: пакеты уходят сразу, а не пачками

    // локальная сеть
    volatile String selectedProfile = "esp32-19x20";
    volatile int deviceGeneration = 0;
    final java.util.concurrent.ConcurrentHashMap<String,JSONObject> devices = new java.util.concurrent.ConcurrentHashMap<>();
    volatile String devIp = null;
    volatile long lastSeen = 0;
    volatile String devName = "";
    volatile boolean localOnline = false;
    // что последний раз сообщили странице
    String lastLink = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("led", MODE_PRIVATE);
        selectedProfile=prefs.getString("matrixProfile","esp32-19x20");
        if (!prefs.getBoolean("dualEnabled",true) || !selectedProfile.equals("esp32c3-9x20")) selectedProfile="esp32-19x20";
        String peerId = prefs.getString("peerNode2", "");
        if (peerId.isEmpty()) { peerId = java.util.UUID.randomUUID().toString().replace("-", ""); prefs.edit().putString("peerNode2", peerId).apply(); }
        peerLan = new PeerTransportLan(peerId, text -> js("window.onPeerRecords&&window.onPeerRecords("+q(text)+")"));
        // облако и привязка к одной гирлянде убраны — чистим старые записи
        prefs.edit().remove("devId").remove("devKey").remove("devName").remove("autoPair").apply();
        Window w = getWindow();
        w.setStatusBarColor(Color.BLACK);
        w.setNavigationBarColor(Color.BLACK);
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setLongClickable(false);
        web.setOnLongClickListener(v -> true);
        web.setHapticFeedbackEnabled(false);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Bridge(), "Native");
        // быстродействие: рендер WebView в приоритете, страницы готовы заранее
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        try { s.setOffscreenPreRaster(true); } catch (Throwable t) { }
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            try { web.setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true); } catch (Throwable t) { }
        }
        setContentView(web);
        loadWeb();
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            mlock = wm.createMulticastLock("ledmatrix");
            mlock.setReferenceCounted(false);
            int wm_mode = android.os.Build.VERSION.SDK_INT >= 29 ? WifiManager.WIFI_MODE_FULL_LOW_LATENCY : WifiManager.WIFI_MODE_FULL_HIGH_PERF;
            wlock = wm.createWifiLock(wm_mode, "ledmatrix-draw");
            wlock.setReferenceCounted(false);
        } catch (Exception e) { }
    }

    File webFile() { return new File(getFilesDir(), "web/index.html"); }

    boolean bundledAssetFallback = false;

    int webVer() {
        if (bundledAssetFallback) return ASSET_WEB_VER;
        int v = prefs.getInt("webVer", 0);
        if(prefs.getBoolean("legacySingle",false)&&webFile().exists())return v;
        return v >= ASSET_WEB_VER && webFile().exists() ? v : ASSET_WEB_VER;
    }

    // Обновление вшитого интерфейса без смены пути, очистки localStorage и настроек.
    void applyBundledInterface() {
        if(prefs.getBoolean("legacySingle",false)&&webFile().exists())return;
        if (prefs.getInt("webVer", 0) >= ASSET_WEB_VER && webFile().exists()) return;
        File target = webFile();
        File temp = new File(target.getParentFile(), "index.bundled.tmp");
        try {
            if (!target.getParentFile().isDirectory() && !target.getParentFile().mkdirs())
                throw new java.io.IOException("Cannot create web directory");
            try (InputStream in = getAssets().open("index.html");
                 FileOutputStream out = new FileOutputStream(temp)) {
                byte[] buffer = new byte[8192];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                out.getFD().sync();
            }
            if (!temp.renameTo(target)) throw new java.io.IOException("Cannot replace cached interface");
            prefs.edit().putInt("webVer", ASSET_WEB_VER).commit();
        } catch (Exception e) {
            bundledAssetFallback = true;
            temp.delete();
            android.util.Log.e("LEDMatrix", "Interface update: using bundled version", e);
        }
    }

    void loadWeb() {
        applyBundledInterface();
        if (bundledAssetFallback) { web.loadUrl("file:///android_asset/index.html"); return; }
        if (webFile().exists() && (prefs.getInt("webVer", 0) >= ASSET_WEB_VER || prefs.getBoolean("legacySingle",false))) web.loadUrl("file://" + webFile().getAbsolutePath());
        else web.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onResume() { super.onResume(); resumeInstall(); startNet(); js("window.onResume&&window.onResume()"); }
    @Override protected void onPause() { super.onPause(); stopNet(); }

    @Override public void onBackPressed() {
        web.evaluateJavascript("window.onBack?window.onBack():false", v -> {
            if (!"true".equals(v)) MainActivity.super.onBackPressed();
        });
    }

    void js(final String code) {
        ui.post(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    static String q(String s) { return s == null ? "null" : JSONObject.quote(s); }

    void updateLink() {
        boolean on = localOnline;
        String ip = on ? devIp : null;
        String key = on + "|" + ip + "|" + devName;
        synchronized (this) { if (key.equals(lastLink)) return; lastLink = key; }
        js("window.onLink&&window.onLink(" + on + "," + q(ip) + "," + q(devName) + ")");
    }

    void forceLink() { synchronized (this) { lastLink = ""; } updateLink(); }

    // ===================== ЛОКАЛЬНАЯ СЕТЬ =====================
    synchronized void startNet() {
        if (running) return;
        running = true;
        if (peerLan != null) peerLan.start();
        try { if (mlock != null) mlock.acquire(); } catch (Exception e) { }
        try { if (wlock != null) wlock.acquire(); } catch (Exception e) { }
        try {
            sock = new DatagramSocket(null);
            sock.setReuseAddress(true);
            sock.setBroadcast(true);
            sock.bind(new InetSocketAddress(UDP_PORT));
        } catch (Exception e) {
            try { sock = new DatagramSocket(); sock.setBroadcast(true); } catch (Exception e2) { sock = null; }
        }
        new Thread(this::recvLoop).start();
        new Thread(this::pingLoop).start();
    }

    synchronized void stopNet() {
        running = false;localOnline=false;lastSeen=0;devIp=null;devices.clear();deviceGeneration++;
        if (peerLan != null) peerLan.stop();
        try { if (sock != null) sock.close(); } catch (Exception e) { }
        sock = null;
        try { if (mlock != null && mlock.isHeld()) mlock.release(); } catch (Exception e) { }
        try { if (wlock != null && wlock.isHeld()) wlock.release(); } catch (Exception e) { }
    }

    /** "LEDGARLAND|имя" (анонс) или "PONG" (ответ на PING) */
    static String profileOf(String msg) {
        String[] p=msg.split("\\|",-1);
        if(p.length==6 && p[0].equals("MATRIX2") && p[2].equals("esp32c3-9x20") && p[4].equals("9") && p[5].equals("20"))return p[2];
        if(p.length>=2 && p[0].equals("LEDGARLAND"))return "esp32-19x20";
        return null;
    }
    synchronized void onFound(String msg, String ip) {
        try {
            String profile=profileOf(msg);String[] p=msg.split("\\|",-1);
            if(profile!=null) devices.put(profile,new JSONObject().put("profile",profile).put("name",p[1]).put("ip",ip).put("seen",System.currentTimeMillis()));
            else if(msg.equals("PONG")) {
                JSONObject legacy=devices.get("esp32-19x20");
                if(legacy!=null && ip.equals(legacy.optString("ip"))){profile="esp32-19x20";legacy.put("seen",System.currentTimeMillis());}
            }
            if(!selectedProfile.equals(profile))return;
            JSONObject d=devices.get(profile);if(d==null)return;
            devIp=ip;devName=d.optString("name");lastSeen=System.currentTimeMillis();localOnline=true;updateLink();
        }catch(Exception e){}
    }
    synchronized boolean selectMatrixProfile(String profile, boolean dual) {
        if(!profile.equals("esp32-19x20")&&!profile.equals("esp32c3-9x20"))return false;
        if(!dual)profile="esp32-19x20";
        deviceGeneration++;selectedProfile=profile;
        prefs.edit().putString("matrixProfile",profile).putBoolean("dualEnabled",dual).commit();
        devIp=null;devName="";lastSeen=0;localOnline=false;lastLink="";
        if(peerLan!=null)peerLan.state("{}");
        // A cached IP is not proof: both provisioning APs can use 192.168.4.1.
        // Only a fresh announcement matching the selected model can enable commands.
        return true;
    }

    void recvLoop() {
        byte[] buf = new byte[2048];
        while (running) {
            DatagramSocket s = sock;
            if (s == null) break;
            try {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                s.receive(p);
                String msg = new String(p.getData(), 0, p.getLength(), "UTF-8").trim();
                String ip = p.getAddress().getHostAddress();
                if (msg.startsWith("LEDGARLAND|") || msg.equals("PONG") || msg.startsWith("MATRIX2|")) onFound(msg, ip);
            } catch (Exception e) {
                if (!running) break;
            }
        }
    }

    void sendUdp(String msg, InetAddress to) {
        DatagramSocket s = sock;
        if (s == null || to == null) return;
        try {
            byte[] d = msg.getBytes("UTF-8");
            s.send(new DatagramPacket(d, d.length, to, UDP_PORT));
        } catch (Exception e) { }
    }

    InetAddress bcast() {
        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            android.net.DhcpInfo di = wm.getDhcpInfo();
            if (di != null && di.ipAddress != 0) {
                int b = (di.ipAddress & di.netmask) | ~di.netmask;
                byte[] q = new byte[4];
                for (int i = 0; i < 4; i++) q[i] = (byte) ((b >> (i * 8)) & 0xFF);
                return InetAddress.getByAddress(q);
            }
        } catch (Exception e) { }
        try { return InetAddress.getByName("255.255.255.255"); } catch (Exception e) { return null; }
    }

    String addrFor = null; InetAddress addrCache = null;
    InetAddress devAddr() throws Exception {
        String ip = devIp;
        if (ip == null) return null;
        if (!ip.equals(addrFor)) { addrCache = InetAddress.getByName(ip); addrFor = ip; }
        return addrCache;
    }

    void pingLoop() {
        while (running) {
            try {
                sendUdp("PING", bcast());
                try { sendUdp("PING", InetAddress.getByName("255.255.255.255")); } catch (Exception e) { }
                if (devIp != null) sendUdp("PING", InetAddress.getByName(devIp));
                try { sendUdp("PING", InetAddress.getByName("192.168.4.1")); } catch (Exception e) { }
                if (localOnline && System.currentTimeMillis() - lastSeen > 10000) localOnline = false;
                updateLink();
                Thread.sleep(1500);
            } catch (Exception e) { }
        }
    }

    String tcpExchange(String ip, String json, int timeout) {
        if (ip == null) return null;
        Socket s = new Socket();
        try {
            s.connect(new InetSocketAddress(ip, TCP_PORT), Math.min(timeout, 4000));
            s.setSoTimeout(timeout);
            OutputStream o = s.getOutputStream();
            o.write((json + "\n").getBytes("UTF-8"));
            o.flush();
            BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            String line = r.readLine();
            if(ip.equals(devIp)) lastSeen = System.currentTimeMillis();
            return line == null ? "" : line.trim();
        } catch (Exception e) {
            return null;
        } finally {
            try { s.close(); } catch (Exception e) { }
        }
    }

    // ===================== HTTP / ОБНОВЛЕНИЯ =====================
    static byte[] download(String url) throws Exception { return UpdateDownloader.bytes(url); }

    boolean canInstall() {
        return android.os.Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls();
    }

    void launchInstall() {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(ApkProvider.uri(), "application/vnd.android.package-archive");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) { js("window.onApk&&window.onApk('fail',0)"); }
    }

    // Android перезапускает приложение, когда даёшь разрешение «Установка из этого источника» —
    // поэтому запоминаем ожидающую установку в настройках и продолжаем её сами
    void resumeInstall() {
        if (!prefs.getBoolean("pendingApk", false) || !canInstall()) return;
        prefs.edit().putBoolean("pendingApk", false).apply();
        File f = ApkProvider.apkFile(this);
        try {
            android.content.pm.PackageInfo pi = getPackageManager().getPackageArchiveInfo(f.getAbsolutePath(), 0);
            int cur = getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
            if (f.exists() && pi != null && pi.versionCode > cur) ui.postDelayed(this::launchInstall, 300);
        } catch (Exception e) { }
    }

    void startInstall() {
        if (canInstall()) { launchInstall(); return; }
        pendingInstall = true;
        prefs.edit().putBoolean("pendingApk", true).apply();
        js("window.onApk&&window.onApk('perm',0)");
        try {
            startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
        } catch (Exception e) { pendingInstall = false; launchInstall(); }
    }

    final java.util.concurrent.atomic.AtomicBoolean apkDownloading = new java.util.concurrent.atomic.AtomicBoolean(false);

    void downloadApk(String url) {
        if (!apkDownloading.compareAndSet(false, true)) return;
        File f = ApkProvider.apkFile(this);
        File tmp = new File(f.getParentFile(), "update.tmp");
        File meta = new File(tmp.getPath() + ".meta");
        try {
            if (!f.getParentFile().isDirectory() && !f.getParentFile().mkdirs())
                throw new java.io.IOException("cannot create update directory");
            final int[] last = {-2};
            UpdateDownloader.file(url, tmp, (got, total) -> {
                int percent = total > 0 ? (int)Math.min(99, got * 100 / total) : -1;
                if (percent != last[0]) {
                    last[0] = percent;
                    js("window.onApk&&window.onApk('progress'," + percent + ")");
                }
            });
            android.content.pm.PackageInfo pi = getPackageManager().getPackageArchiveInfo(
                    tmp.getAbsolutePath(), android.content.pm.PackageManager.GET_SIGNATURES);
            android.content.pm.PackageInfo current = getPackageManager().getPackageInfo(
                    getPackageName(), android.content.pm.PackageManager.GET_SIGNATURES);
            boolean valid = pi != null && getPackageName().equals(pi.packageName)
                    && pi.versionCode > current.versionCode && pi.signatures != null && pi.signatures.length > 0 && current.signatures != null
                    && new java.util.HashSet<>(java.util.Arrays.asList(pi.signatures)).equals(
                       new java.util.HashSet<>(java.util.Arrays.asList(current.signatures)));
            if (!valid) {
                tmp.delete(); meta.delete();
                throw new java.io.IOException("invalid APK, signing certificate, or version");
            }
            // POSIX rename replaces the old cached APK atomically; don't delete it first.
            android.system.Os.rename(tmp.getAbsolutePath(), f.getAbsolutePath());
            meta.delete();
            js("window.onApk&&window.onApk('ready'," + pi.versionCode + ")");
            ui.post(this::startInstall);
        } catch (Exception e) {
            // Keep a validated partial download for the next attempt, never start its installation.
            android.util.Log.e("LEDMatrix", "APK update failed", e);
            js("window.onApk&&window.onApk('fail',0)");
        } finally { apkDownloading.set(false); }
    }

    class Bridge {
        @JavascriptInterface public void rollbackSingle() {
            httpPool.execute(()->{try {
                byte[] data=UpdateDownloader.bytes("https://raw.githubusercontent.com/nf97700-glitch/LED-Matrix-Updates/968a87bc1722175cd387584cc316fcc06a1cb274/app/index.html");
                StringBuilder h=new StringBuilder();for(byte b:java.security.MessageDigest.getInstance("SHA-256").digest(data))h.append(String.format("%02x",b&255));
                if(!h.toString().equals("07b8d2171374368977391afebce4899b17e057b759aebd242736b85d58e0dbd5"))throw new java.io.IOException("Legacy interface hash mismatch");
                File f=webFile(),tmp=new File(f.getParentFile(),"rollback.tmp");f.getParentFile().mkdirs();
                try(FileOutputStream out=new FileOutputStream(tmp)){out.write(data);out.getFD().sync();}
                android.system.Os.rename(tmp.getAbsolutePath(),f.getAbsolutePath());
                selectMatrixProfile("esp32-19x20",false);
                prefs.edit().putInt("webVer",21).putBoolean("legacySingle",true).commit();
                ui.post(MainActivity.this::loadWeb);
            }catch(Exception e){android.util.Log.e("LEDMatrix","Interface rollback failed",e);js("window.onRollback&&window.onRollback(false)");}});
        }

        @JavascriptInterface public String matrixInfo() {
            synchronized(MainActivity.this){try { org.json.JSONArray a=new org.json.JSONArray();for(JSONObject d:devices.values())a.put(d);
                return new JSONObject().put("profile",selectedProfile).put("dual",prefs.getBoolean("dualEnabled",true)).put("devices",a).toString();
            }catch(Exception e){return "{}";}}
        }
        @JavascriptInterface public boolean selectMatrix(String profile,boolean dual){return selectMatrixProfile(profile,dual);}
        @JavascriptInterface public String peerInfo() {
            try { int count=0; long now=System.currentTimeMillis(); for(long t:peerLan.peers.values()) if(now-t<5000)count++;
                return new JSONObject().put("id",peerLan.node).put("peers",count).put("error",peerLan.error).toString();
            } catch(Exception e) { return "{}"; }
        }
        @JavascriptInterface public void peerState(String records) { peerLan.state(records); if (running) peerLan.start(); }

        @JavascriptInterface public void udp(final String json) {
            if (!localOnline) return;
            final String target=devIp;final int generation=deviceGeneration;
            udpPool.execute(() -> {
                try { if (target != null && generation==deviceGeneration) sendUdp(json, InetAddress.getByName(target)); } catch (Exception e) { }
            });
        }
        @JavascriptInterface public void tcp(final String id, final String json, final int timeoutMs) {
            final String target=devIp;final int generation=deviceGeneration;
            tcpPool.execute(() -> {
                if(generation!=deviceGeneration)return;
                String r = target != null && localOnline ? tcpExchange(target, json, timeoutMs > 0 ? timeoutMs : 3000) : null;
                if(generation==deviceGeneration)js("window.onTcp&&window.onTcp(" + q(id) + "," + q(r) + ")");
            });
        }
        @JavascriptInterface public void vibrate(int ms) {
            try {
                Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.vibrate(Math.max(5, Math.min(ms, 200)));
            } catch (Exception e) { }
        }
        @JavascriptInterface public void ready() { forceLink(); }
        @JavascriptInterface public String appInfo() {
            try {
                JSONObject o = new JSONObject();
                android.content.pm.PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
                o.put("apk", pi.versionCode);
                o.put("apkName", pi.versionName);
                o.put("web", webVer());
                o.put("peerProtocol", 2);
                return o.toString();
            } catch (Exception e) { return "{}"; }
        }
        @JavascriptInterface public void httpGet(final String id, final String url) {
            httpPool.execute(() -> {
                String r;
                try { r = new String(download(url), StandardCharsets.UTF_8); } catch (Exception e) { r = null; }
                js("window.onHttp&&window.onHttp(" + q(id) + "," + q(r) + ")");
            });
        }
        @JavascriptInterface public void updateWeb(final String id, final String url, final int ver, final String expectedSha) {
            httpPool.execute(() -> {
                String r = null;
                try {
                    byte[] d = download(url);
                    if (expectedSha != null && !expectedSha.isEmpty()) {
                        StringBuilder h = new StringBuilder(); for(byte b:java.security.MessageDigest.getInstance("SHA-256").digest(d)) h.append(String.format("%02x", b & 255));
                        if (!h.toString().equalsIgnoreCase(expectedSha)) throw new java.io.IOException("interface SHA256 mismatch");
                    }
                    String html = new String(d, StandardCharsets.UTF_8);
                    if (!html.contains("WEB_VERSION") || !html.contains("</html>")) throw new Exception("bad");
                    File f = webFile();
                    f.getParentFile().mkdirs();
                    File tmp = new File(f.getParentFile(), "index.tmp");
                    try (FileOutputStream o = new FileOutputStream(tmp)) { o.write(d); }
                    if (!tmp.renameTo(f)) throw new Exception("rename");
                    prefs.edit().putInt("webVer", ver).putBoolean("legacySingle",ver<ASSET_WEB_VER).apply();
                    r = "OK";
                } catch (Exception e) { }
                js("window.onHttp&&window.onHttp(" + q(id) + "," + q(r) + ")");
                if (r != null) ui.postDelayed(MainActivity.this::loadWeb, 600);
            });
        }
        @JavascriptInterface public void installApk(final String url) {
            httpPool.execute(() -> downloadApk(url));
        }
        @JavascriptInterface public void openUrl(String url) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception e) { }
        }
    }
}
