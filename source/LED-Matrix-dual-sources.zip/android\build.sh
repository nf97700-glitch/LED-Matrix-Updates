set -e
cd /data/mobile/app
SDK=/data/android/sdk; BT=$SDK/build-tools/34.0.0; AJ=$SDK/platforms/android-34/android.jar
rm -rf build; mkdir -p build/res build/classes build/dex
cp ../index.html assets/index.html
$BT/aapt2 compile --dir res -o build/res/res.zip
$BT/aapt2 link -o build/base.apk -I $AJ --manifest AndroidManifest.xml -A assets build/res/res.zip --java build/gen --min-sdk-version 24 --target-sdk-version 34
javac -encoding UTF-8 --release 11 -classpath $AJ -d build/classes $(find src build/gen -name '*.java') 2>&1
$BT/d8 --release --lib $AJ --min-api 24 --output build/dex $(find build/classes -name '*.class')
cp build/base.apk build/unsigned.apk
(cd build/dex && zip -q -j ../unsigned.apk classes.dex)
$BT/zipalign -f -p 4 build/unsigned.apk build/aligned.apk
[ -f /data/mobile/debug.keystore ] || keytool -genkeypair -keystore /data/mobile/debug.keystore -storepass android -keypass android -alias led -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=LED Matrix" >/dev/null 2>&1
$BT/apksigner sign --ks /data/mobile/debug.keystore --ks-pass pass:android --key-pass pass:android --out /data/mobile/LED-Matrix.apk build/aligned.apk
$BT/apksigner verify /data/mobile/LED-Matrix.apk && ls -la /data/mobile/LED-Matrix.apk
