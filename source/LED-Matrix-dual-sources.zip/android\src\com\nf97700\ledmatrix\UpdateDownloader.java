package com.nf97700.ledmatrix;

import java.io.*;
import java.net.*;
import java.util.Properties;
import java.util.regex.*;

/** Только интернет-загрузки обновлений. Локальную сеть ESP не обслуживает. */
final class UpdateDownloader {
    interface Progress { void update(long received, long total); }
    static final long MAX_APK = 32L * 1024 * 1024;
    static int connectTimeout = 7000, readTimeout = 10000, retryDelay = 600;

    static HttpURLConnection open(String url) throws IOException {
        String u = url + (url.contains("?") ? "&" : "?") + "t=" + System.currentTimeMillis();
        HttpURLConnection c = (HttpURLConnection)new URL(u).openConnection();
        c.setConnectTimeout(connectTimeout);
        c.setReadTimeout(readTimeout);
        c.setUseCaches(false);
        c.setRequestProperty("Cache-Control", "no-cache");
        c.setRequestProperty("Accept-Encoding", "identity");
        return c;
    }
    static void pause(int attempt) throws IOException {
        try { Thread.sleep((long)retryDelay * attempt); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException("interrupted", e); }
    }
    static boolean retryable(IOException e) {
        if (e instanceof javax.net.ssl.SSLPeerUnverifiedException) return false;
        for (Throwable t=e; t!=null; t=t.getCause())
            if (t instanceof java.security.cert.CertificateException) return false;
        return !(e instanceof PermanentFailure);
    }
    static final class PermanentFailure extends IOException {
        PermanentFailure(String s) { super(s); }
    }
    static void checkStatus(int status) throws IOException {
        if (status >= 400 && status != 408 && status != 429 && status < 500)
            throw new PermanentFailure("HTTP " + status);
        throw new IOException("HTTP " + status);
    }
    static byte[] bytes(String url) throws IOException {
        IOException last = null;
        long deadline=System.nanoTime()+15000000000L;
        for (int attempt=1; attempt<=2; attempt++) {
            HttpURLConnection c=null;
            try {
                if(System.nanoTime()>deadline)throw new PermanentFailure("update request time limit");
                c=open(url);c.setConnectTimeout(Math.min(connectTimeout,3000));c.setReadTimeout(Math.min(readTimeout,4000));
                int status=c.getResponseCode(); if(status!=200) checkStatus(status);
                long expected=c.getContentLengthLong();
                if(expected>2*1024*1024) throw new PermanentFailure("file too large");
                try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()) {
                    byte[] b=new byte[16384]; int n;
                    while((n=in.read(b))!=-1) {
                        if(System.nanoTime()>deadline)throw new PermanentFailure("update request time limit");
                        if(out.size()+n>2*1024*1024) throw new PermanentFailure("file too large");
                        out.write(b,0,n);
                    }
                    if(expected>=0 && out.size()!=expected) throw new IOException("incomplete response");
                    return out.toByteArray();
                }
            } catch(IOException e) { last=e; if(!retryable(e)) throw e; }
            finally { if(c!=null)c.disconnect(); }
            if(attempt<2) pause(attempt);
        }
        throw last;
    }
    static Properties readMeta(File f) {
        Properties p=new Properties();
        try(InputStream in=new FileInputStream(f)){p.load(in);}catch(IOException e){}
        return p;
    }
    static void clear(File file, File meta) throws IOException {
        if(file.exists()&&!file.delete()) throw new PermanentFailure("cannot discard partial update");
        if(meta.exists()&&!meta.delete()) throw new PermanentFailure("cannot discard update metadata");
    }
    static void file(String url, File target, Progress progress) throws IOException {
        File meta=new File(target.getPath()+".meta");
        IOException last=null;
        long deadline=System.nanoTime()+120000000000L;
        for(int attempt=1;attempt<=5;attempt++) {
            HttpURLConnection c=null;
            try {
                if(System.nanoTime()>deadline)throw new PermanentFailure("APK download time limit; partial file kept");
                Properties p=readMeta(meta);
                String validator=p.getProperty("validator", "");
                long offset=target.exists()?target.length():0;
                if(!url.equals(p.getProperty("url")) || validator.isEmpty() || offset>MAX_APK) {
                    clear(target,meta);offset=0;validator="";
                }
                c=open(url);
                if(offset>0){c.setRequestProperty("Range","bytes="+offset+"-");c.setRequestProperty("If-Range",validator);}
                int status=c.getResponseCode();
                if(status==416){clear(target,meta);throw new IOException("range changed; restart");}
                if(status!=200&&status!=206)checkStatus(status);
                long total;
                if(status==206){
                    String header=c.getHeaderField("Content-Range");
                    Matcher m=Pattern.compile("bytes (\\d+)-(\\d+)/(\\d+)").matcher(header==null?"":header);
                    if(!m.matches()||Long.parseLong(m.group(1))!=offset) {
                        clear(target,meta);throw new IOException("invalid response range");
                    }
                    long end=Long.parseLong(m.group(2));total=Long.parseLong(m.group(3));
                    if(end<offset||end>=total){clear(target,meta);throw new IOException("invalid response length");}
                    String oldETag=p.getProperty("etag","");String newETag=c.getHeaderField("ETag");
                    if(offset>0&&!oldETag.isEmpty()&&newETag!=null&&!oldETag.equals(newETag)){
                        clear(target,meta);throw new IOException("update changed; restart");
                    }
                } else {offset=0;total=c.getContentLengthLong();}
                if(total>MAX_APK)throw new PermanentFailure("APK too large");
                String etag=c.getHeaderField("ETag"), modified=c.getHeaderField("Last-Modified");
                String safeValidator=etag!=null&&!etag.startsWith("W/")?etag:(modified==null?"":modified);
                Properties saved=new Properties();saved.setProperty("url",url);saved.setProperty("validator",safeValidator);
                saved.setProperty("etag",etag==null?"":etag);
                // Truncate a 200 response BEFORE saving its new validator: never mix old/new APK bytes.
                try(FileOutputStream out=new FileOutputStream(target,offset>0)) {
                    try(OutputStream mo=new FileOutputStream(meta)){saved.store(mo,"update partial file");}
                    long got=offset;progress.update(got,total);
                    try(InputStream in=c.getInputStream()) {
                        byte[] b=new byte[32768];int n;
                        while((n=in.read(b))!=-1) {
                            if(System.nanoTime()>deadline)throw new PermanentFailure("APK download time limit; partial file kept");
                            if(got+n>MAX_APK)throw new PermanentFailure("APK too large");
                            out.write(b,0,n);got+=n;progress.update(got,total);
                        }
                    }
                    if(total>=0&&got!=total)throw new IOException("incomplete APK");
                    out.getFD().sync();
                    if(got==0)throw new IOException("empty APK");
                }
                return;
            } catch(IOException e){last=e;if(!retryable(e))throw e;}
            finally {if(c!=null)c.disconnect();}
            if(attempt<5)pause(attempt);
        }
        throw last;
    }
}
